package controller;

import dal.TicketDAO;
import model.Ticket;
import model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "AdminTicketServlet", urlPatterns = {"/admin/tickets"})
public class AdminTicketServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        // Mở cửa cho cả ADMIN và MANAGER
        if (user == null || (!"ADMIN".equalsIgnoreCase(user.getRole()) && !"MANAGER".equalsIgnoreCase(user.getRole()))) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }

        try {
            TicketDAO ticketDao = new TicketDAO();
            List<Ticket> ticketList = ticketDao.getAllTickets();

            request.setAttribute("ticketList", ticketList);
            request.getRequestDispatcher("tickets.jsp").forward(request, response);
        } catch (Exception e) {
            System.out.println("Lỗi AdminTicketServlet: " + e.getMessage());
            response.sendRedirect("../AdminServlet");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}