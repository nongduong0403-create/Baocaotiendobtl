package controller;

import dal.MovieDAO;
import model.Movie;
import model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "AdminMovieServlet", urlPatterns = {"/admin/movies"})
public class AdminMovieServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        // ĐÃ SỬA: Cho phép cả ADMIN và MANAGER truy cập load trang
        if (user == null || (!"ADMIN".equalsIgnoreCase(user.getRole()) && !"MANAGER".equalsIgnoreCase(user.getRole()))) {
            response.sendRedirect("../login.jsp");
            return;
        }

        try {
            MovieDAO movieDao = new MovieDAO();
            String action = request.getParameter("action");

            // 1. XỬ LÝ NÚT XÓA (Gửi qua URL)
            if ("delete".equals(action)) {
                String idStr = request.getParameter("id");
                if (idStr != null && !idStr.trim().isEmpty()) {
                    int id = Integer.parseInt(idStr);
                    movieDao.deleteMovie(id); // Chạy lệnh DELETE trong DB
                }
                // Xóa xong chuyển hướng lại trang phim
                response.sendRedirect(request.getContextPath() + "/admin/movies");
                return;
            }

            // 2. MẶC ĐỊNH: LOAD DANH SÁCH PHIM LÊN GIAO DIỆN
            List<Movie> movieList = movieDao.getAllMovies();
            request.setAttribute("movieList", movieList);
            request.getRequestDispatcher("movies.jsp").forward(request, response);

        } catch (Exception e) {
            System.out.println("Lỗi AdminMovieServlet (doGet): " + e.getMessage());
            response.sendRedirect("../AdminServlet");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Ép kiểu UTF-8 để nhập tiếng Việt có dấu không bị lỗi
        request.setCharacterEncoding("UTF-8");

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        // Cho phép cả ADMIN và MANAGER truy cập
        if (user == null || (!"ADMIN".equalsIgnoreCase(user.getRole()) && !"MANAGER".equalsIgnoreCase(user.getRole()))) {
            response.sendRedirect("../login.jsp");
            return;
        }

        try {
            MovieDAO movieDao = new MovieDAO();
            String action = request.getParameter("action");

            // Lấy các tham số chung từ Form gửi lên
            String title = request.getParameter("title");
            String posterUrl = request.getParameter("posterUrl");
            String description = request.getParameter("description");
            String ageRating = request.getParameter("ageRating");

            int duration = Integer.parseInt(request.getParameter("duration"));
            int status = Integer.parseInt(request.getParameter("status"));

            // Nếu Checkbox HOT được tích thì nó sẽ trả về chuỗi "true", nếu không tích thì trả về null
            boolean isHot = request.getParameter("isHot") != null;

            // 3. XỬ LÝ FORM THÊM PHIM MỚI
            if ("add".equals(action)) {
                // Khởi tạo phim mới (ID = 0 vì DB sẽ tự tăng)
                Movie newMovie = new Movie();
                newMovie.setTitle(title);
                newMovie.setPosterUrl(posterUrl);
                newMovie.setDuration(duration);
                newMovie.setStatus(status);
                newMovie.setAgeRating(ageRating);
                newMovie.setHot(isHot);
                newMovie.setDescription(description);

                movieDao.addMovie(newMovie); // Chạy lệnh INSERT INTO
            }
            // 4. XỬ LÝ FORM CẬP NHẬT PHIM
            else if ("edit".equals(action)) {
                int id = Integer.parseInt(request.getParameter("id"));

                Movie updatedMovie = new Movie();
                updatedMovie.setId(id);
                updatedMovie.setTitle(title);
                updatedMovie.setPosterUrl(posterUrl);
                updatedMovie.setDuration(duration);
                updatedMovie.setStatus(status);
                updatedMovie.setAgeRating(ageRating);
                updatedMovie.setHot(isHot);
                updatedMovie.setDescription(description);

                movieDao.updateMovie(updatedMovie); // Chạy lệnh UPDATE
            }

            // Xử lý xong thì tự động load lại trang danh sách phim
            response.sendRedirect(request.getContextPath() + "/admin/movies");

        } catch (Exception e) {
            System.out.println("Lỗi AdminMovieServlet (doPost): " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/admin/movies");
        }
    }
}