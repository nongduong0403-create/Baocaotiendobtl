package controller;

import dal.DBContext;
import model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

@WebServlet(name = "AddMovieServlet", urlPatterns = {"/admin/add-movie"})
public class AddMovieServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Đảm bảo tiếng Việt không bị lỗi font
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        if (user == null || !"ADMIN".equalsIgnoreCase(user.getRole())) {
            response.sendRedirect("../login.jsp");
            return;
        }

        try {
            // Lấy dữ liệu từ form modal
            String title = request.getParameter("title");
            String posterUrl = request.getParameter("posterUrl");
            int duration = Integer.parseInt(request.getParameter("duration"));
            String description = request.getParameter("description");
            int status = Integer.parseInt(request.getParameter("status"));
            String ageRating = request.getParameter("ageRating");
            boolean isHot = request.getParameter("isHot") != null;

            // Câu lệnh SQL thêm phim mới (có tính đến cột is_deleted mặc định là false)
            String sql = "INSERT INTO Movie (title, poster_url, duration, description, status, age_rating, is_hot, is_deleted) VALUES (?, ?, ?, ?, ?, ?, ?, FALSE)";

            Connection conn = DBContext.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, title);
            ps.setString(2, posterUrl);
            ps.setInt(3, duration);
            ps.setString(4, description);
            ps.setInt(5, status);
            ps.setString(6, ageRating);
            ps.setBoolean(7, isHot);

            ps.executeUpdate();
            conn.close();

            System.out.println("Thêm phim mới thành công: " + title);
        } catch (Exception e) {
            System.out.println("Lỗi thêm phim mới: " + e.getMessage());
        }

        // Quay lại trang danh sách phim
        response.sendRedirect("movies");
    }
}