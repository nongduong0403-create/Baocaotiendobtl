package controller;

import dal.ShowtimeDAO;
import model.Showtime;
import model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Date;
import java.util.List;

@WebServlet(name = "AdminShowtimeServlet", urlPatterns = {"/admin/showtimes"})
public class AdminShowtimeServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        // ĐÃ SỬA: Cho phép cả ADMIN và MANAGER truy cập load trang
        if (user == null || (!"ADMIN".equalsIgnoreCase(user.getRole()) && !"MANAGER".equalsIgnoreCase(user.getRole()))) {
            response.sendRedirect("../login.jsp");
            return;
        }

        try {
            ShowtimeDAO showtimeDao = new ShowtimeDAO();
            String action = request.getParameter("action");

            // 1. XỬ LÝ NÚT XÓA LỊCH CHIẾU
            if ("delete".equals(action)) {
                String idStr = request.getParameter("id");
                if (idStr != null && !idStr.trim().isEmpty()) {
                    int id = Integer.parseInt(idStr);
                    showtimeDao.deleteShowtime(id); // Gọi hàm xóa trong ShowtimeDAO
                }
                // Xóa xong chuyển hướng lại trang quản lý lịch chiếu
                response.sendRedirect(request.getContextPath() + "/admin/showtimes");
                return;
            }

            // 2. MẶC ĐỊNH: LOAD DANH SÁCH LỊCH CHIẾU LÊN GIAO DIỆN
            List<Showtime> showtimeList = showtimeDao.getAllShowtimes();
            request.setAttribute("showtimeList", showtimeList);
            request.getRequestDispatcher("showtimes.jsp").forward(request, response);

        } catch (Exception e) {
            System.out.println("Lỗi AdminShowtimeServlet (doGet): " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/AdminServlet");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Ép kiểu UTF-8 để không bị lỗi dữ liệu
        request.setCharacterEncoding("UTF-8");

        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        // Cho phép cả ADMIN và MANAGER truy cập
        if (user == null || (!"ADMIN".equalsIgnoreCase(user.getRole()) && !"MANAGER".equalsIgnoreCase(user.getRole()))) {
            response.sendRedirect("../login.jsp");
            return;
        }

        try {
            ShowtimeDAO showtimeDao = new ShowtimeDAO();
            String action = request.getParameter("action");

            // Lấy các tham số từ Form Modal Thêm/Sửa gửi lên
            int movieId = Integer.parseInt(request.getParameter("movieId"));
            int roomId = Integer.parseInt(request.getParameter("roomId"));

            // Ép kiểu String từ input date sang java.sql.Date để khớp với model Showtime
            Date showDate = Date.valueOf(request.getParameter("showDate"));

            String showTime = request.getParameter("showTime");
            int price = Integer.parseInt(request.getParameter("price"));

            // 3. XỬ LÝ THÊM MỚI LỊCH CHIẾU
            if ("add".equals(action)) {
                Showtime newShowtime = new Showtime();
                newShowtime.setMovieId(movieId);
                newShowtime.setRoomId(roomId);
                newShowtime.setShowDate(showDate);
                newShowtime.setShowTime(showTime);
                newShowtime.setPrice(price);

                showtimeDao.addShowtime(newShowtime);
            }
            // 4. XỬ LÝ CẬP NHẬT LỊCH CHIẾU
            else if ("edit".equals(action)) {
                int id = Integer.parseInt(request.getParameter("id"));

                Showtime updatedShowtime = new Showtime();
                updatedShowtime.setId(id);
                updatedShowtime.setMovieId(movieId);
                updatedShowtime.setRoomId(roomId);
                updatedShowtime.setShowDate(showDate);
                updatedShowtime.setShowTime(showTime);
                updatedShowtime.setPrice(price);

                showtimeDao.updateShowtime(updatedShowtime);
            }

            // Xử lý xong chuyển hướng về trang danh sách lịch chiếu
            response.sendRedirect(request.getContextPath() + "/admin/showtimes");

        } catch (Exception e) {
            System.out.println("Lỗi AdminShowtimeServlet (doPost): " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/admin/showtimes");
        }
    }
}