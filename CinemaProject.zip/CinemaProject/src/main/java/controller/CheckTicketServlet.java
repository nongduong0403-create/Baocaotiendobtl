package controller;

import dal.DBContext;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "CheckTicketServlet", urlPatterns = {"/check-ticket"})
public class CheckTicketServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // 1. CHỨC NĂNG TÌM KIẾM VÉ
        String ticketCode = request.getParameter("ticketCode");

        if (ticketCode != null && !ticketCode.trim().isEmpty()) {
            try {
                Connection conn = DBContext.getConnection();
                // Tìm vé theo ID đơn hàng (VD: khách đọc mã BK-12, ta cắt lấy số 12)
                String searchId = ticketCode.replaceAll("[^0-9]", "");

                String sql = "SELECT b.id, b.status, b.total_amount, s.show_date, s.show_time " +
                        "FROM booking b JOIN showtime s ON b.showtime_id = s.id " +
                        "WHERE b.id = ?";

                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, searchId.isEmpty() ? "0" : searchId);
                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    request.setAttribute("bookingId", rs.getInt("id"));
                    request.setAttribute("status", rs.getString("status"));
                    request.setAttribute("totalAmount", rs.getDouble("total_amount"));
                    request.setAttribute("showDate", rs.getString("show_date"));
                    request.setAttribute("showTime", rs.getString("show_time"));

                    // Lấy danh sách ghế của đơn hàng này
                    String seatSql = "SELECT seat_name FROM showtime_seat WHERE booking_id = ?";
                    PreparedStatement psSeat = conn.prepareStatement(seatSql);
                    psSeat.setInt(1, rs.getInt("id"));
                    ResultSet rsSeat = psSeat.executeQuery();
                    StringBuilder seats = new StringBuilder();
                    while(rsSeat.next()) {
                        seats.append(rsSeat.getString("seat_name")).append(", ");
                    }
                    request.setAttribute("seats", seats.toString().replaceAll(", $", ""));
                } else {
                    request.setAttribute("error", "Không tìm thấy mã vé này trong hệ thống!");
                }
                conn.close();
            } catch (Exception e) {
                e.printStackTrace();
                request.setAttribute("error", "Lỗi CSDL: " + e.getMessage());
            }
        }

        // Đẩy kết quả tìm được về lại đúng trang giao diện POS
        request.getRequestDispatcher("pos.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // 2. CHỨC NĂNG XÁC NHẬN CHECK-IN (Chuyển trạng thái vé thành Đã sử dụng)
        String bookingId = request.getParameter("bookingId");

        try {
            Connection conn = DBContext.getConnection();
            String sql = "UPDATE booking SET status = 'USED' WHERE id = ?";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, bookingId);
            int updated = ps.executeUpdate();

            conn.close();

            if (updated > 0) {
                response.sendRedirect("pos.jsp?success=Check-in thành công mã BK-" + bookingId);
            } else {
                response.sendRedirect("pos.jsp?error=Lỗi khi cập nhật trạng thái");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("pos.jsp?error=Lỗi hệ thống");
        }
    }
}