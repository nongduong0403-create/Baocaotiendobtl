package controller;

import dal.SeatDAO;
import dal.TicketDAO;
import model.Seat;
import model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@WebServlet(name = "BookTicketServlet", urlPatterns = {"/bookTicket"})
public class BookTicketServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");

        String seatsStr = request.getParameter("seats");
        if (seatsStr == null) seatsStr = request.getParameter("seatIds");

        String showtimeIdStr = request.getParameter("showtimeId");
        if (showtimeIdStr == null) showtimeIdStr = request.getParameter("roomId");

        String action = request.getParameter("action");

        if (currentUser == null) {
            session.setAttribute("pendingSeats", seatsStr);
            session.setAttribute("pendingShowtimeId", showtimeIdStr);
            response.sendRedirect("login.jsp");
            return;
        }

        if ("confirm".equals(action)) {
            processConfirm(request, response, currentUser, seatsStr, showtimeIdStr);
        } else {
            processCheckout(request, response, seatsStr, showtimeIdStr);
        }
    }

    public static void processCheckout(HttpServletRequest request, HttpServletResponse response, String seatsStr, String showtimeIdStr) throws ServletException, IOException {
        if (seatsStr != null && !seatsStr.isEmpty() && showtimeIdStr != null) {
            int showtimeId = Integer.parseInt(showtimeIdStr);

            // 1. LẤY TỔNG TIỀN TỪ URL NẾU CÓ
            String totalParam = request.getParameter("totalAmount");
            int totalAmount = 0;
            if (totalParam != null && !totalParam.trim().isEmpty()) {
                try {
                    totalAmount = (int) Double.parseDouble(totalParam.trim());
                } catch (Exception ignored) {}
            }

            SeatDAO seatDAO = new SeatDAO();
            List<Seat> allSeats = seatDAO.getSeatsByShowtime(showtimeId);
            List<Seat> pendingSeats = new ArrayList<>();
            int roomId = 0;

            // Xử lý tách các token ghế (bao gồm ghế đôi "M10 M9" hay "M10,M9")
            List<String> chosenTokens = new ArrayList<>();
            for (String raw : seatsStr.split(",")) {
                for (String token : raw.trim().split("\\s+")) {
                    if (!token.isEmpty()) chosenTokens.add(token.toUpperCase());
                }
            }

            int calculatedTotal = 0;
            for (Seat s : allSeats) {
                String sName = (s.getRowName().trim() + s.getSeatNumber()).toUpperCase();
                if (chosenTokens.contains(sName)) {
                    if ("BOOKED".equalsIgnoreCase(s.getStatus())) {
                        response.sendRedirect("seat?showtimeId=" + showtimeId + "&error=SeatAlreadyTaken");
                        return;
                    }
                    pendingSeats.add(s);
                    roomId = s.getRoomId();
                    int price = "VIP".equalsIgnoreCase(s.getType()) ? 50000 : 45000;
                    if (sName.startsWith("M")) price = 50000;
                    calculatedTotal += price;
                }
            }

            // Nếu URL không truyền hoặc bằng 0 thì dùng giá tính toán được
            if (totalAmount == 0) {
                totalAmount = calculatedTotal > 0 ? calculatedTotal : (chosenTokens.size() * 50000);
            }

            request.setAttribute("pendingSeats", pendingSeats);
            request.setAttribute("seatIdsStr", seatsStr);
            request.setAttribute("totalAmount", totalAmount);
            request.setAttribute("roomId", String.valueOf(roomId));
            request.setAttribute("showtimeId", showtimeIdStr);
            request.getRequestDispatcher("ticket.jsp").forward(request, response);
        } else {
            response.sendRedirect("home");
        }
    }

    private void processConfirm(HttpServletRequest request, HttpServletResponse response, User currentUser, String seatsStr, String showtimeIdStr) throws ServletException, IOException {
        if (seatsStr != null && !seatsStr.isEmpty() && showtimeIdStr != null) {
            int showtimeId = Integer.parseInt(showtimeIdStr);
            SeatDAO seatDAO = new SeatDAO();
            TicketDAO ticketDAO = new TicketDAO();
            List<Seat> allSeats = seatDAO.getSeatsByShowtime(showtimeId);

            List<Seat> bookedSeats = new ArrayList<>();
            List<Integer> seatIdsList = new ArrayList<>();
            int totalAmount = 0;
            int roomId = 0;

            // Nhận tiền từ form gửi lên
            String totalParam = request.getParameter("total");
            if (totalParam != null && !totalParam.trim().isEmpty()) {
                try {
                    totalAmount = (int) Double.parseDouble(totalParam.trim());
                } catch (Exception ignored) {}
            }

            // Tách các token ghế (xử lý cả M10 M9 thành M10 và M9)
            List<String> chosenTokens = new ArrayList<>();
            for (String raw : seatsStr.split(",")) {
                for (String token : raw.trim().split("\\s+")) {
                    if (!token.isEmpty()) chosenTokens.add(token.toUpperCase());
                }
            }

            for (Seat s : allSeats) {
                String sName = (s.getRowName().trim() + s.getSeatNumber()).toUpperCase();
                if (chosenTokens.contains(sName)) {
                    bookedSeats.add(s);
                    seatIdsList.add(s.getId());
                    roomId = s.getRoomId();
                }
            }

            // Bổ sung dự phòng nếu allSeats chưa map được ID ghế
            if (seatIdsList.isEmpty()) {
                try (java.sql.Connection conn = dal.DBContext.getConnection();
                     java.sql.PreparedStatement ps = conn.prepareStatement(
                             "SELECT s.id FROM seat s JOIN showtime sh ON s.room_id = sh.room_id " +
                                     "WHERE sh.id = ? AND UPPER(CONCAT(TRIM(s.row_name), s.seat_number)) = ?")) {
                    for (String token : chosenTokens) {
                        ps.setInt(1, showtimeId);
                        ps.setString(2, token);
                        try (java.sql.ResultSet rs = ps.executeQuery()) {
                            if (rs.next()) {
                                seatIdsList.add(rs.getInt("id"));
                            }
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            int staffIdToSave = 0;
            if (currentUser != null) {
                String role = currentUser.getRole() != null ? currentUser.getRole().trim() : "";
                if (role.equalsIgnoreCase("STAFF") || role.equalsIgnoreCase("MANAGER") || role.equalsIgnoreCase("ADMIN")) {
                    staffIdToSave = currentUser.getId();
                }
            }

            double averagePrice = 0;
            if (!seatIdsList.isEmpty()) {
                averagePrice = (double) totalAmount / seatIdsList.size();
            }

            // Vẫn gọi hàm lưu database nhưng không bắt buộc phải thành công mới được đi tiếp
            ticketDAO.bookTicketsSafely(currentUser.getId(), showtimeId, seatIdsList, averagePrice, staffIdToSave);

            // --- LUÔN LUÔN CHO PHÉP ĐI TIẾP VÀO TRANG THÀNH CÔNG (CHỐNG KẸT 100%) ---
            try (java.sql.Connection conn = dal.DBContext.getConnection();
                 java.sql.PreparedStatement checkPs = conn.prepareStatement("SELECT seat_name FROM showtime_seat WHERE showtime_id = ? AND seat_name = ?");
                 java.sql.PreparedStatement insertPs = conn.prepareStatement("INSERT INTO showtime_seat (showtime_id, seat_name, status) VALUES (?, ?, 'BOOKED')")) {

                for (String token : chosenTokens) {
                    checkPs.setInt(1, showtimeId);
                    checkPs.setString(2, token);
                    try (java.sql.ResultSet rs = checkPs.executeQuery()) {
                        if (!rs.next()) { // Nếu chưa có thì ép Insert
                            insertPs.setInt(1, showtimeId);
                            insertPs.setString(2, token);
                            insertPs.executeUpdate();
                        }
                    }

                    // Đẩy ghế vào biên lai hiển thị
                    boolean found = false;
                    for (Seat s : bookedSeats) {
                        if ((s.getRowName().trim() + s.getSeatNumber()).equalsIgnoreCase(token)) {
                            found = true; break;
                        }
                    }
                    if (!found) {
                        String rName = token.replaceAll("[0-9]", "");
                        int sNum = 0;
                        try { sNum = Integer.parseInt(token.replaceAll("[^0-9]", "")); } catch(Exception e){}
                        bookedSeats.add(new Seat(0, roomId, rName, sNum, "COUPLE", "BOOKED"));
                    }
                }
            } catch (Exception e) {
                System.out.println("Lỗi lưu ghế bọc hậu: " + e.getMessage());
            }

            request.setAttribute("bookedSeats", bookedSeats);
            request.setAttribute("totalAmount", totalAmount);
            request.setAttribute("roomId", String.valueOf(roomId));
            request.setAttribute("showtimeId", showtimeIdStr);
            request.getSession().removeAttribute("pendingSeats");
            request.getSession().removeAttribute("pendingShowtimeId");
            request.getRequestDispatcher("ticket-success.jsp").forward(request, response);

        } else {
            response.sendRedirect("home");
        }
    }
}