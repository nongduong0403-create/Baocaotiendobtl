package controller;

import dal.SeatDAO;
import model.Seat;

import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "SeatServlet", urlPatterns = {"/seat"})
public class SeatServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");

        String showtimeIdStr = request.getParameter("showtimeId");

        if (showtimeIdStr != null && !showtimeIdStr.isEmpty()) {
            try {
                int showtimeId = Integer.parseInt(showtimeIdStr);

                // 1. Gọi hàm ĐÃ SỬA để lấy danh sách ghế theo ĐÚNG suất chiếu này
                SeatDAO seatDAO = new SeatDAO();
                List<Seat> seatList = seatDAO.getSeatsByShowtime(showtimeId);

                // 2. Ép danh sách ghế vào request để truyền ra JSP
                request.setAttribute("seatList", seatList);
                request.setAttribute("showtimeId", showtimeId);

                // 3. Mở file giao diện chọn ghế
                request.getRequestDispatcher("seat.jsp").forward(request, response);

            } catch (Exception e) {
                System.out.println("Lỗi tại SeatServlet: " + e.getMessage());
                response.sendRedirect("home");
            }
        } else {
            response.sendRedirect("home");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doGet(request, response);
    }
}