package controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "LoadSeatServlet", urlPatterns = {"/load-seat"})
public class LoadSeatServlet extends HttpServlet {

    private final String DB_URL = "jdbc:mysql://localhost:3306/cinema_management?useSSL=false&serverTimezone=UTC";
    private final String DB_USER = "root";
    private final String DB_PASS = "admin";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // ĐỔI TÊN BIẾN ĐỂ TRÁNH NHẦM LẪN LÀ MÃ PHÒNG (Room)
        String showtimeIdStr = request.getParameter("showtimeId");

        if (showtimeIdStr == null || showtimeIdStr.trim().isEmpty()) {
            response.sendRedirect("home.jsp");
            return;
        }

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS)) {

                // CÂU SQL ĐÃ ĐƯỢC LÀM SẠCH, BỎ ĐI BẢNG ROOM VÌ SHOWTIME KHÔNG CÓ CỘT NÀY
                String sql = "SELECT m.title AS movieName, s.show_date, s.show_time, m.duration " +
                        "FROM showtime s " +
                        "JOIN movie m ON s.movie_id = m.id " +
                        "WHERE s.id = ?";

                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setInt(1, Integer.parseInt(showtimeIdStr));
                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    request.setAttribute("movieName", rs.getString("movieName"));
                    request.setAttribute("showDate", rs.getString("show_date"));
                    request.setAttribute("showTime", rs.getString("show_time"));
                    request.setAttribute("duration", rs.getString("duration"));
                } else {
                    request.setAttribute("movieName", "Phim không xác định (Sai ID suất chiếu)");
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("movieName", "Chi tiết lỗi: " + e.getMessage());
        }

        // Truyền thẳng showtimeId sang trang chọn ghế
        request.setAttribute("showtimeId", showtimeIdStr);
        request.getRequestDispatcher("seat.jsp").forward(request, response);
    }
}