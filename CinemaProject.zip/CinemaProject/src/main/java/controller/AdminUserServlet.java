package controller;

import dal.UserDAO;
import model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "AdminUserServlet", urlPatterns = {"/admin/users"})
public class AdminUserServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");

        // Cho phép cả ADMIN hoặc MANAGER truy cập
        if (currentUser == null || (!"ADMIN".equalsIgnoreCase(currentUser.getRole()) && !"MANAGER".equalsIgnoreCase(currentUser.getRole()))) {
            response.sendRedirect("../login.jsp");
            return;
        }

        try {
            UserDAO userDao = new UserDAO();
            String action = request.getParameter("action");

            // 1. XỬ LÝ XÓA TÀI KHOẢN (Gửi qua URL)
            if ("delete".equalsIgnoreCase(action)) {
                String idStr = request.getParameter("id");
                if (idStr != null && !idStr.trim().isEmpty()) {
                    int id = Integer.parseInt(idStr);
                    // Không cho phép tài khoản tự xóa chính mình khi đang đăng nhập
                    if (currentUser.getId() != id) {
                        userDao.deleteUser(id);
                    }
                }
                response.sendRedirect(request.getContextPath() + "/admin/users");
                return;
            }

            // 2. MẶC ĐỊNH: LẤY DANH SÁCH USER HIỂN THỊ
            List<User> userList = userDao.getAllUsers();
            request.setAttribute("userList", userList);
            request.getRequestDispatcher("users.jsp").forward(request, response);

        } catch (Exception e) {
            System.out.println("Lỗi AdminUserServlet (doGet): " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/AdminServlet");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Hỗ trợ tiếng Việt UTF-8 khi lưu tên người dùng
        request.setCharacterEncoding("UTF-8");

        HttpSession session = request.getSession();
        User currentUser = (User) session.getAttribute("user");

        if (currentUser == null || (!"ADMIN".equalsIgnoreCase(currentUser.getRole()) && !"MANAGER".equalsIgnoreCase(currentUser.getRole()))) {
            response.sendRedirect("../login.jsp");
            return;
        }

        try {
            UserDAO userDao = new UserDAO();
            String action = request.getParameter("action");

            // 3. XỬ LÝ FORM THÊM TÀI KHOẢN MỚI
            if ("add".equalsIgnoreCase(action)) {
                String username = request.getParameter("username");
                String pass = request.getParameter("password");
                String fullName = request.getParameter("fullName");
                String role = request.getParameter("role");

                userDao.insertUser(username, pass, fullName, role);
            }
            // 4. XỬ LÝ FORM SỬA / CẬP NHẬT TÀI KHOẢN
            else if ("edit".equalsIgnoreCase(action)) {
                int id = Integer.parseInt(request.getParameter("id"));
                String pass = request.getParameter("password");
                String fullName = request.getParameter("fullName");
                String role = request.getParameter("role");

                userDao.updateUser(id, pass, fullName, role);
            }

            // Xử lý xong tự động load lại danh sách tài khoản
            response.sendRedirect(request.getContextPath() + "/admin/users");

        } catch (Exception e) {
            System.out.println("Lỗi AdminUserServlet (doPost): " + e.getMessage());
            response.sendRedirect(request.getContextPath() + "/admin/users");
        }
    }
}