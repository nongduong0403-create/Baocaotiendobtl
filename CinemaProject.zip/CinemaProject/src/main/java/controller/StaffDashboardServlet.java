package controller;

import dal.DBContext;
import model.User;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.time.LocalDate;

@WebServlet(name = "StaffDashboardServlet", urlPatterns = {"/staff/dashboard"})
public class StaffDashboardServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        // Kiểm tra quyền nhân viên / quản lý
        if (user == null || (!"STAFF".equals(user.getRole()) && !"MANAGER".equals(user.getRole()) && !"ADMIN".equals(user.getRole()))) {
            response.sendRedirect("../login.jsp");
            return;
        }

        int staffId = user.getId();
        LocalDate today = LocalDate.now();

        int totalTicketsSold = 0;
        double totalRevenue = 0;
        int totalCheckedIn = 0;

        try {
            Connection conn = DBContext.getConnection();

            // 1. Thống kê tổng vé do nhân viên này bán trong ngày hôm nay
            String sqlStats = "SELECT COUNT(id) AS ticket_count, SUM(total_amount) AS revenue " +
                    "FROM booking WHERE staff_id = ? AND DATE(booking_time) = ? AND status IN ('PAID', 'USED')";
            PreparedStatement ps = conn.prepareStatement(sqlStats);
            ps.setInt(1, staffId);
            ps.setString(2, today.toString());
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                totalTicketsSold = rs.getInt("ticket_count");
                totalRevenue = rs.getDouble("revenue");
            }

            // 2. Thống kê số lượng khách đã check-in trong ngày
            String sqlCheckin = "SELECT COUNT(id) AS checked_count FROM booking WHERE staff_id = ? AND DATE(booking_time) = ? AND status = 'USED'";
            PreparedStatement psCheckin = conn.prepareStatement(sqlCheckin);
            psCheckin.setInt(1, staffId);
            psCheckin.setString(2, today.toString());
            ResultSet rsCheckin = psCheckin.executeQuery();
            if (rsCheckin.next()) {
                totalCheckedIn = rsCheckin.getInt("checked_count");
            }

            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Đẩy dữ liệu sang giao diện JSP
        request.setAttribute("totalTicketsSold", totalTicketsSold);
        request.setAttribute("totalRevenue", totalRevenue);
        request.setAttribute("totalCheckedIn", totalCheckedIn);
        request.setAttribute("currentDate", today.toString());

        request.getRequestDispatcher("dashboard.jsp").forward(request, response);
    }
}