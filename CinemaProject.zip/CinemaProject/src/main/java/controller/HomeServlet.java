package controller;

import dal.MovieDAO;
import model.Movie;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "HomeServlet", urlPatterns = {"/home"})
public class HomeServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        // 1. DỌN SẠCH DỮ LIỆU ĐẶT VÉ CŨ KHI TRỞ VỀ TRANG CHỦ
        HttpSession session = request.getSession();
        session.removeAttribute("seatIdsStr");
        session.removeAttribute("roomId");
        session.removeAttribute("totalAmount");

        // 2. Lấy TOÀN BỘ danh sách phim từ Database
        MovieDAO movieDAO = new MovieDAO();
        List<Movie> movieList = movieDAO.getAllMovies();

        // 3. Gắn dữ liệu danh sách phim vào request
        request.setAttribute("movieList", movieList);

        // 4. Chuyển hướng an toàn sang home.jsp
        request.getRequestDispatcher("home.jsp").forward(request, response);
    }
}