package controller;

import dal.DBContext;
import model.User;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

@WebServlet(name = "StaffHistoryServlet", urlPatterns = {"/staff/history"})
public class StaffHistoryServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        // Kiểm tra quyền nhân viên
        if (user == null || (!"STAFF".equals(user.getRole()) && !"MANAGER".equals(user.getRole()) && !"ADMIN".equals(user.getRole()))) {
            response.sendRedirect("../login.jsp");
            return;
        }

        int staffId = user.getId();
        List<BookingHistoryDTO> historyList = new ArrayList<>();

        try {
            Connection conn = DBContext.getConnection();

            // FIX DỨT ĐIỂM: Quét cả staff_id VÀ user_id để không bao giờ lọt lưới bất kỳ đơn nào do NV này tạo!
            String sql = "SELECT id, booking_code, total_amount, booking_time, status " +
                    "FROM booking WHERE staff_id = ? OR user_id = ? ORDER BY booking_time DESC";

            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, staffId);
            ps.setInt(2, staffId); // Gắn staffId vào cả 2 tham số
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                BookingHistoryDTO item = new BookingHistoryDTO();
                item.setId(rs.getInt("id"));

                // Mẹo an toàn: Nếu DB cũ chưa có booking_code, tự sinh mã tạm để giao diện luôn hiện đẹp
                String code = rs.getString("booking_code");
                item.setBookingCode((code != null && !code.trim().isEmpty()) ? code : "BK-POS-" + rs.getInt("id"));

                item.setTotalAmount(rs.getDouble("total_amount"));
                item.setBookingTime(rs.getString("booking_time"));
                item.setStatus(rs.getString("status"));
                historyList.add(item);
            }
            conn.close();
        } catch (Exception e) {
            System.out.println("Lỗi tại StaffHistoryServlet: " + e.getMessage());
            e.printStackTrace();
        }

        request.setAttribute("historyList", historyList);
        request.getRequestDispatcher("history.jsp").forward(request, response);
    }

    // Class DTO
    public static class BookingHistoryDTO {
        private int id;
        private String bookingCode;
        private double totalAmount;
        private String bookingTime;
        private String status;

        public int getId() { return id; }
        public void setId(int id) { this.id = id; }
        public String getBookingCode() { return bookingCode; }
        public void setBookingCode(String bookingCode) { this.bookingCode = bookingCode; }
        public double getTotalAmount() { return totalAmount; }
        public void setTotalAmount(double totalAmount) { this.totalAmount = totalAmount; }
        public String getBookingTime() { return bookingTime; }
        public void setBookingTime(String bookingTime) { this.bookingTime = bookingTime; }
        public String getStatus() { return status; }
        public void setStatus(String status) { this.status = status; }
    }
}