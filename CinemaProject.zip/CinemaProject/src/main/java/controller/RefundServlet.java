package controller;

import dal.DBContext;
import java.io.IOException;
import java.net.URLEncoder; // ĐÃ THÊM: Thư viện mã hóa URL để sửa lỗi tiếng Việt
import java.sql.Connection;
import java.sql.PreparedStatement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "RefundServlet", urlPatterns = {"/refund-ticket"})
public class RefundServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Hỗ trợ tiếng Việt cho lý do hoàn vé
        request.setCharacterEncoding("UTF-8");

        String showtimeIdStr = request.getParameter("showtimeId");
        String seatsStr = request.getParameter("seats");

        // 1. Kiểm tra xem có nhận được ID suất chiếu và ghế không
        if (showtimeIdStr == null || showtimeIdStr.isEmpty() || seatsStr == null || seatsStr.isEmpty()) {
            response.sendRedirect("ticket-success.jsp?error=missing_id");
            return;
        }

        try {
            Connection conn = DBContext.getConnection();
            conn.setAutoCommit(false); // Bật Transaction an toàn

            // 2. LỆNH SÁT THỦ: Trực tiếp xóa ghế đỏ khỏi sơ đồ
            String freeSeatSql = "DELETE FROM showtime_seat WHERE showtime_id = ? AND seat_name = ?";
            PreparedStatement psFreeSeat = conn.prepareStatement(freeSeatSql);

            String[] seatArray = seatsStr.split(",");
            for (String sName : seatArray) {
                psFreeSeat.setString(1, showtimeIdStr);
                // Ép In hoa và xóa khoảng trắng để trùng khớp 100% với CSDL
                psFreeSeat.setString(2, sName.trim().toUpperCase());
                psFreeSeat.executeUpdate();
            }

            conn.commit();
            conn.close();

            // 3. ĐÃ SỬA: Mã hóa tiếng Việt trước khi đưa vào đường link để không bị lỗi văng trang trắng
            String encodedAmount = URLEncoder.encode("Toàn bộ tiền", "UTF-8");
            response.sendRedirect("ticket-success.jsp?success=refunded&amount=" + encodedAmount);

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("ticket-success.jsp?error=system_error");
        }
    }
}