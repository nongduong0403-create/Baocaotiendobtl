package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.UUID;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "PaymentServlet", urlPatterns = {"/process-payment"})
public class PaymentServlet extends HttpServlet {

    private final String DB_URL = "jdbc:mysql://localhost:3306/cinema_management?useSSL=false&serverTimezone=UTC";
    private final String DB_USER = "root";
    private final String DB_PASS = "admin";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        String showtimeIdStr = request.getParameter("showtimeId");
        String seatsStr = request.getParameter("seats");
        String total = request.getParameter("total");

        // --- ĐÃ THÊM: Hứng thêm biến bookingId từ giao diện ---
        String bookingId = request.getParameter("bookingId");

        if (showtimeIdStr == null || seatsStr == null) {
            out.write("<h3>Loi: Thieu ma suat chieu hoac ghe!</h3>");
            return;
        }

        try {
            int showtimeId = Integer.parseInt(showtimeIdStr);
            String[] seatArray = seatsStr.split(",");

            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);

            // 1. Xóa ghế bị kẹt (nếu có) để không bị lỗi trùng lặp
            String deleteSql = "DELETE FROM showtime_seat WHERE showtime_id = ? AND seat_name = ?";
            PreparedStatement psDel = conn.prepareStatement(deleteSql);

            // 2. Lệnh lưu ghế (Nếu database của cậu thiếu cột, nó sẽ văng lỗi ngay tại đây)
            String insertSql = "INSERT INTO showtime_seat (showtime_id, seat_name, status) VALUES (?, ?, 'BOOKED')";
            PreparedStatement psInsert = conn.prepareStatement(insertSql);

            for (String seatName : seatArray) {
                seatName = seatName.trim();

                // Chạy xóa trước cho an toàn
                psDel.setInt(1, showtimeId);
                psDel.setString(2, seatName);
                psDel.executeUpdate();

                // Chạy lưu vào DB
                psInsert.setInt(1, showtimeId);
                psInsert.setString(2, seatName);
                psInsert.executeUpdate();
            }

            conn.close();

            // NẾU THÀNH CÔNG: Chuyển hướng nhận vé
            String ticketCode = "TCK-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();

            // --- ĐÃ SỬA: Nối thêm bookingId vào đuôi link để RefundServlet không bị kích văng ra ngoài ---
            String redirectUrl = "ticket-success.jsp?seats=" + seatsStr + "&total=" + total + "&ticketCode=" + ticketCode + "&showtimeId=" + showtimeId;
            if (bookingId != null && !bookingId.isEmpty() && !"null".equals(bookingId)) {
                redirectUrl += "&bookingId=" + bookingId;
            }

            response.sendRedirect(redirectUrl);

        } catch (Exception e) {
            // NẾU MYSQL CHẶN: In lỗi thẳng ra màn hình
            out.write("<h2 style='color:red;'>PHÁT HIỆN LỖI DATABASE KHI LƯU GHẾ:</h2>");
            out.write("<h3 style='color:black;'>" + e.getMessage() + "</h3>");
            out.write("<br><p><b>Cậu copy dòng lỗi màu đen ở trên gửi cho tớ, tớ bắt đúng bệnh và chốt fix trong 1 nốt nhạc!</b></p>");
            e.printStackTrace();
        }
    }
}