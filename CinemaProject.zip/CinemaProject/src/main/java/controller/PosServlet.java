package controller;

import dal.DBContext;
import model.User;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet(name = "PosServlet", urlPatterns = {"/PosServlet"})
public class PosServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        // Kiểm tra bảo mật: Chỉ STAFF, MANAGER hoặc ADMIN mới được vào quầy POS
        if (user == null || (!"STAFF".equals(user.getRole()) && !"MANAGER".equals(user.getRole()) && !"ADMIN".equals(user.getRole()))) {
            response.sendRedirect("login.jsp");
            return;
        }

        // --- TÍNH NĂNG MỚI: TÌM KIẾM VÉ ĐỂ SOÁT VÉ ---
        String ticketCode = request.getParameter("ticketCode");
        if (ticketCode != null && !ticketCode.trim().isEmpty()) {
            try {
                Connection conn = DBContext.getConnection();
                // Tách lấy số từ mã vé (Ví dụ: Nhập BK-12 hoặc TCK-12 -> Lấy số 12)
                String searchId = ticketCode.replaceAll("[^0-9]", "");

                String sql = "SELECT b.id, b.status, b.total_amount, s.show_date, s.show_time " +
                        "FROM booking b JOIN showtime s ON b.showtime_id = s.id " +
                        "WHERE b.id = ?";

                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, searchId.isEmpty() ? "0" : searchId);
                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    request.setAttribute("bookingId", rs.getInt("id"));
                    request.setAttribute("status", rs.getString("status"));
                    request.setAttribute("totalAmount", rs.getDouble("total_amount"));
                    request.setAttribute("showDate", rs.getString("show_date"));
                    request.setAttribute("showTime", rs.getString("show_time"));

                    // Lấy danh sách ghế của đơn hàng
                    String seatSql = "SELECT seat_name FROM showtime_seat WHERE booking_id = ?";
                    PreparedStatement psSeat = conn.prepareStatement(seatSql);
                    psSeat.setInt(1, rs.getInt("id"));
                    ResultSet rsSeat = psSeat.executeQuery();
                    StringBuilder seats = new StringBuilder();
                    while(rsSeat.next()) {
                        seats.append(rsSeat.getString("seat_name")).append(", ");
                    }
                    request.setAttribute("seats", seats.toString().replaceAll(", $", ""));
                } else {
                    request.setAttribute("errorMsg", "Không tìm thấy thông tin vé cho mã này!");
                }
                conn.close();
            } catch (Exception e) {
                e.printStackTrace();
                request.setAttribute("errorMsg", "Lỗi CSDL: " + e.getMessage());
            }
        }

        // Chuyển hướng tới giao diện quầy bán vé POS
        request.getRequestDispatcher("pos.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // --- TÍNH NĂNG MỚI: XÁC NHẬN CHECK-IN (ĐỔI TRẠNG THÁI VÉ THÀNH USED) ---
        String bookingId = request.getParameter("bookingId");

        if (bookingId != null && !bookingId.isEmpty()) {
            try {
                Connection conn = DBContext.getConnection();
                String sql = "UPDATE booking SET status = 'USED' WHERE id = ?";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, bookingId);
                ps.executeUpdate();
                conn.close();

                response.sendRedirect("PosServlet?successMsg=Check-in thành công cho vé BK-" + bookingId);
                return;
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        doGet(request, response);
    }
}