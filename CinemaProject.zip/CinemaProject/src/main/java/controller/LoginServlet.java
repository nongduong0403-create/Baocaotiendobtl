package controller;

import dal.UserDAO;
import dal.TicketDAO;
import model.User;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet(name = "LoginServlet", urlPatterns = {"/login"})
public class LoginServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("login.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // 1. Lấy tài khoản và mật khẩu từ ô input trên form
        String u = request.getParameter("txtUser");
        String p = request.getParameter("txtPass");

        // 2. Giao cho DAO xuống DB kiểm tra
        UserDAO dao = new UserDAO();
        User user = dao.checkLogin(u, p);

        // 3. Xử lý kết quả
        if (user != null) {
            HttpSession session = request.getSession();
            session.setAttribute("user", user); // LƯU Ý: Tên biến là "user"

            // Đếm số vé đã mua
            TicketDAO ticketDAO = new TicketDAO();
            int totalTickets = ticketDAO.countTicketsByUser(user.getId());
            session.setAttribute("totalTickets", totalTickets);

            String role = user.getRole();

            // =============================================================
            // Hứng link redirect từ form login.jsp (Giữ nguyên)
            // =============================================================
            String redirectUrl = request.getParameter("redirect");
            if (redirectUrl != null && !redirectUrl.trim().isEmpty()) {
                response.sendRedirect(redirectUrl);
                return;
            }

            // =============================================================
            // Xử lý luồng đặt vé dở dang (Giữ nguyên)
            // =============================================================
            String pendingSeats = (String) session.getAttribute("pendingSeats");
            String pendingShowtimeId = (String) session.getAttribute("pendingShowtimeId");

            // Nếu khách đang mua dở vé thì đẩy thẳng sang trang quét mã QR thanh toán
            if (("CUSTOMER".equals(role) || role == null) && pendingSeats != null && pendingShowtimeId != null) {
                // Xóa dữ liệu tạm trong session
                session.removeAttribute("pendingSeats");
                session.removeAttribute("pendingShowtimeId");

                // Gọi thẳng sang luồng tính tiền của BookTicketServlet
                response.sendRedirect("bookTicket?showtimeId=" + pendingShowtimeId + "&seats=" + pendingSeats);
                return;
            }
            // =============================================================

            // =============================================================
            // ĐÃ SỬA: Phân luồng hệ thống nội bộ theo quyền (Role)
            // Cho phép cả ADMIN và MANAGER truy cập vào chung trang AdminServlet
            // =============================================================
            if ("ADMIN".equals(role) || "MANAGER".equals(role)) {
                response.sendRedirect("AdminServlet");
            } else if ("STAFF".equals(role)) {
                response.sendRedirect("staff/dashboard");
            } else {
                // Khách hàng bình thường đăng nhập từ đầu -> Về trang chủ
                response.sendRedirect("home");
            }
        } else {
            request.setAttribute("error", "Sai tài khoản hoặc mật khẩu!");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }
}