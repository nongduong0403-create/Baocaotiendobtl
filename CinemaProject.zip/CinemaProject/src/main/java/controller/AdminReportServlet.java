package controller;

import dal.ReportDAO;
import model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "AdminReportServlet", urlPatterns = {"/admin/reports"})
public class AdminReportServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        if (user == null || !"ADMIN".equalsIgnoreCase(user.getRole())) {
            response.sendRedirect("../login.jsp");
            return;
        }

        try {
            ReportDAO reportDao = new ReportDAO();
            double totalRevenue = reportDao.getTotalRevenue();
            int totalTickets = reportDao.getTotalTicketsSold();
            List<String[]> revenueDetails = reportDao.getRevenueDetails();

            request.setAttribute("totalRevenue", totalRevenue);
            request.setAttribute("totalTickets", totalTickets);
            request.setAttribute("revenueDetails", revenueDetails);

            request.getRequestDispatcher("reports.jsp").forward(request, response);
        } catch (Exception e) {
            System.out.println("Lỗi AdminReportServlet: " + e.getMessage());
            response.sendRedirect("../AdminServlet");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}