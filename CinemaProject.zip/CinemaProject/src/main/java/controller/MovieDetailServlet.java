package controller;

import dal.MovieDAO;
import model.Movie;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/movie-detail")
public class MovieDetailServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String idParam = request.getParameter("id");
        if (idParam != null) {
            int movieId = Integer.parseInt(idParam);
            MovieDAO dao = new MovieDAO();
            Movie movie = dao.getMovieById(movieId); // Hàm lấy phim theo ID trong DAO của cậu

            // Đẩy đối tượng movie sang trang JSP
            request.setAttribute("movie", movie);
        }
        request.getRequestDispatcher("movie-detail.jsp").forward(request, response);
    }
}