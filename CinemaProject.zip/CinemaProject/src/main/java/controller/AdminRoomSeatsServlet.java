package controller;

import dal.DBContext;
import dal.SeatDAO;
import model.Seat;
import model.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;

@WebServlet(name = "AdminRoomSeatsServlet", urlPatterns = {"/admin/room-seats"})
public class AdminRoomSeatsServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");

        // Cho phép cả ADMIN và MANAGER truy cập
        if (user == null || (!"ADMIN".equalsIgnoreCase(user.getRole()) && !"MANAGER".equalsIgnoreCase(user.getRole()))) {
            response.sendRedirect("../login.jsp");
            return;
        }

        try {
            int roomId = Integer.parseInt(request.getParameter("roomId"));
            request.setAttribute("roomId", roomId);

            SeatDAO seatDao = new SeatDAO();
            List<Seat> seatList = seatDao.getSeatsByRoomId(roomId);

            // NẾU PHÒNG NÀY CHƯA CÓ GHẾ NÀO -> TỰ ĐỘNG SINH TOÀN BỘ SƠ ĐỒ GHẾ CHUẨN (A-M)
            if (seatList == null || seatList.isEmpty()) {
                generateDefaultSeatsForRoom(roomId);
                // Load lại danh sách sau khi đã tự động tạo
                seatList = seatDao.getSeatsByRoomId(roomId);
            }

            request.setAttribute("seatList", seatList);
            request.getRequestDispatcher("room_seats.jsp").forward(request, response);
        } catch (Exception e) {
            System.out.println("Lỗi load sơ đồ ghế: " + e.getMessage());
            response.sendRedirect("AdminServlet");
        }
    }

    // Hàm tự động sinh sơ đồ ghế chuẩn cho phòng mới
    private void generateDefaultSeatsForRoom(int roomId) {
        String[] normalRows = {"A", "B", "C", "D", "E", "F", "G", "K", "L"};
        String[] vipRows = {"H", "I"};
        String[] lastRow = {"M"};

        try {
            Connection conn = DBContext.getConnection();
            String sql = "INSERT INTO seat (room_id, row_name, seat_number, type) VALUES (?, ?, ?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);

            // 1. Tạo ghế Thường cho các hàng từ A đến G, K, L (Mỗi hàng 14 ghế)
            for (String row : normalRows) {
                for (int i = 1; i <= 14; i++) {
                    ps.setInt(1, roomId);
                    ps.setString(2, row);
                    ps.setInt(3, i);
                    ps.setString(4, "NORMAL");
                    ps.addBatch();
                }
            }

            // 2. Tạo ghế VIP cho hàng H và I (Mỗi hàng 14 ghế)
            for (String row : vipRows) {
                for (int i = 1; i <= 14; i++) {
                    ps.setInt(1, roomId);
                    ps.setString(2, row);
                    ps.setInt(3, i);
                    ps.setString(4, "VIP");
                    ps.addBatch();
                }
            }

            // 3. Tạo ghế cho hàng cuối M (10 ghế)
            for (String row : lastRow) {
                for (int i = 1; i <= 10; i++) {
                    ps.setInt(1, roomId);
                    ps.setString(2, row);
                    ps.setInt(3, i);
                    ps.setString(4, "NORMAL");
                    ps.addBatch();
                }
            }

            ps.executeBatch();
            conn.close();
            System.out.println("Đã tự động tạo sơ đồ ghế thành công cho phòng ID: " + roomId);
        } catch (Exception e) {
            System.out.println("Lỗi tự động sinh ghế: " + e.getMessage());
        }
    }
}