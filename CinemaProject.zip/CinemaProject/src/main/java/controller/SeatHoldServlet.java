package controller;

import java.io.IOException;
import java.sql.*;
import java.time.LocalDateTime;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

// ĐÂY CHÍNH LÀ THƯ VIỆN BỊ THIẾU KHIẾN CODE KHÔNG CHẠY:
import model.User;

@WebServlet(name = "SeatHoldServlet", urlPatterns = {"/hold-seats"})
public class SeatHoldServlet extends HttpServlet {

    private final String DB_URL = "jdbc:mysql://localhost:3306/cinema_management?useSSL=false&serverTimezone=UTC";
    private final String DB_USER = "root";
    private final String DB_PASS = "admin";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");

        // ========================================================
        // 1. KIỂM TRA ĐĂNG NHẬP CHUẨN XÁC BẰNG CLASS model.User
        // ========================================================
        HttpSession session = request.getSession();

        // Đọc đúng biến "user" do LoginServlet truyền vào
        User user = (User) session.getAttribute("user");

        if (user == null) {
            // Khách chưa đăng nhập: Lấy thông tin ghế để lưu vết
            String roomIdStr = request.getParameter("roomId");
            String seatsParam = request.getParameter("seats");
            String totalAmountStr = request.getParameter("totalAmount");

            roomIdStr = (roomIdStr != null) ? roomIdStr : "";
            seatsParam = (seatsParam != null) ? seatsParam : "";
            totalAmountStr = (totalAmountStr != null) ? totalAmountStr : "";

            // Tạo đường dẫn lưu vết
            String returnUrl = "hold-seats?roomId=" + roomIdStr + "&seats=" + seatsParam + "&totalAmount=" + totalAmountStr;
            String encodedReturnUrl = java.net.URLEncoder.encode(returnUrl, "UTF-8");

            // Đá về form đăng nhập kèm link quay lại
            response.sendRedirect("login.jsp?message=Vui long dang nhap de tiep tuc&redirect=" + encodedReturnUrl);
            return;
        }

        // Khách ĐÃ đăng nhập: Lấy ID khách hàng thật từ Class User
        int userId = user.getId();

        // ========================================================
        // 2. LẤY DỮ LIỆU TỪ TRANG CHỌN GHẾ & TIẾN HÀNH GIỮ GHẾ
        // ========================================================
        String roomIdStr = request.getParameter("roomId");
        String seatsParam = request.getParameter("seats");
        String totalAmountStr = request.getParameter("totalAmount");

        if (seatsParam == null || seatsParam.trim().isEmpty()) {
            response.sendRedirect("seat.jsp?error=no_seat_selected");
            return;
        }

        String[] selectedSeats = seatsParam.split(",");
        int showtimeId = (roomIdStr != null && !roomIdStr.isEmpty()) ? Integer.parseInt(roomIdStr) : 1;

        Connection conn = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
            conn.setAutoCommit(false); // Bắt đầu Transaction

            // Kiểm tra xem ghế đã bị ai giữ hoặc đã bán chưa
            String checkSql = "SELECT seat_name, status, hold_until FROM showtime_seat WHERE showtime_id = ? AND seat_name = ?";
            PreparedStatement checkStmt = conn.prepareStatement(checkSql);
            LocalDateTime now = LocalDateTime.now();

            for (String seat : selectedSeats) {
                seat = seat.trim();
                checkStmt.setInt(1, showtimeId);
                checkStmt.setString(2, seat);
                ResultSet rs = checkStmt.executeQuery();

                if (rs.next()) {
                    String status = rs.getString("status");
                    Timestamp holdUntil = rs.getTimestamp("hold_until");

                    if ("SOLD".equals(status) || ("HELD".equals(status) && holdUntil != null && holdUntil.toLocalDateTime().isAfter(now))) {
                        conn.rollback();
                        response.sendRedirect("seat.jsp?error=seat_occupied&seat=" + seat);
                        return;
                    }
                }
            }

            // Tạo đơn hàng (Booking) gắn với ID KHÁCH HÀNG THẬT
            String bookingCode = "BK" + System.currentTimeMillis();
            double totalAmount = Double.parseDouble(totalAmountStr);

            String insertBookingSql = "INSERT INTO booking (user_id, showtime_id, booking_code, total_amount, status) VALUES (?, ?, ?, ?, 'PENDING_PAYMENT')";
            PreparedStatement bookingStmt = conn.prepareStatement(insertBookingSql, Statement.RETURN_GENERATED_KEYS);
            bookingStmt.setInt(1, userId);
            bookingStmt.setInt(2, showtimeId);
            bookingStmt.setString(3, bookingCode);
            bookingStmt.setDouble(4, totalAmount);
            bookingStmt.executeUpdate();

            ResultSet generatedKeys = bookingStmt.getGeneratedKeys();
            int bookingId = 0;
            if (generatedKeys.next()) {
                bookingId = generatedKeys.getInt(1);
            }

            // Cập nhật trạng thái ghế thành HELD (Giữ trong vòng 5 phút)
            String upsertSeatQuery = "INSERT INTO showtime_seat (showtime_id, seat_name, status, hold_until, booking_id) " +
                    "VALUES (?, ?, 'HELD', DATE_ADD(NOW(), INTERVAL 5 MINUTE), ?) " +
                    "ON DUPLICATE KEY UPDATE status = 'HELD', hold_until = DATE_ADD(NOW(), INTERVAL 5 MINUTE), booking_id = ?";
            PreparedStatement seatStmt = conn.prepareStatement(upsertSeatQuery);

            for (String seat : selectedSeats) {
                seat = seat.trim();
                seatStmt.setInt(1, showtimeId);
                seatStmt.setString(2, seat);
                seatStmt.setInt(3, bookingId);
                seatStmt.setInt(4, bookingId);
                seatStmt.executeUpdate();
            }

            conn.commit();

            // Chuyển hướng sang trang thanh toán checkout.jsp
            response.sendRedirect("checkout.jsp?bookingId=" + bookingId + "&seats=" + seatsParam + "&total=" + totalAmount);

        } catch (Exception e) {
            if (conn != null) {
                try { conn.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
            }
            e.printStackTrace();

            // HIỆN THẲNG LỖI RA MÀN HÌNH THAY VÌ ÂM THẦM ĐÁ VỀ TRANG CHỌN GHẾ
            response.setContentType("text/html;charset=UTF-8");
            response.getWriter().write("<div style='text-align:center; margin-top:50px; font-family:sans-serif;'>");
            response.getWriter().write("<h2 style='color:red;'>⚠️ LỖI DATABASE KHI LƯU ĐƠN HÀNG!</h2>");
            response.getWriter().write("<p style='font-size:18px; color:black;'><b>Lý do:</b> " + e.getMessage() + "</p>");
            response.getWriter().write("<div style='display:inline-block; text-align:left; background:#fff3cd; padding:20px; border-radius:10px;'>");
            response.getWriter().write("<b>Gợi ý nguyên nhân:</b><ul>");
            response.getWriter().write("<li>Bảng <b>showtime</b> chưa có suất chiếu nào mang <b>id = " + showtimeId + "</b> (Lỗi khóa ngoại).</li>");
            response.getWriter().write("<li>Cột trong bảng booking hoặc showtime_seat không khớp dữ liệu.</li>");
            response.getWriter().write("</ul></div><br><br>");
            response.getWriter().write("<a href='seat.jsp' style='padding:10px 20px; background:#0056b3; color:white; text-decoration:none; border-radius:5px;'>Quay lại trang chọn ghế</a>");
            response.getWriter().write("</div>");
        } finally {
            if (conn != null) {
                try { conn.close(); } catch (SQLException ex) { ex.printStackTrace(); }
            }
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }
}