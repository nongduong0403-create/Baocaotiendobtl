package controller;

import dal.MovieDAO;
import dal.ShowtimeDAO;
import model.Movie;
import model.Showtime;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "ShowtimeServlet", urlPatterns = {"/showtimes"})
public class ShowtimeServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");

        // 1. Lấy ID của bộ phim mà người dùng vừa click vào từ home.jsp
        String movieIdStr = request.getParameter("movieId");

        if (movieIdStr != null && !movieIdStr.isEmpty()) {
            try {
                int movieId = Integer.parseInt(movieIdStr);

                // 2. Gọi DAO để lấy Thông tin phim & Danh sách suất chiếu tương ứng
                MovieDAO movieDAO = new MovieDAO();
                Movie movie = movieDAO.getMovieById(movieId);

                ShowtimeDAO showtimeDAO = new ShowtimeDAO();
                List<Showtime> showtimeList = showtimeDAO.getShowtimesByMovieId(movieId);

                // 3. Đẩy dữ liệu động sang trang giao diện
                request.setAttribute("movie", movie);
                request.setAttribute("showtimeList", showtimeList);

                // Đã sửa thành showtime.jsp theo đúng tên file giao diện của cậu
                request.getRequestDispatcher("showtime.jsp").forward(request, response);

            } catch (Exception e) {
                System.out.println("Lỗi xử lý ShowtimeServlet: " + e.getMessage());
                response.sendRedirect("home");
            }
        } else {
            // Nếu không có ID phim thì trả về trang chủ
            response.sendRedirect("home");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}