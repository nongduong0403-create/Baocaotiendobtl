package dal;

import model.User;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {

    // Hàm kiểm tra đăng nhập
    public User checkLogin(String username, String password) {
        try {
            String sql = "SELECT * FROM user WHERE username = ? AND password = ?";

            Connection conn = DBContext.getConnection();
            PreparedStatement st = conn.prepareStatement(sql);

            st.setString(1, username);
            st.setString(2, password);
            ResultSet rs = st.executeQuery();

            if (rs.next()) {
                User u = new User();
                u.setId(rs.getInt("id"));
                u.setUsername(rs.getString("username"));
                u.setPassword(rs.getString("password"));

                // Lấy 4 thuộc tính mới thêm
                u.setRole(rs.getString("role"));
                u.setFullName(rs.getString("full_name"));
                u.setPoints(rs.getInt("points"));
                u.setMembershipTier(rs.getString("membership_tier"));

                return u;
            }
        } catch (Exception e) {
            System.out.println("Lỗi UserDAO: " + e.getMessage());
        }
        return null;
    }

    // Hàm main để test thử thuật toán
    public static void main(String[] args) {
        UserDAO dao = new UserDAO();

        // Thử đăng nhập bằng tài khoản mẫu trong DB
        User u = dao.checkLogin("admin", "123456");

        if (u != null) {
            System.out.println("Đăng nhập thành công! Quyền của bạn là: " + u.getRole());
        } else {
            System.out.println("Sai tài khoản hoặc mật khẩu!");
        }
    }

    // Hàm đăng ký tài khoản khách hàng mới
    public boolean register(String username, String password) {
        String sql = "INSERT INTO user (username, password, role) VALUES (?, ?, 'CUSTOMER')";
        try {
            Connection conn = DBContext.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, username);
            ps.setString(2, password);
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            System.out.println("Lỗi đăng ký: " + e.getMessage());
        }
        return false;
    }

    // Hàm lấy toàn bộ danh sách người dùng cho trang Admin
    public List<User> getAllUsers() {
        List<User> list = new ArrayList<>();
        String sql = "SELECT * FROM user ORDER BY id DESC";

        try {
            Connection conn = DBContext.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                User u = new User();
                u.setId(rs.getInt("id"));
                u.setUsername(rs.getString("username"));
                u.setPassword(rs.getString("password"));
                u.setRole(rs.getString("role"));
                u.setFullName(rs.getString("full_name"));
                u.setPoints(rs.getInt("points"));
                u.setMembershipTier(rs.getString("membership_tier"));

                list.add(u);
            }
            conn.close();
        } catch (Exception e) {
            System.out.println("Lỗi lấy danh sách user cho Admin: " + e.getMessage());
        }
        return list;
    }

    // 1. Hàm thêm mới tài khoản từ trang Quản trị
    public boolean insertUser(String username, String password, String fullName, String role) {
        String sql = "INSERT INTO user (username, password, full_name, role, points, membership_tier) VALUES (?, ?, ?, ?, 0, 'MEMBER')";
        try {
            Connection conn = DBContext.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, username);
            ps.setString(2, password);
            ps.setString(3, fullName);
            ps.setString(4, role);
            int rows = ps.executeUpdate();
            conn.close();
            return rows > 0;
        } catch (Exception e) {
            System.out.println("Lỗi UserDAO (insertUser): " + e.getMessage());
        }
        return false;
    }

    // 2. Hàm cập nhật thông tin/vai trò (giữ nguyên mật khẩu cũ nếu ô mật khẩu trống)
    public boolean updateUser(int id, String password, String fullName, String role) {
        String sql;
        boolean updatePass = (password != null && !password.trim().isEmpty());

        if (updatePass) {
            sql = "UPDATE user SET password = ?, full_name = ?, role = ? WHERE id = ?";
        } else {
            sql = "UPDATE user SET full_name = ?, role = ? WHERE id = ?";
        }

        try {
            Connection conn = DBContext.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            if (updatePass) {
                ps.setString(1, password);
                ps.setString(2, fullName);
                ps.setString(3, role);
                ps.setInt(4, id);
            } else {
                ps.setString(1, fullName);
                ps.setString(2, role);
                ps.setInt(3, id);
            }
            int rows = ps.executeUpdate();
            conn.close();
            return rows > 0;
        } catch (Exception e) {
            System.out.println("Lỗi UserDAO (updateUser): " + e.getMessage());
        }
        return false;
    }

    // 3. Hàm xóa tài khoản theo ID
    public boolean deleteUser(int id) {
        String sql = "DELETE FROM user WHERE id = ?";
        try {
            Connection conn = DBContext.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);
            int rows = ps.executeUpdate();
            conn.close();
            return rows > 0;
        } catch (Exception e) {
            System.out.println("Lỗi UserDAO (deleteUser): " + e.getMessage());
        }
        return false;
    }
}