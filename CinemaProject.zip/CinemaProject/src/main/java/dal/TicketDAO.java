package dal;

import model.Ticket;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class TicketDAO {

    public boolean bookTicketsSafely(int userId, int showtimeId, List<Integer> seatIds, double pricePerSeat, int staffId) {
        // CÁC CÂU LỆNH SQL
        String insertBookingSql = "INSERT INTO booking (user_id, showtime_id, booking_code, total_amount, status, staff_id, booking_time) VALUES (?, ?, ?, ?, 'PAID', ?, NOW())";
        String insertTicketSql = "INSERT INTO ticket (booking_id, seat_id, price) VALUES (?, ?, ?)";

        // Cập nhật thêm cả bảng seat gốc để chắc chắn 100% không trượt ở đâu
        String updateSeatSql = "UPDATE seat SET is_booked = TRUE WHERE id = ?";

        String getSeatNameSql = "SELECT row_name, seat_number FROM seat WHERE id = ?";
        // ĐÃ SỬA: Gọi cột 'seat_name' thay vì 'id' vì bảng showtime_seat không có khóa chính id
        String checkShowtimeSeatSql = "SELECT seat_name FROM showtime_seat WHERE showtime_id = ? AND seat_name = ? FOR UPDATE";
        String insertShowtimeSeatSql = "INSERT INTO showtime_seat (showtime_id, seat_name, status) VALUES (?, ?, 'BOOKED')";

        Connection conn = null;
        System.out.println("========== BẮT ĐẦU ĐẶT VÉ (TicketDAO) ==========");

        try {
            conn = DBContext.getConnection();
            conn.setAutoCommit(false); // Bắt đầu Transaction

            // 1. Lấy danh sách tên ghế từ ID vật lý và chuẩn hóa triệt để
            List<String> seatNames = new ArrayList<>();
            try (PreparedStatement psGetName = conn.prepareStatement(getSeatNameSql)) {
                for (int seatId : seatIds) {
                    psGetName.setInt(1, seatId);
                    try (ResultSet rsName = psGetName.executeQuery()) {
                        if (rsName.next()) {
                            // ĐÃ SỬA: Xóa khoảng trắng thừa và in hoa (Ví dụ: "E12 " -> "E12")
                            String sName = (rsName.getString("row_name").trim() + rsName.getInt("seat_number")).toUpperCase();
                            seatNames.add(sName);
                            System.out.println("-> Đã xác định ghế: " + sName);
                        } else {
                            conn.rollback();
                            return false;
                        }
                    }
                }
            }

            // 2. Khóa dòng & Kiểm tra xem có ai nhanh tay đặt ghế này chưa
            try (PreparedStatement psCheck = conn.prepareStatement(checkShowtimeSeatSql)) {
                for (String seatName : seatNames) {
                    psCheck.setInt(1, showtimeId);
                    psCheck.setString(2, seatName);
                    try (ResultSet rsCheck = psCheck.executeQuery()) {
                        if (rsCheck.next()) {
                            System.out.println("-> LỖI: Ghế " + seatName + " đã bị đặt trước!");
                            conn.rollback();
                            return false;
                        }
                    }
                }
            }

            // 3. Tính tiền và lưu bảng Booking
            double totalAmount = pricePerSeat * seatIds.size();
            String bookingCode = "BK" + System.currentTimeMillis();
            int bookingId = 0;

            try (PreparedStatement psBooking = conn.prepareStatement(insertBookingSql, PreparedStatement.RETURN_GENERATED_KEYS)) {
                psBooking.setInt(1, userId);
                psBooking.setInt(2, showtimeId);
                psBooking.setString(3, bookingCode);
                psBooking.setDouble(4, totalAmount);

                if (staffId > 0) {
                    psBooking.setInt(5, staffId);
                } else {
                    psBooking.setNull(5, java.sql.Types.INTEGER);
                }
                psBooking.executeUpdate();

                try (ResultSet rsKeys = psBooking.getGeneratedKeys()) {
                    if (rsKeys.next()) {
                        bookingId = rsKeys.getInt(1);
                        System.out.println("-> Đã tạo Booking ID: " + bookingId);
                    }
                }
            }

            // 4. Lưu từng vé chi tiết & Chèn trạng thái ghế vào CẢ 2 BẢNG (ticket, showtime_seat, seat)
            try (PreparedStatement psTicket = conn.prepareStatement(insertTicketSql);
                 PreparedStatement psShowtimeSeat = conn.prepareStatement(insertShowtimeSeatSql);
                 PreparedStatement psUpdateSeat = conn.prepareStatement(updateSeatSql)) {

                for (int i = 0; i < seatIds.size(); i++) {
                    int seatId = seatIds.get(i);
                    String seatName = seatNames.get(i);

                    // Batch cho bảng ticket
                    psTicket.setInt(1, bookingId);
                    psTicket.setInt(2, seatId);
                    psTicket.setDouble(3, pricePerSeat);
                    psTicket.addBatch();

                    // Batch cho bảng showtime_seat (Làm đỏ sơ đồ ghế theo suất chiếu)
                    psShowtimeSeat.setInt(1, showtimeId);
                    psShowtimeSeat.setString(2, seatName);
                    psShowtimeSeat.addBatch();

                    // Batch cho bảng seat gốc (Làm đỏ sơ đồ ghế nếu code đọc từ bảng seat)
                    psUpdateSeat.setInt(1, seatId);
                    psUpdateSeat.addBatch();
                }

                psTicket.executeBatch();
                psShowtimeSeat.executeBatch();
                psUpdateSeat.executeBatch();
                System.out.println("-> Đã insert dữ liệu vào Ticket, Showtime_Seat và Seat thành công!");
            }

            // 5. Giao dịch thành công hoàn hảo
            conn.commit();
            System.out.println("========== HOÀN TẤT GIAO DỊCH! GHẾ ĐÃ ĐỎ ==========");
            return true;

        } catch (SQLException e) {
            if (conn != null) {
                try { conn.rollback(); } catch (SQLException ex) { ex.printStackTrace(); }
            }
            System.out.println("-> LỖI SQL KHI ĐẶT VÉ: " + e.getMessage());
            e.printStackTrace();
            return false;
        } catch (Exception e) {
            System.out.println("-> LỖI HỆ THỐNG: " + e.getMessage());
            return false;
        } finally {
            if (conn != null) {
                try {
                    conn.setAutoCommit(true);
                    conn.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
        }
    }

    public int countTicketsByUser(int userId) {
        String sql = "SELECT COUNT(*) FROM booking WHERE user_id = ?";
        try {
            Connection conn = DBContext.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, userId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1);
            }
        } catch (Exception e) {
            System.out.println("Lỗi khi đếm số vé của User: " + e.getMessage());
        }
        return 0;
    }

    // ======================================================================
    // THÊM MỚI: Hàm lấy toàn bộ danh sách vé phục vụ cho trang Quản lý của Admin
    // ======================================================================
    public List<Ticket> getAllTickets() {
        List<Ticket> list = new ArrayList<>();
        String sql = "SELECT t.id, t.booking_id, t.seat_id, t.price, " +
                "b.user_id, b.showtime_id, b.booking_time, b.status AS booking_status, " +
                "m.title AS movie_title, r.name AS room_name, s.row_name, s.seat_number, u.username " +
                "FROM ticket t " +
                "JOIN booking b ON t.booking_id = b.id " +
                "JOIN showtime st ON b.showtime_id = st.id " +
                "JOIN movie m ON st.movie_id = m.id " +
                "JOIN room r ON st.room_id = r.id " +
                "JOIN seat s ON t.seat_id = s.id " +
                "JOIN users u ON b.user_id = u.id " +
                "ORDER BY b.booking_time DESC";

        try {
            Connection conn = DBContext.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Ticket ticket = new Ticket();
                ticket.setId(rs.getInt("id"));
                ticket.setShowtimeId(rs.getInt("showtime_id"));
                ticket.setSeatId(rs.getInt("seat_id"));
                ticket.setUserId(rs.getInt("user_id"));
                ticket.setPrice(rs.getDouble("price"));
                ticket.setBookingTime(rs.getTimestamp("booking_time"));

                // Mặc định set trạng thái thành 1 (Thành công) hoặc xử lý theo ý muốn
                ticket.setStatus(1);

                ticket.setMovieTitle(rs.getString("movie_title"));
                ticket.setRoomName(rs.getString("room_name"));
                ticket.setSeatName((rs.getString("row_name").trim() + rs.getInt("seat_number")).toUpperCase());
                ticket.setUserName(rs.getString("username"));

                list.add(ticket);
            }
            conn.close();
        } catch (Exception e) {
            System.out.println("Lỗi lấy danh sách vé cho Admin: " + e.getMessage());
        }
        return list;
    }
}