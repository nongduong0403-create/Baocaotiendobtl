package dal;

import model.Seat;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class SeatDAO {

    // 1. HÀM LẤY GHẾ THEO SUẤT CHIẾU (Xử lý logic so sánh 100% bằng Java)
    public List<Seat> getSeatsByShowtime(int showtimeId) {
        List<Seat> list = new ArrayList<>();
        try {
            Connection conn = DBContext.getConnection();

            // Bước 1.1: Tìm xem suất chiếu này đang chiếu ở phòng nào
            int roomId = 0;
            PreparedStatement ps1 = conn.prepareStatement("SELECT room_id FROM showtime WHERE id = ?");
            ps1.setInt(1, showtimeId);
            ResultSet rs1 = ps1.executeQuery();
            if (rs1.next()) {
                roomId = rs1.getInt("room_id");
            }

            // Bước 1.2: Lấy danh sách tên các ghế ĐÃ BÁN của riêng suất chiếu này
            List<String> bookedSeats = new ArrayList<>();
            PreparedStatement ps2 = conn.prepareStatement("SELECT seat_name FROM showtime_seat WHERE showtime_id = ?");
            ps2.setInt(1, showtimeId);
            ResultSet rs2 = ps2.executeQuery();
            while (rs2.next()) {
                String dbSeatName = rs2.getString("seat_name");
                if (dbSeatName != null) {
                    // ĐÃ FIX: Chuẩn hóa xóa khoảng trắng và ép in hoa từ Database
                    bookedSeats.add(dbSeatName.trim().toUpperCase());
                }
            }

            // Bước 1.3: Lấy toàn bộ ghế của phòng đó và tự kiểm tra trạng thái
            PreparedStatement ps3 = conn.prepareStatement("SELECT * FROM seat WHERE room_id = ?");
            ps3.setInt(1, roomId);
            ResultSet rs3 = ps3.executeQuery();
            while (rs3.next()) {
                int id = rs3.getInt("id");
                String rowName = rs3.getString("row_name");
                int seatNum = rs3.getInt("seat_number");
                String type = rs3.getString("type");

                // ĐÃ FIX: Ghép tên ghế và chuẩn hóa để khớp 100% với danh sách bookedSeats
                String seatName = (rowName.trim() + seatNum).toUpperCase();

                // Nếu tên ghế nằm trong danh sách đã bán -> BOOKED, ngược lại -> AVAILABLE
                String status = bookedSeats.contains(seatName) ? "BOOKED" : "AVAILABLE";

                list.add(new Seat(id, roomId, rowName, seatNum, type, status));
            }
            conn.close();
        } catch (Exception e) {
            System.out.println("Lỗi xử lý ghế Java: " + e.getMessage());
        }
        return list;
    }

    // 2. HÀM ĐẶT GHẾ (Lưu thẳng tên ghế vào CSDL)
    public void bookSeatForShowtime(int showtimeId, int seatId) {
        try {
            Connection conn = DBContext.getConnection();

            // Lấy tên ghế từ ID vật lý
            String seatName = "";
            PreparedStatement psName = conn.prepareStatement("SELECT row_name, seat_number FROM seat WHERE id = ?");
            psName.setInt(1, seatId);
            ResultSet rsName = psName.executeQuery();
            if(rsName.next()){
                // ĐÃ FIX: Chuẩn hóa tên ghế
                seatName = (rsName.getString("row_name").trim() + rsName.getInt("seat_number")).toUpperCase();
            }

            // Chèn vào bảng lịch sử đặt ghế
            String query = "INSERT INTO showtime_seat (showtime_id, seat_name, status) VALUES (?, ?, 'BOOKED')";
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, showtimeId);
            ps.setString(2, seatName);
            ps.executeUpdate();

            conn.close();
        } catch (Exception e) {
            System.out.println("Lỗi đặt ghế: " + e.getMessage());
        }
    }

    // 3. Lấy thông tin 1 ghế (Giữ nguyên)
    public Seat getSeatById(int seatId) {
        String sql = "SELECT * FROM seat WHERE id = ?";
        try {
            Connection conn = DBContext.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, seatId);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                Seat seat = new Seat(rs.getInt("id"), rs.getInt("room_id"), rs.getString("row_name"),
                        rs.getInt("seat_number"), rs.getString("type"), "AVAILABLE");
                conn.close();
                return seat;
            }
        } catch (Exception e) {
            System.out.println("Lỗi lấy 1 ghế: " + e.getMessage());
        }
        return null;
    }

    // 4. HÀM LƯU LẠI DỮ LIỆU GHẾ KHI KHÁCH ĐÃ THANH TOÁN THÀNH CÔNG
    public void bookSeatByName(int showtimeId, String seatName) {
        // Lưu thông tin vào bảng phụ để biết Suất chiếu nào - Ghế nào đã có người ngồi
        String query = "INSERT INTO showtime_seat (showtime_id, seat_name, status) VALUES (?, ?, 'BOOKED')";
        try {
            Connection conn = DBContext.getConnection();
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, showtimeId);
            // ĐÃ FIX: Chuẩn hóa mạnh tay tên ghế truyền vào
            ps.setString(2, seatName.trim().toUpperCase());
            ps.executeUpdate();
            conn.close();
        } catch (Exception e) {
            System.out.println("Lỗi lưu dữ liệu ghế: " + e.getMessage());
        }
    }

    // ======================================================================
    // 5. BỔ SUNG MỚI: HÀM LẤY DANH SÁCH GHẾ THEO PHÒNG CHO PHẦN ADMIN QUẢN LÝ
    // ======================================================================
    public List<Seat> getSeatsByRoomId(int roomId) {
        List<Seat> list = new ArrayList<>();
        String sql = "SELECT * FROM seat WHERE room_id = ?";
        try {
            Connection conn = DBContext.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, roomId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                int id = rs.getInt("id");
                String rowName = rs.getString("row_name");
                int seatNum = rs.getInt("seat_number");
                String type = rs.getString("type");

                // Sử dụng Constructor sẵn có của class Seat
                list.add(new Seat(id, roomId, rowName, seatNum, type, "AVAILABLE"));
            }
            conn.close();
        } catch (Exception e) {
            System.out.println("Lỗi lấy danh sách ghế theo phòng cho Admin: " + e.getMessage());
        }
        return list;
    }
}