package dal;

import model.Showtime;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import java.sql.Date;

public class ShowtimeDAO {

    // Hàm lấy danh sách CÁC NGÀY (dùng để làm tab ngày chiếu)
    public List<Date> getShowDatesByMovieId(int movieId) {
        List<Date> dates = new ArrayList<>();
        String sql = "SELECT DISTINCT show_date FROM showtime WHERE movie_id = ? AND show_date >= CURDATE() ORDER BY show_date";
        try {
            Connection conn = DBContext.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, movieId);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                dates.add(rs.getDate("show_date"));
            }
        } catch (Exception e) {
            System.out.println("Lỗi lấy ngày chiếu: " + e.getMessage());
        }
        return dates;
    }

    // Hàm lấy SUẤT CHIẾU THEO NGÀY
    public List<Showtime> getShowtimesByMovieAndDate(int movieId, Date showDate) {
        List<Showtime> list = new ArrayList<>();

        String sql = "SELECT s.id, s.movie_id, s.room_id, r.name AS room_name, " +
                "c.name AS cinema_name, s.show_date, s.show_time, s.price " +
                "FROM showtime s " +
                "JOIN room r ON s.room_id = r.id " +
                "JOIN cinema c ON r.cinema_id = c.id " +
                "WHERE s.movie_id = ? AND s.show_date = ? " +
                "ORDER BY c.name, s.show_time";

        try {
            Connection conn = DBContext.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, movieId);
            ps.setDate(2, showDate);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Showtime st = new Showtime();
                st.setId(rs.getInt("id"));
                st.setMovieId(rs.getInt("movie_id"));
                st.setRoomId(rs.getInt("room_id"));
                st.setRoomName(rs.getString("room_name"));
                st.setShowTime(rs.getString("show_time"));
                st.setCinemaName(rs.getString("cinema_name"));
                st.setShowDate(rs.getDate("show_date"));
                st.setPrice(rs.getInt("price"));

                list.add(st);
            }
        } catch (Exception e) {
            System.out.println("Lỗi lấy suất chiếu theo ngày: " + e.getMessage());
        }
        return list;
    }

    // [Bổ sung thêm hàm cũ này để fix lỗi Servlet gọi nhầm getShowtimesByMovieId]
    public List<Showtime> getShowtimesByMovieId(int movieId) {
        List<Showtime> list = new ArrayList<>();
        String sql = "SELECT s.id, s.movie_id, s.room_id, r.name AS room_name, " +
                "c.name AS cinema_name, s.show_date, s.show_time, s.price " +
                "FROM showtime s " +
                "JOIN room r ON s.room_id = r.id " +
                "JOIN cinema c ON r.cinema_id = c.id " +
                "WHERE s.movie_id = ? AND s.show_date >= CURDATE() " +
                "ORDER BY s.show_date, c.name, s.show_time";

        try {
            Connection conn = DBContext.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, movieId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Showtime st = new Showtime();
                st.setId(rs.getInt("id"));
                st.setMovieId(rs.getInt("movie_id"));
                st.setRoomId(rs.getInt("room_id"));
                st.setRoomName(rs.getString("room_name"));
                st.setShowTime(rs.getString("show_time"));
                st.setCinemaName(rs.getString("cinema_name"));
                st.setShowDate(rs.getDate("show_date"));
                st.setPrice(rs.getInt("price"));

                list.add(st);
            }
        } catch (Exception e) {
            System.out.println("Lỗi lấy suất chiếu: " + e.getMessage());
        }
        return list;
    }

    // Hàm lấy toàn bộ danh sách suất chiếu phục vụ cho trang Admin
    public List<Showtime> getAllShowtimes() {
        List<Showtime> list = new ArrayList<>();
        String sql = "SELECT s.id, s.movie_id, s.room_id, r.name AS room_name, " +
                "c.name AS cinema_name, s.show_date, s.show_time, s.price " +
                "FROM showtime s " +
                "JOIN room r ON s.room_id = r.id " +
                "JOIN cinema c ON r.cinema_id = c.id " +
                "ORDER BY s.show_date DESC, s.show_time DESC";

        try {
            Connection conn = DBContext.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Showtime st = new Showtime();
                st.setId(rs.getInt("id"));
                st.setMovieId(rs.getInt("movie_id"));
                st.setRoomId(rs.getInt("room_id"));
                st.setRoomName(rs.getString("room_name"));
                st.setShowTime(rs.getString("show_time"));
                st.setCinemaName(rs.getString("cinema_name"));
                st.setShowDate(rs.getDate("show_date"));
                st.setPrice(rs.getInt("price"));

                list.add(st);
            }
        } catch (Exception e) {
            System.out.println("Lỗi lấy toàn bộ suất chiếu cho admin: " + e.getMessage());
        }
        return list;
    }

    // ----------------------------------------------------------------------
    // CÁC HÀM THÊM / SỬA / XÓA LỊCH CHIẾU (DÀNH CHO ADMIN)
    // ----------------------------------------------------------------------

    // 1. Thêm lịch chiếu mới
    public void addShowtime(Showtime s) {
        String sql = "INSERT INTO showtime (movie_id, room_id, show_date, show_time, price) VALUES (?, ?, ?, ?, ?)";
        try {
            Connection conn = DBContext.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, s.getMovieId());
            ps.setInt(2, s.getRoomId());
            ps.setString(3, s.getShowDate().toString());
            ps.setString(4, s.getShowTime());
            ps.setInt(5, s.getPrice());
            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println("Lỗi thêm lịch chiếu: " + e.getMessage());
        }
    }

    // 2. Cập nhật lịch chiếu
    public void updateShowtime(Showtime s) {
        String sql = "UPDATE showtime SET movie_id = ?, room_id = ?, show_date = ?, show_time = ?, price = ? WHERE id = ?";
        try {
            Connection conn = DBContext.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, s.getMovieId());
            ps.setInt(2, s.getRoomId());
            ps.setString(3, s.getShowDate().toString());
            ps.setString(4, s.getShowTime());
            ps.setInt(5, s.getPrice());
            ps.setInt(6, s.getId());
            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println("Lỗi cập nhật lịch chiếu: " + e.getMessage());
        }
    }

    // 3. Xóa lịch chiếu
    public void deleteShowtime(int id) {
        String sql = "DELETE FROM showtime WHERE id = ?";
        try {
            Connection conn = DBContext.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);
            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println("Lỗi xóa lịch chiếu: " + e.getMessage());
        }
    }
}