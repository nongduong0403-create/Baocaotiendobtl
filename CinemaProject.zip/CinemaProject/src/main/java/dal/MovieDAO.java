package dal;

import model.Movie;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class MovieDAO {

    // Hàm lấy toàn bộ danh sách phim đang có (CHỈ LẤY NHỮNG PHIM CHƯA BỊ XÓA)
    public List<Movie> getAllMovies() {
        List<Movie> list = new ArrayList<>();
        // Đã thêm điều kiện is_deleted = FALSE
        String sql = "SELECT * FROM Movie WHERE is_deleted = FALSE";

        try {
            Connection conn = DBContext.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                // 1. Khởi tạo đối tượng phim với các thông tin cơ bản ban đầu
                Movie m = new Movie(
                        rs.getInt("id"),
                        rs.getString("title"),
                        rs.getString("poster_url"),
                        rs.getInt("duration"),
                        rs.getString("description")
                );

                // 2. Bổ sung 3 thuộc tính mới lấy từ Database
                m.setStatus(rs.getInt("status"));
                m.setAgeRating(rs.getString("age_rating"));
                m.setHot(rs.getBoolean("is_hot"));

                list.add(m);
            }
        } catch (Exception e) {
            System.out.println("Lỗi khi lấy danh sách phim: " + e.getMessage());
        }
        return list;
    }

    // Hàm lấy thông tin 1 bộ phim cụ thể dựa vào ID (CHỈ LẤY NẾU PHIM CHƯA BỊ XÓA)
    public Movie getMovieById(int id) {
        // Đã thêm điều kiện is_deleted = FALSE
        String sql = "SELECT * FROM Movie WHERE id = ? AND is_deleted = FALSE";
        try {
            Connection conn = DBContext.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                // 1. Khởi tạo đối tượng phim với các thông tin cơ bản ban đầu
                Movie m = new Movie(
                        rs.getInt("id"),
                        rs.getString("title"),
                        rs.getString("poster_url"),
                        rs.getInt("duration"),
                        rs.getString("description")
                );

                // 2. Bổ sung 3 thuộc tính mới lấy từ Database
                m.setStatus(rs.getInt("status"));
                m.setAgeRating(rs.getString("age_rating"));
                m.setHot(rs.getBoolean("is_hot"));

                return m;
            }
        } catch (Exception e) {
            System.out.println("Lỗi tìm phim: " + e.getMessage());
        }
        return null;
    }

    // ----------------------------------------------------------------------
    // THÊM MỚI: Hàm Xóa mềm (Soft Delete) - Ẩn phim thay vì xóa vĩnh viễn
    // ----------------------------------------------------------------------
    public void deleteMovie(int id) {
        String sql = "UPDATE Movie SET is_deleted = TRUE WHERE id = ?";
        try {
            Connection conn = DBContext.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, id);

            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Đã xóa mềm thành công phim có ID: " + id);
            }
        } catch (Exception e) {
            System.out.println("Lỗi khi xóa mềm phim: " + e.getMessage());
        }
    }

    // Hàm lấy phim theo Trạng thái (1: Đang chiếu, 2: Sắp chiếu, 3: Chiếu sớm)
    public List<Movie> getMoviesByStatus(int status) {
        List<Movie> list = new ArrayList<>();
        // Lọc theo cột status và bỏ qua phim đã xóa
        String sql = "SELECT * FROM movie WHERE status = ? AND is_deleted = FALSE ORDER BY id DESC";

        try {
            Connection conn = DBContext.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setInt(1, status);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Movie m = new Movie(
                        rs.getInt("id"),
                        rs.getString("title"),
                        rs.getString("poster_url"),
                        rs.getInt("duration"),
                        rs.getString("description")
                );
                m.setStatus(rs.getInt("status"));
                m.setAgeRating(rs.getString("age_rating"));
                m.setHot(rs.getBoolean("is_hot"));
                list.add(m);
            }
        } catch (Exception e) {
            System.out.println("Lỗi khi lọc phim theo trạng thái: " + e.getMessage());
        }
        return list;
    }

    // ----------------------------------------------------------------------
    // THÊM MỚI: Hàm Thêm phim (Insert)
    // ----------------------------------------------------------------------
    public void addMovie(Movie m) {
        String sql = "INSERT INTO Movie (title, poster_url, duration, status, age_rating, is_hot, description) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try {
            Connection conn = DBContext.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, m.getTitle());
            ps.setString(2, m.getPosterUrl());
            ps.setInt(3, m.getDuration());
            ps.setInt(4, m.getStatus());
            ps.setString(5, m.getAgeRating());
            ps.setBoolean(6, m.isHot());
            ps.setString(7, m.getDescription());

            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println("Lỗi khi thêm phim mới: " + e.getMessage());
        }
    }

    // ----------------------------------------------------------------------
    // THÊM MỚI: Hàm Cập nhật phim (Update)
    // ----------------------------------------------------------------------
    public void updateMovie(Movie m) {
        String sql = "UPDATE Movie SET title = ?, poster_url = ?, duration = ?, status = ?, age_rating = ?, is_hot = ?, description = ? WHERE id = ?";
        try {
            Connection conn = DBContext.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, m.getTitle());
            ps.setString(2, m.getPosterUrl());
            ps.setInt(3, m.getDuration());
            ps.setInt(4, m.getStatus());
            ps.setString(5, m.getAgeRating());
            ps.setBoolean(6, m.isHot());
            ps.setString(7, m.getDescription());
            ps.setInt(8, m.getId());

            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println("Lỗi khi cập nhật phim: " + e.getMessage());
        }
    }
}