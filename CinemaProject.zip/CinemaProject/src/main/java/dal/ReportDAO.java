package dal;

import model.Ticket; // Hoặc tạo một Model/DTO riêng nếu cần
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ReportDAO {

    // 1. Lấy tổng doanh thu toàn hệ thống
    public double getTotalRevenue() {
        double total = 0;
        String sql = "SELECT SUM(total_amount) FROM booking WHERE status = 'PAID'";
        try {
            Connection conn = DBContext.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                total = rs.getDouble(1);
            }
            conn.close();
        } catch (Exception e) {
            System.out.println("Lỗi tính tổng doanh thu: " + e.getMessage());
        }
        return total;
    }

    // 2. Lấy tổng số vé đã bán thành công
    public int getTotalTicketsSold() {
        int count = 0;
        String sql = "SELECT COUNT(t.id) FROM ticket t JOIN booking b ON t.booking_id = b.id WHERE b.status = 'PAID'";
        try {
            Connection conn = DBContext.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                count = rs.getInt(1);
            }
            conn.close();
        } catch (Exception e) {
            System.out.println("Lỗi đếm số vé bán ra: " + e.getMessage());
        }
        return count;
    }

    // 3. Lấy danh sách doanh thu chi tiết theo từng đơn hàng/booking
    public List<String[]> getRevenueDetails() {
        List<String[]> list = new ArrayList<>();
        String sql = "SELECT b.booking_code, u.username, m.title, b.total_amount, b.booking_time " +
                "FROM booking b " +
                "JOIN user u ON b.user_id = u.id " +
                "JOIN showtime st ON b.showtime_id = st.id " +
                "JOIN movie m ON st.movie_id = m.id " +
                "WHERE b.status = 'PAID' " +
                "ORDER BY b.booking_time DESC";
        try {
            Connection conn = DBContext.getConnection();
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String[] row = {
                        rs.getString("booking_code"),
                        rs.getString("username"),
                        rs.getString("title"),
                        String.format("%,.0f đ", rs.getDouble("total_amount")),
                        rs.getString("booking_time")
                };
                list.add(row);
            }
            conn.close();
        } catch (Exception e) {
            System.out.println("Lỗi lấy chi tiết doanh thu: " + e.getMessage());
        }
        return list;
    }
}