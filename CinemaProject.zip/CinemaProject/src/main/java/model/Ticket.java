package model;

import java.sql.Timestamp;

public class Ticket {
    private int id;
    private int showtimeId;
    private int seatId;
    private int userId;
    private double price;
    private Timestamp bookingTime;
    private int status; // Ví dụ: 0 - Đã hủy, 1 - Đã đặt/Thành công

    // Các thuộc tính mở rộng phục vụ hiển thị
    private String movieTitle;
    private String roomName;
    private String seatName;
    private String userName;

    public Ticket() {
    }

    public Ticket(int id, int showtimeId, int seatId, int userId, double price, Timestamp bookingTime, int status) {
        this.id = id;
        this.showtimeId = showtimeId;
        this.seatId = seatId;
        this.userId = userId;
        this.price = price;
        this.bookingTime = bookingTime;
        this.status = status;
    }

    // --- GETTER VÀ SETTER ---
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public int getShowtimeId() { return showtimeId; }
    public void setShowtimeId(int showtimeId) { this.showtimeId = showtimeId; }

    public int getSeatId() { return seatId; }
    public void setSeatId(int seatId) { this.seatId = seatId; }

    public int getUserId() { return userId; }
    public void setUserId(int userId) { this.userId = userId; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public Timestamp getBookingTime() { return bookingTime; }
    public void setBookingTime(Timestamp bookingTime) { this.bookingTime = bookingTime; }

    public int getStatus() { return status; }
    public void setStatus(int status) { this.status = status; }

    public String getMovieTitle() { return movieTitle; }
    public void setMovieTitle(String movieTitle) { this.movieTitle = movieTitle; }

    public String getRoomName() { return roomName; }
    public void setRoomName(String roomName) { this.roomName = roomName; }

    public String getSeatName() { return seatName; }
    public void setSeatName(String seatName) { this.seatName = seatName; }

    public String getUserName() { return userName; }
    public void setUserName(String userName) { this.userName = userName; }
}