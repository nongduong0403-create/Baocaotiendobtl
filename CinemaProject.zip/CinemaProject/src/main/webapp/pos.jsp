<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<html>
<head>
    <title>Quầy Bán Vé (POS) - Hệ Thống Rạp Chiếu Phim</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

    <!-- Bootstrap 5 & FontAwesome -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">

    <style>
        body { background-color: #f4f7f6; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .pos-container { max-width: 950px; margin: 40px auto; }
        .pos-card { border: none; border-radius: 16px; box-shadow: 0 10px 30px rgba(0,0,0,0.08); background: #ffffff; }
        .header-section { background: linear-gradient(135deg, #198754, #157347); color: white; border-radius: 16px 16px 0 0; padding: 25px; }
        .action-box { border-radius: 12px; transition: all 0.2s ease; }
        .action-box:hover { transform: translateY(-3px); box-shadow: 0 6px 15px rgba(0,0,0,0.05); }
        .btn-active:active { transform: scale(0.97); }
    </style>
</head>
<body>

<div class="container pos-container px-3">
    <div class="pos-card">

        <!-- Header rực rỡ mang phong cách POS chuyên nghiệp -->
        <div class="header-section d-flex justify-content-between align-items-center flex-wrap gap-2">
            <div>
                <h3 class="fw-bold mb-1"><i class="fa-solid fa-cash-register me-2"></i> QUẦY BÁN VÉ TRỰC TIẾP (POS)</h3>
                <p class="mb-0 text-white-50 small">Hệ thống soát vé tại cửa & Bán vé nhanh cho khách vãng lai</p>
            </div>
            <div class="d-flex align-items-center gap-2">
                <!-- NÚT HỖ TRỢ KHÁCH HÀNG MỚI THÊM VÀO -->
                <a href="${pageContext.request.contextPath}/staff/support.jsp" class="btn btn-light text-primary px-3 py-2 rounded-pill fw-bold shadow-sm btn-active small">
                    <i class="fa-solid fa-headset me-1"></i> Hỗ trợ
                </a>

                <!-- Nút quay lại Dashboard nhân viên -->
                <a href="${pageContext.request.contextPath}/staff/dashboard" class="btn btn-light text-success px-3 py-2 rounded-pill fw-bold shadow-sm btn-active small">
                    <i class="fa-solid fa-chart-line me-1"></i> Dashboard
                </a>

                <span class="badge bg-light text-success px-3 py-2 rounded-pill fw-bold">
                    <i class="fa-solid fa-user-shield me-1"></i> ${sessionScope.user.fullName}
                </span>
            </div>
        </div>

        <div class="p-4">
            <!-- THÔNG BÁO THÀNH CÔNG -->
            <c:if test="${not empty param.successMsg}">
                <div class="alert alert-success alert-dismissible fade show d-flex align-items-center shadow-sm" role="alert">
                    <i class="fa-solid fa-circle-check fs-5 me-2"></i>
                    <div>${param.successMsg}</div>
                    <button type="button" class="btn-close ms-auto" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            </c:if>

            <div class="row g-4 mt-1">
                <!-- CỘT 1: KIỂM TRA VÉ & SOÁT VÉ -->
                <div class="col-12 col-md-6">
                    <div class="card p-4 bg-white border border-success-subtle shadow-sm action-box h-100 d-flex flex-column">
                        <div class="d-flex align-items-center mb-3">
                            <div class="bg-success text-white rounded-circle p-2 me-2 d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                                <i class="fa-solid fa-qrcode fs-5"></i>
                            </div>
                            <h5 class="fw-bold text-success mb-0">Kiểm tra & Soát vé</h5>
                        </div>
                        <p class="text-muted small mb-3">Nhập mã vé hoặc mã giao dịch để xác thực khách vào phòng chiếu.</p>

                        <!-- Form Tìm kiếm -->
                        <form action="${pageContext.request.contextPath}/PosServlet" method="GET" class="mt-auto">
                            <div class="input-group mb-2">
                                <input type="text" class="form-control" name="ticketCode" placeholder="VD: BK-1 hoặc 1..." required value="${param.ticketCode}">
                                <button class="btn btn-success fw-bold px-3 btn-active" type="submit">
                                    <i class="fa-solid fa-magnifying-glass"></i> Kiểm tra
                                </button>
                            </div>
                        </form>

                        <!-- THÔNG BÁO LỖI NẾU KHÔNG TÌM THẤY -->
                        <c:if test="${not empty errorMsg}">
                            <div class="alert alert-danger py-2 small mt-2 mb-0 text-center fw-bold">
                                <i class="fa-solid fa-triangle-exclamation"></i> ${errorMsg}
                            </div>
                        </c:if>

                        <!-- KẾT QUẢ TÌM KIẾM VÉ -->
                        <c:if test="${not empty bookingId}">
                            <div class="p-3 bg-light border border-secondary-subtle rounded mt-3 text-start small">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <span class="fw-bold text-success fs-6">Đơn hàng: #BK-${bookingId}</span>
                                    <span class="badge bg-${status == 'PAID' ? 'success' : (status == 'USED' ? 'secondary' : 'warning')} px-2 py-1">
                                            ${status}
                                    </span>
                                </div>
                                <hr class="my-1">
                                <p class="mb-1"><b>Ghế ngồi:</b> <span class="text-danger fw-bold fs-6">${seats}</span></p>
                                <p class="mb-1"><b>Suất chiếu:</b> ${showDate} (${showTime})</p>
                                <p class="mb-2"><b>Tổng tiền:</b> <span class="text-primary fw-bold">${totalAmount} đ</span></p>

                                <c:choose>
                                    <c:when test="${status == 'PAID'}">
                                        <form action="${pageContext.request.contextPath}/PosServlet" method="POST" class="mt-2">
                                            <input type="hidden" name="bookingId" value="${bookingId}">
                                            <button type="submit" class="btn btn-warning w-100 fw-bold btn-sm btn-active text-dark py-2 shadow-sm">
                                                <i class="fa-solid fa-check-to-slot me-1"></i> XÁC NHẬN CHECK-IN (CHO VÀO RẠP)
                                            </button>
                                        </form>
                                    </c:when>
                                    <c:when test="${status == 'USED'}">
                                        <div class="alert alert-secondary text-center mb-0 py-1 fw-bold">⚠️ Vé này đã được sử dụng rồi!</div>
                                    </c:when>
                                    <c:otherwise>
                                        <div class="alert alert-warning text-center mb-0 py-1 fw-bold">⚠️ Vé chưa thanh toán hoặc đã hủy!</div>
                                    </c:otherwise>
                                </c:choose>
                            </div>
                        </c:if>
                    </div>
                </div>

                <!-- CỘT 2: BÁN VÉ NHANH TẠI QUẦY -->
                <div class="col-12 col-md-6">
                    <div class="card p-4 bg-white border border-warning-subtle shadow-sm action-box h-100 d-flex flex-column">
                        <div class="d-flex align-items-center mb-3">
                            <div class="bg-warning text-dark rounded-circle p-2 me-2 d-flex align-items-center justify-content-center" style="width: 40px; height: 40px;">
                                <i class="fa-solid fa-ticket fs-5"></i>
                            </div>
                            <h5 class="fw-bold text-dark mb-0">Bán vé tại quầy</h5>
                        </div>
                        <p class="text-muted small mb-3 flex-grow-1">Mở sơ đồ ghế trực tiếp, chọn chỗ ngồi và thanh toán tiền mặt/chuyển khoản cho khách vãng lai tại rạp.</p>

                        <div class="mt-auto">
                            <!-- CHỈ ĐỊNH ĐƯỜNG DẪN TUYỆT ĐỐI VỀ TRANG CHỦ -->
                            <a href="${pageContext.request.contextPath}/home" class="btn btn-warning btn-active fw-bold w-100 text-dark py-2 shadow-sm">
                                <i class="fa-solid fa-chair me-1"></i> Mở sơ đồ ghế rạp
                            </a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Nút đăng xuất cuối trang -->
            <div class="mt-4 pt-3 border-top text-end">
                <a href="${pageContext.request.contextPath}/logout" class="btn btn-outline-danger px-4 fw-bold btn-active">
                    <i class="fa-solid fa-right-from-bracket me-1"></i> Đăng xuất
                </a>
            </div>
        </div>

    </div>
</div>

<!-- Bootstrap JS Bundle -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>