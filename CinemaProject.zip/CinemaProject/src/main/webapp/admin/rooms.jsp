<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Quản Lý Rạp & Phòng Chiếu - Cinema Portal</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { background-color: #f8fafc; color: #1e293b; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .wrapper { display: flex; width: 100%; align-items: stretch; min-height: 100vh; }

        /* SIDEBAR CHUYÊN NGHIỆP BÊN TRÁI (LIGHT MODE) */
        #sidebar { min-width: 260px; max-width: 260px; background: #ffffff; color: #1e293b; border-right: 1px solid #e2e8f0; box-shadow: 2px 0 10px rgba(0,0,0,0.02); }
        #sidebar .sidebar-header { padding: 20px; background: #ffffff; font-weight: bold; font-size: 1.1rem; border-bottom: 1px solid #e2e8f0; color: #0f172a; }
        #sidebar ul.components { padding: 15px 0; }
        #sidebar ul li a { padding: 12px 20px; font-size: 0.9rem; display: block; color: #64748b; text-decoration: none; transition: 0.2s; }
        #sidebar ul li a:hover, #sidebar ul li.active a { color: #fff; background: #dc3545; border-radius: 0 25px 25px 0; margin-right: 15px; }
        #sidebar ul li a i { margin-right: 10px; width: 20px; }

        /* NỘI DUNG CHÍNH */
        #content { width: 100%; padding: 30px; }
        .admin-card { background-color: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.03); }

        /* BẢNG DỮ LIỆU LIGHT MODE */
        .table-light-custom { background-color: #ffffff; color: #1e293b; }
        .table-light-custom th { color: #b45309; border-bottom: 2px solid #e2e8f0; background-color: #ffffff; }
        .table-light-custom td { border-color: #f1f5f9; vertical-align: middle; color: #1e293b; }

        /* FORM INPUT SÁNG MÀU */
        .form-control-light { background-color: #f8fafc; color: #1e293b; border: 1px solid #cbd5e1; }
        .form-control-light:focus { background-color: #ffffff; color: #1e293b; border-color: #fbbf24; box-shadow: 0 0 0 0.25rem rgba(251, 191, 36, 0.25); }
    </style>
</head>
<body>

<div class="wrapper">
    <!-- SIDEBAR CHUẨN ĐẦY ĐỦ CÁC MỤC -->
    <nav id="sidebar">
        <!-- TIÊU ĐỀ SIDEBAR LINH HOẠT THEO ROLE -->
        <div class="sidebar-header">
            <i class="fa-solid fa-shield-halved text-danger me-2"></i>
            <c:choose>
                <c:when test="${sessionScope.user.role == 'MANAGER'}">ADMIN PORTAL</c:when>
                <c:when test="${sessionScope.user.role == 'ADMIN'}">MANAGER PORTAL</c:when>
                <c:otherwise>MANAGEMENT PORTAL</c:otherwise>
            </c:choose>
        </div>
        <ul class="list-unstyled components">
            <li class="active">
                <a href="${pageContext.request.contextPath}/AdminServlet"><i class="fa-solid fa-building"></i> Quản lý rạp, phòng, ghế</a>
            </li>
            <li>
                <a href="${pageContext.request.contextPath}/admin/movies"><i class="fa-solid fa-film"></i> Quản lý phim, thể loại</a>
            </li>
            <li>
                <a href="${pageContext.request.contextPath}/admin/showtimes"><i class="fa-solid fa-calendar-days"></i> Quản lý lịch chiếu</a>
            </li>
            <li>
                <a href="${pageContext.request.contextPath}/admin/tickets"><i class="fa-solid fa-ticket"></i> Quản lý đặt vé</a>
            </li>
            <c:if test="${sessionScope.user.role == 'ADMIN'}">
                <li>
                    <a href="${pageContext.request.contextPath}/admin/users"><i class="fa-solid fa-users"></i> Khách hàng & Nhân viên</a>
                </li>
                <li>
                    <a href="${pageContext.request.contextPath}/admin/reports"><i class="fa-solid fa-chart-line"></i> Báo cáo doanh thu</a>
                </li>
            </c:if>
            <hr class="text-secondary mx-3">
            <li>
                <a href="${pageContext.request.contextPath}/logout" class="text-danger"><i class="fa-solid fa-right-from-bracket"></i> Đăng xuất</a>
            </li>
        </ul>
    </nav>

    <!-- NỘI DUNG QUẢN LÝ RẠP -->
    <div id="content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="fw-bold text-dark mb-1"><i class="fa-solid fa-building text-warning me-2"></i> Quản lý Rạp, Phòng & Ghế Chiếu</h3>
                <p class="text-muted small mb-0">Thêm mới, cấu hình phòng chiếu và sơ đồ ghế ngồi trong hệ thống.</p>
            </div>

            <!-- BADGE HIỂN THỊ ĐỘNG ADMIN HOẶC QUẢN LÝ -->
            <div class="bg-white px-3 py-2 rounded-pill shadow-sm border border-secondary-subtle d-flex align-items-center">
                <i class="fa-solid fa-user-shield text-danger me-2"></i>
                <span class="text-secondary fw-semibold me-1">
                    <c:choose>
                        <c:when test="${sessionScope.user.role == 'ADMIN'}">Quản lý:</c:when>
                        <c:when test="${sessionScope.user.role == 'MANAGER'}">admin:</c:when>
                        <c:otherwise>Tài khoản:</c:otherwise>
                    </c:choose>
                </span>
                <strong class="text-dark">
                    <c:choose>
                        <c:when test="${not empty sessionScope.user.fullName}">
                            ${sessionScope.user.fullName}
                        </c:when>
                        <c:otherwise>
                            ${sessionScope.user.username}
                        </c:otherwise>
                    </c:choose>
                </strong>
            </div>
        </div>

        <!-- Khu vực Thêm Rạp Mới -->
        <div class="admin-card p-4 mb-4">
            <h5 class="text-warning mb-3 fw-bold"><i class="fa-solid fa-plus-circle me-1"></i> Thêm Phòng / Rạp Mới</h5>
            <form action="${pageContext.request.contextPath}/AdminServlet" method="post" class="d-flex gap-3 align-items-center flex-wrap">
                <input type="text" class="form-control form-control-light w-50" name="roomName" required placeholder="Nhập tên phòng chiếu (VD: Phòng VIP 01)...">
                <button type="submit" class="btn btn-warning fw-bold px-4 text-dark shadow-sm">
                    <i class="fa-solid fa-check me-1"></i> Thêm Rạp
                </button>
            </form>
        </div>

        <!-- Khu vực Danh sách Rạp -->
        <div class="admin-card p-4">
            <h5 class="text-warning mb-3 fw-bold"><i class="fa-solid fa-list-ul me-1"></i> Danh Sách Các Phòng Chiếu Đang Hoạt Động</h5>

            <div class="table-responsive">
                <table class="table table-light-custom table-hover text-center align-middle mb-0">
                    <thead>
                    <tr>
                        <th style="width: 100px;">Mã Phòng</th>
                        <th class="text-start ps-4">Tên Phòng / Rạp</th>
                        <th style="width: 300px;">Thao tác quản trị</th>
                    </tr>
                    </thead>
                    <tbody>
                    <c:forEach items="${roomList}" var="r">
                        <tr>
                            <td class="fw-bold text-warning">#${r.id}</td>
                            <td class="fw-bold text-dark text-start ps-4"><i class="fa-solid fa-door-open text-secondary me-2"></i> ${r.name}</td>
                            <td>
                                <!-- Nút cấu hình ghế rạp -->
                                <a href="${pageContext.request.contextPath}/admin/room-seats?roomId=${r.id}" class="btn btn-outline-info btn-sm fw-bold me-2">
                                    <i class="fa-solid fa-chair"></i> Sơ đồ ghế
                                </a>
                                <!-- Nút xóa rạp -->
                                <a href="deleteRoom?id=${r.id}" onclick="return confirm('CẢNH BÁO: Xóa rạp này sẽ ảnh hưởng tới suất chiếu và ghế bên trong. Bạn chắc chứ?');" class="btn btn-outline-danger btn-sm fw-bold">
                                    <i class="fa-solid fa-trash-can"></i> Xóa
                                </a>
                            </td>
                        </tr>
                    </c:forEach>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>