<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Cấu Hình Sơ Đồ Ghế - Admin Portal</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { background-color: #f8fafc; color: #1e293b; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .wrapper { display: flex; width: 100%; align-items: stretch; min-height: 100vh; }
        #sidebar { min-width: 260px; max-width: 260px; background: #ffffff; color: #1e293b; border-right: 1px solid #e2e8f0; box-shadow: 2px 0 10px rgba(0,0,0,0.02); }
        #sidebar .sidebar-header { padding: 20px; background: #ffffff; font-weight: bold; font-size: 1.1rem; border-bottom: 1px solid #e2e8f0; color: #0f172a; }
        #sidebar ul.components { padding: 15px 0; }
        #sidebar ul li a { padding: 12px 20px; font-size: 0.9rem; display: block; color: #64748b; text-decoration: none; transition: 0.2s; }
        #sidebar ul li a:hover, #sidebar ul li.active a { color: #fff; background: #dc3545; border-radius: 0 25px 25px 0; margin-right: 15px; }
        #sidebar ul li a i { margin-right: 10px; width: 20px; }
        #content { width: 100%; padding: 30px; }
        .admin-card { background-color: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.03); }

        /* STYLE CHUẨN XÁC KHỚP VỚI GIAO DIỆN SÁNG */
        .screen-bar { background: linear-gradient(to bottom, #cbd5e1, #94a3b8); color: #0f172a; letter-spacing: 3px; font-weight: bold; border-radius: 6px; box-shadow: 0 4px 10px rgba(0,0,0,0.05); }
        .seat-item { width: 34px; height: 32px; display: inline-flex; align-items: center; justify-content: center; font-size: 0.7rem; font-weight: bold; border-radius: 4px; margin: 2px; border: 1px solid #cbd5e1; background-color: #f1f5f9; color: #1e293b; }
        .seat-item.vip { background-color: #dc3545; border-color: #b91c1c; color: #fff; }
    </style>
</head>
<body>

<div class="wrapper">
    <!-- SIDEBAR CHUẨN ĐẦY ĐỦ CÁC MỤC -->
    <nav id="sidebar">
        <div class="sidebar-header">
            <i class="fa-solid fa-shield-halved text-danger me-2"></i>
            <c:choose>
                <c:when test="${sessionScope.user.role == 'ADMIN'}">ADMIN PORTAL</c:when>
                <c:when test="${sessionScope.user.role == 'MANAGER'}">MANAGER PORTAL</c:when>
                <c:otherwise>MANAGEMENT PORTAL</c:otherwise>
            </c:choose>
        </div>
        <ul class="list-unstyled components">
            <li class="active">
                <a href="${pageContext.request.contextPath}/AdminServlet"><i class="fa-solid fa-building"></i> Quản lý rạp, phòng, ghế</a>
            </li>
            <li>
                <a href="${pageContext.request.contextPath}/admin/movies"><i class="fa-solid fa-film"></i> Quản lý phim, thể loại</a>
            </li>
            <li>
                <a href="${pageContext.request.contextPath}/admin/showtimes"><i class="fa-solid fa-calendar-days"></i> Quản lý lịch chiếu</a>
            </li>
            <li>
                <a href="${pageContext.request.contextPath}/admin/tickets"><i class="fa-solid fa-ticket"></i> Quản lý đặt vé</a>
            </li>
            <c:if test="${sessionScope.user.role == 'ADMIN'}">
                <li>
                    <a href="${pageContext.request.contextPath}/admin/users"><i class="fa-solid fa-users"></i> Khách hàng & Nhân viên</a>
                </li>
                <li>
                    <a href="${pageContext.request.contextPath}/admin/reports"><i class="fa-solid fa-chart-line"></i> Báo cáo doanh thu</a>
                </li>
            </c:if>
            <hr class="text-secondary mx-3">
            <li>
                <a href="${pageContext.request.contextPath}/logout" class="text-danger"><i class="fa-solid fa-right-from-bracket"></i> Đăng xuất</a>
            </li>
        </ul>
    </nav>

    <!-- NỘI DUNG CHÍNH -->
    <div id="content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="fw-bold text-dark mb-1"><i class="fa-solid fa-chair text-warning me-2"></i> Sơ Đồ Ghế Thực Tế Của Phòng #${roomId}</h3>
                <p class="text-muted small mb-0">Hiển thị phân loại hàng ghế đồng bộ với phía khách hàng.</p>
            </div>
            <a href="${pageContext.request.contextPath}/AdminServlet" class="btn btn-outline-secondary btn-sm fw-bold">
                <i class="fa-solid fa-arrow-left me-1"></i> Quay lại danh sách rạp
            </a>
        </div>

        <div class="admin-card p-4 text-center">
            <!-- MÀN HÌNH CHIẾU -->
            <div class="screen-bar py-2 mb-5 mx-auto w-75 text-uppercase">
                Màn Hình Chiếu (Screen)
            </div>

            <!-- HIỂN THỊ GHẾ THEO TỪNG HÀNG NGANG (ROW) -->
            <div class="seat-container p-3 d-flex flex-column align-items-center">
                <c:choose>
                <c:when test="${not empty seatList}">
                <c:set var="currentRow" value="" />
                <c:forEach items="${seatList}" var="s">
                <c:if test="${currentRow != s.rowName}">
                <c:if test="${not empty currentRow}">
            </div> <!-- đóng hàng trước -->
            </c:if>
            <c:set var="currentRow" value="${s.rowName}" />
            <div class="d-flex justify-content-center align-items-center mb-1">
                <span class="fw-bold text-danger me-3" style="width: 20px; text-align: right;">${s.rowName}</span>
                </c:if>
                <div class="seat-item ${s.type == 'VIP' || s.type == 'vip' ? 'vip' : ''}" title="${s.rowName}${s.seatNumber} - ${s.type}">
                        ${s.rowName}${s.seatNumber}
                </div>
                </c:forEach>
            </div> <!-- đóng hàng cuối cùng -->
            </c:when>
            <c:otherwise>
                <div class="text-warning py-4">
                    <i class="fa-solid fa-triangle-exclamation me-1"></i> Chưa có dữ liệu ghế nào được khởi tạo trong database cho phòng này!
                </div>
            </c:otherwise>
            </c:choose>
        </div>
    </div>
</div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>