<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Quản Lý Khách Hàng & Nhân Viên - Admin Portal</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { background-color: #f8fafc; color: #1e293b; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .wrapper { display: flex; width: 100%; align-items: stretch; min-height: 100vh; }
        #sidebar { min-width: 260px; max-width: 260px; background: #ffffff; color: #1e293b; border-right: 1px solid #e2e8f0; box-shadow: 2px 0 10px rgba(0,0,0,0.02); }
        #sidebar .sidebar-header { padding: 20px; background: #ffffff; font-weight: bold; font-size: 1.1rem; border-bottom: 1px solid #e2e8f0; color: #0f172a; }
        #sidebar ul.components { padding: 15px 0; }
        #sidebar ul li a { padding: 12px 20px; font-size: 0.9rem; display: block; color: #64748b; text-decoration: none; transition: 0.2s; }
        #sidebar ul li a:hover, #sidebar ul li.active a { color: #fff; background: #dc3545; border-radius: 0 25px 25px 0; margin-right: 15px; }
        #sidebar ul li a i { margin-right: 10px; width: 20px; }
        #content { width: 100%; padding: 30px; }
        .admin-card { background-color: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.03); }
        .table-light-custom { background-color: #ffffff; color: #1e293b; }
        .table-light-custom th, .table-light-custom td { background-color: #ffffff !important; color: #1e293b !important; border-color: #f1f5f9 !important; vertical-align: middle; }
    </style>
</head>
<body>

<div class="wrapper">
    <!-- SIDEBAR CHUẨN ĐẦY ĐỦ CÁC MỤC -->
    <nav id="sidebar">
        <div class="sidebar-header">
            <i class="fa-solid fa-shield-halved text-danger me-2"></i> MANAGER PORTAL
        </div>
        <ul class="list-unstyled components">
            <li>
                <a href="${pageContext.request.contextPath}/AdminServlet"><i class="fa-solid fa-building"></i> Quản lý rạp, phòng, ghế</a>
            </li>
            <li>
                <a href="${pageContext.request.contextPath}/admin/movies"><i class="fa-solid fa-film"></i> Quản lý phim, thể loại</a>
            </li>
            <li>
                <a href="${pageContext.request.contextPath}/admin/showtimes"><i class="fa-solid fa-calendar-days"></i> Quản lý lịch chiếu</a>
            </li>
            <li>
                <a href="${pageContext.request.contextPath}/admin/tickets"><i class="fa-solid fa-ticket"></i> Quản lý đặt vé</a>
            </li>
            <c:if test="${sessionScope.user.role == 'ADMIN'}">
                <li class="active">
                    <a href="${pageContext.request.contextPath}/admin/users"><i class="fa-solid fa-users"></i> Khách hàng & Nhân viên</a>
                </li>
                <li>
                    <a href="${pageContext.request.contextPath}/admin/reports"><i class="fa-solid fa-chart-line"></i> Báo cáo doanh thu</a>
                </li>
            </c:if>
            <hr class="text-secondary mx-3">
            <li>
                <a href="${pageContext.request.contextPath}/logout" class="text-danger"><i class="fa-solid fa-right-from-bracket"></i> Đăng xuất</a>
            </li>
        </ul>
    </nav>

    <!-- NỘI DUNG CHÍNH -->
    <div id="content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="fw-bold text-dark mb-1"><i class="fa-solid fa-users text-warning me-2"></i> Quản Lý Tài Khoản</h3>
                <p class="text-muted small mb-0">Quản lý danh sách khách hàng, nhân viên và phân quyền hệ thống.</p>
            </div>
            <!-- Nút bật Modal Thêm Tài Khoản -->
            <button class="btn btn-danger btn-sm fw-bold" data-bs-toggle="modal" data-bs-target="#addUserModal">
                <i class="fa-solid fa-user-plus me-1"></i> Thêm Tài Khoản Mới
            </button>
        </div>

        <div class="admin-card p-4">
            <div class="table-responsive">
                <table class="table table-light-custom table-hover align-middle">
                    <thead>
                    <tr>
                        <th scope="col" style="width: 10%;">ID</th>
                        <th scope="col" style="width: 30%;">Tên Tài Khoản</th>
                        <th scope="col" style="width: 25%;">Vai Trò (Role)</th>
                        <th scope="col" style="width: 15%; text-align: center;">Hành Động</th>
                    </tr>
                    </thead>
                    <tbody>
                    <c:choose>
                        <c:when test="${not empty userList}">
                            <c:forEach items="${userList}" var="u">
                                <tr>
                                    <td class="fw-bold">#${u.id}</td>
                                    <td class="fw-bold text-dark"><i class="fa-solid fa-circle-user text-secondary me-2"></i> ${u.username}</td>
                                    <td>
                                        <c:choose>
                                            <c:when test="${u.role == 'ADMIN'}">
                                                <span class="badge bg-danger">ADMIN</span>
                                            </c:when>
                                            <c:when test="${u.role == 'MANAGER'}">
                                                <span class="badge bg-primary">MANAGER</span>
                                            </c:when>
                                            <c:when test="${u.role == 'STAFF'}">
                                                <span class="badge bg-warning text-dark">STAFF</span>
                                            </c:when>
                                            <c:otherwise>
                                                <span class="badge bg-info text-dark">CUSTOMER</span>
                                            </c:otherwise>
                                        </c:choose>
                                    </td>
                                    <td class="text-center">
                                        <!-- Nút mở Modal Sửa -->
                                        <button type="button" class="btn btn-sm btn-outline-warning me-1" title="Sửa quyền"
                                                onclick="openEditUserModal('${u.id}', '${u.username}', '${u.fullName}', '${u.role}')">
                                            <i class="fa-solid fa-pen-to-square"></i>
                                        </button>
                                        <!-- Nút Xóa -->
                                        <a href="${pageContext.request.contextPath}/admin/users?action=delete&id=${u.id}"
                                           onclick="return confirm('Bạn có chắc chắn muốn xóa tài khoản [${u.username}] không?');"
                                           class="btn btn-sm btn-outline-danger" title="Xóa tài khoản">
                                            <i class="fa-solid fa-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                            </c:forEach>
                        </c:when>
                        <c:otherwise>
                            <tr>
                                <td colspan="4" class="text-center text-muted py-4">Chưa có tài khoản nào trong hệ thống!</td>
                            </tr>
                        </c:otherwise>
                    </c:choose>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- MODAL THÊM TÀI KHOẢN MỚI -->
<div class="modal fade" id="addUserModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="${pageContext.request.contextPath}/admin/users" method="post">
                <input type="hidden" name="action" value="add">
                <div class="modal-header">
                    <h5 class="modal-title fw-bold"><i class="fa-solid fa-user-plus text-danger me-2"></i>Thêm Tài Khoản Mới</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Tên đăng nhập (Username):</label>
                        <input type="text" class="form-control" name="username" required placeholder="Nhập tên đăng nhập...">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Mật khẩu:</label>
                        <input type="password" class="form-control" name="password" required placeholder="Nhập mật khẩu...">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Họ và tên:</label>
                        <input type="text" class="form-control" name="fullName" placeholder="Nhập họ và tên...">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Vai trò (Role):</label>
                        <select class="form-select" name="role" required>
                            <option value="CUSTOMER">CUSTOMER (Khách hàng)</option>
                            <option value="STAFF">STAFF (Nhân viên)</option>
                            <option value="MANAGER">MANAGER (Quản lý)</option>
                            <option value="ADMIN">ADMIN (Quản trị viên)</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Đóng</button>
                    <button type="submit" class="btn btn-danger fw-bold">Tạo tài khoản</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- MODAL CẬP NHẬT TÀI KHOẢN -->
<div class="modal fade" id="editUserModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="${pageContext.request.contextPath}/admin/users" method="post">
                <input type="hidden" name="action" value="edit">
                <!-- Đã gắn name="id" để Servlet nhận được ID -->
                <input type="hidden" name="id" id="edit_id">
                <div class="modal-header">
                    <h5 class="modal-title fw-bold"><i class="fa-solid fa-pen-to-square text-warning me-2"></i>Cập Nhật Tài Khoản</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Tên đăng nhập:</label>
                        <input type="text" class="form-control bg-light" id="edit_username" readonly>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Mật khẩu mới (Để trống nếu giữ nguyên):</label>
                        <input type="password" class="form-control" name="password" placeholder="Nhập mật khẩu mới nếu muốn đổi...">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Họ và tên:</label>
                        <!-- Đã gắn name="fullName" để gửi tên lên Servlet -->
                        <input type="text" class="form-control" name="fullName" id="edit_fullName" placeholder="Nhập họ và tên...">
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-semibold">Vai trò (Role):</label>
                        <!-- Đã gắn name="role" để gửi quyền lên Servlet -->
                        <select class="form-select" name="role" id="edit_role" required>
                            <option value="CUSTOMER">CUSTOMER (Khách hàng)</option>
                            <option value="STAFF">STAFF (Nhân viên)</option>
                            <option value="MANAGER">MANAGER (Quản lý)</option>
                            <option value="ADMIN">ADMIN (Quản trị viên)</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
                    <button type="submit" class="btn btn-warning fw-bold">Lưu thay đổi</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    function openEditUserModal(id, username, fullName, role) {
        document.getElementById('edit_id').value = id;
        document.getElementById('edit_username').value = username;
        document.getElementById('edit_fullName').value = (fullName === 'null' || !fullName) ? '' : fullName;
        document.getElementById('edit_role').value = role;

        var editModal = new bootstrap.Modal(document.getElementById('editUserModal'));
        editModal.show();
    }
</script>
</body>
</html>