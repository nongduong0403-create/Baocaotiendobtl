<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Báo Cáo Doanh Thu - Admin Portal</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { background-color: #f8fafc; color: #1e293b; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .wrapper { display: flex; width: 100%; align-items: stretch; min-height: 100vh; }
        #sidebar { min-width: 260px; max-width: 260px; background: #ffffff; color: #1e293b; border-right: 1px solid #e2e8f0; box-shadow: 2px 0 10px rgba(0,0,0,0.02); }
        #sidebar .sidebar-header { padding: 20px; background: #ffffff; font-weight: bold; font-size: 1.1rem; border-bottom: 1px solid #e2e8f0; color: #0f172a; }
        #sidebar ul.components { padding: 15px 0; }
        #sidebar ul li a { padding: 12px 20px; font-size: 0.9rem; display: block; color: #64748b; text-decoration: none; transition: 0.2s; }
        #sidebar ul li a:hover, #sidebar ul li.active a { color: #fff; background: #dc3545; border-radius: 0 25px 25px 0; margin-right: 15px; }
        #sidebar ul li a i { margin-right: 10px; width: 20px; }
        #content { width: 100%; padding: 30px; }
        .admin-card { background-color: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.03); }
        .stat-card { background: linear-gradient(135deg, #ffffff 0%, #f1f5f9 100%); border: 1px solid #cbd5e1; border-radius: 12px; padding: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.02); }
        .table-dark-custom { background-color: #ffffff; color: #1e293b; }
        .table-dark-custom th, .table-dark-custom td { background-color: #ffffff !important; color: #1e293b !important; border-color: #f1f5f9 !important; vertical-align: middle; }
    </style>
</head>
<body>

<div class="wrapper">
    <!-- SIDEBAR CHUẨN ĐẦY ĐỦ CÁC MỤC -->
    <nav id="sidebar">
        <div class="sidebar-header">
            <i class="fa-solid fa-shield-halved text-danger me-2"></i> MANAGER
        </div>
        <ul class="list-unstyled components">
            <li>
                <a href="${pageContext.request.contextPath}/AdminServlet"><i class="fa-solid fa-building"></i> Quản lý rạp, phòng, ghế</a>
            </li>
            <li>
                <a href="${pageContext.request.contextPath}/admin/movies"><i class="fa-solid fa-film"></i> Quản lý phim, thể loại</a>
            </li>
            <li>
                <a href="${pageContext.request.contextPath}/admin/showtimes"><i class="fa-solid fa-calendar-days"></i> Quản lý lịch chiếu</a>
            </li>
            <li>
                <a href="${pageContext.request.contextPath}/admin/tickets"><i class="fa-solid fa-ticket"></i> Quản lý đặt vé</a>
            </li>
            <c:if test="${sessionScope.user.role == 'ADMIN'}">
                <li>
                    <a href="${pageContext.request.contextPath}/admin/users"><i class="fa-solid fa-users"></i> Khách hàng & Nhân viên</a>
                </li>
                <li>
                    <a href="${pageContext.request.contextPath}/admin/reports"><i class="fa-solid fa-chart-line"></i> Báo cáo doanh thu</a>
                </li>
            </c:if>
            <hr class="text-secondary mx-3">
            <li>
                <a href="${pageContext.request.contextPath}/logout" class="text-danger"><i class="fa-solid fa-right-from-bracket"></i> Đăng xuất</a>
            </li>
        </ul>
    </nav>

    <!-- NỘI DUNG CHÍNH -->
    <div id="content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="fw-bold text-dark mb-1"><i class="fa-solid fa-chart-line text-warning me-2"></i> Báo Cáo Doanh Thu</h3>
                <p class="text-muted small mb-0">Thống kê tổng quan tài chính và lịch sử giao dịch bán vé.</p>
            </div>
        </div>

        <!-- THẺ THỐNG KÊ TỔNG QUAN -->
        <div class="row g-4 mb-4">
            <div class="col-md-6">
                <div class="stat-card d-flex align-items-center">
                    <div class="fs-1 text-success me-3 bg-white p-3 rounded-3 border shadow-sm">
                        <i class="fa-solid fa-sack-dollar"></i>
                    </div>
                    <div>
                        <span class="text-muted small text-uppercase fw-bold">Tổng Doanh Thu Hệ Thống</span>
                        <h2 class="fw-bold text-success mb-0">${totalRevenue} đ</h2>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="stat-card d-flex align-items-center">
                    <div class="fs-1 text-info me-3 bg-white p-3 rounded-3 border shadow-sm">
                        <i class="fa-solid fa-ticket-simple"></i>
                    </div>
                    <div>
                        <span class="text-muted small text-uppercase fw-bold">Tổng Vé Đã Bán</span>
                        <h2 class="fw-bold text-info mb-0">${totalTickets} vé</h2>
                    </div>
                </div>
            </div>
        </div>

        <!-- BẢNG CHI TIẾT GIAO DỊCH -->
        <div class="admin-card p-4">
            <h5 class="fw-bold text-dark mb-3"><i class="fa-solid fa-list-check me-2 text-warning"></i> Chi Tiết Giao Dịch Đặt Vé</h5>
            <div class="table-responsive">
                <table class="table table-dark-custom table-hover align-middle">
                    <thead>
                    <tr>
                        <th scope="col" style="width: 20%;">Mã Đơn (Booking Code)</th>
                        <th scope="col" style="width: 20%;">Khách Hàng</th>
                        <th scope="col" style="width: 25%;">Tên Phim</th>
                        <th scope="col" style="width: 15%;">Tổng Tiền</th>
                        <th scope="col" style="width: 20%;">Thời Gian Giao Dịch</th>
                    </tr>
                    </thead>
                    <tbody>
                    <c:choose>
                        <c:when test="${not empty revenueDetails}">
                            <c:forEach items="${revenueDetails}" var="row">
                                <tr>
                                    <td class="fw-bold text-warning">${row[0]}</td>
                                    <td><i class="fa-solid fa-user me-1 text-info"></i> ${row[1]}</td>
                                    <td class="fw-bold text-dark">${row[2]}</td>
                                    <td class="text-success fw-bold">${row[3]}</td>
                                    <td><small class="text-muted">${row[4]}</small></td>
                                </tr>
                            </c:forEach>
                        </c:when>
                        <c:otherwise>
                            <tr>
                                <td colspan="5" class="text-center text-muted py-4">Chưa có dữ liệu giao dịch nào!</td>
                            </tr>
                        </c:otherwise>
                    </c:choose>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>