<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Quản Lý Phim - Admin Portal</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { background-color: #f8fafc; color: #1e293b; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .wrapper { display: flex; width: 100%; align-items: stretch; min-height: 100vh; }
        #sidebar { min-width: 260px; max-width: 260px; background: #ffffff; color: #1e293b; border-right: 1px solid #e2e8f0; box-shadow: 2px 0 10px rgba(0,0,0,0.02); }
        #sidebar .sidebar-header { padding: 20px; background: #ffffff; font-weight: bold; font-size: 1.1rem; border-bottom: 1px solid #e2e8f0; color: #0f172a; }
        #sidebar ul.components { padding: 15px 0; }
        #sidebar ul li a { padding: 12px 20px; font-size: 0.9rem; display: block; color: #64748b; text-decoration: none; transition: 0.2s; }
        #sidebar ul li a:hover, #sidebar ul li.active a { color: #fff; background: #dc3545; border-radius: 0 25px 25px 0; margin-right: 15px; }
        #sidebar ul li a i { margin-right: 10px; width: 20px; }
        #content { width: 100%; padding: 30px; }
        .admin-card { background-color: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.03); }
        .table-dark-custom { background-color: #ffffff; color: #1e293b; }
        .table-dark-custom th, .table-dark-custom td { background-color: #ffffff !important; color: #1e293b !important; border-color: #f1f5f9 !important; vertical-align: middle; }
        .movie-poster { width: 50px; height: 70px; object-fit: cover; border-radius: 4px; border: 1px solid #cbd5e1; }
    </style>
</head>
<body>

<div class="wrapper">
    <!-- SIDEBAR -->
    <nav id="sidebar">
        <div class="sidebar-header">
            <i class="fa-solid fa-shield-halved text-danger me-2"></i>
            <c:choose>
                <c:when test="${sessionScope.user.role == 'MANAGER'}">ADMIN PORTAL</c:when>
                <c:when test="${sessionScope.user.role == 'ADMIN'}">MANAGER PORTAL</c:when>
                <c:otherwise>MANAGEMENT PORTAL</c:otherwise>
            </c:choose>
        </div>
        <ul class="list-unstyled components">
            <li>
                <a href="${pageContext.request.contextPath}/AdminServlet"><i class="fa-solid fa-building"></i> Quản lý rạp, phòng, ghế</a>
            </li>
            <li class="active">
                <a href="${pageContext.request.contextPath}/admin/movies"><i class="fa-solid fa-film"></i> Quản lý phim, thể loại</a>
            </li>
            <li>
                <a href="${pageContext.request.contextPath}/admin/showtimes"><i class="fa-solid fa-calendar-days"></i> Quản lý lịch chiếu</a>
            </li>
            <li>
                <a href="${pageContext.request.contextPath}/admin/tickets"><i class="fa-solid fa-ticket"></i> Quản lý đặt vé</a>
            </li>
            <c:if test="${sessionScope.user.role == 'ADMIN'}">
                <li>
                    <a href="${pageContext.request.contextPath}/admin/users"><i class="fa-solid fa-users"></i> Khách hàng & Nhân viên</a>
                </li>
                <li>
                    <a href="${pageContext.request.contextPath}/admin/reports"><i class="fa-solid fa-chart-line"></i> Báo cáo doanh thu</a>
                </li>
            </c:if>
            <hr class="text-secondary mx-3">
            <li>
                <a href="${pageContext.request.contextPath}/logout" class="text-danger"><i class="fa-solid fa-right-from-bracket"></i> Đăng xuất</a>
            </li>
        </ul>
    </nav>

    <!-- NỘI DUNG CHÍNH -->
    <div id="content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="fw-bold text-dark mb-1"><i class="fa-solid fa-film text-warning me-2"></i> Quản Lý Danh Sách Phim</h3>
                <p class="text-muted small mb-0">Hiển thị toàn bộ kho phim hiện có trong hệ thống.</p>
            </div>
            <button class="btn btn-danger btn-sm fw-bold" data-bs-toggle="modal" data-bs-target="#addMovieModal">
                <i class="fa-solid fa-plus me-1"></i> Thêm Phim Mới
            </button>
        </div>

        <div class="admin-card p-4">
            <div class="table-responsive">
                <table class="table table-dark-custom table-hover align-middle">
                    <thead>
                    <tr>
                        <th scope="col" style="width: 5%;">ID</th>
                        <th scope="col" style="width: 10%;">Poster</th>
                        <th scope="col" style="width: 30%;">Tên Phim</th>
                        <th scope="col" style="width: 15%;">Thời Lượng</th>
                        <th scope="col" style="width: 15%;">Độ Tuổi</th>
                        <th scope="col" style="width: 10%;">Trạng Thái</th>
                        <th scope="col" style="width: 15%; text-align: center;">Hành Động</th>
                    </tr>
                    </thead>
                    <tbody>
                    <c:choose>
                        <c:when test="${not empty movieList}">
                            <c:forEach items="${movieList}" var="m">
                                <tr>
                                    <td>#${m.id}</td>
                                    <td>
                                        <img src="${pageContext.request.contextPath}/${m.posterUrl}" alt="Poster" class="movie-poster" onerror="this.src='https://via.placeholder.com/50x70?text=No+Img'">
                                    </td>
                                    <td class="fw-bold text-dark">${m.title}</td>
                                    <td><i class="fa-regular fa-clock me-1 text-muted"></i> ${m.duration} phút</td>
                                    <td>
                                        <span class="badge bg-secondary">${m.ageRating}</span>
                                        <c:if test="${m.hot}">
                                            <span class="badge bg-danger ms-1">HOT</span>
                                        </c:if>
                                    </td>
                                    <td>
                                        <c:choose>
                                            <c:when test="${m.status == 1}"><span class="text-success fw-bold">Đang chiếu</span></c:when>
                                            <c:when test="${m.status == 2}"><span class="text-warning fw-bold text-dark">Sắp chiếu</span></c:when>
                                            <c:otherwise><span class="text-info fw-bold">Chiếu sớm</span></c:otherwise>
                                        </c:choose>
                                    </td>
                                    <td class="text-center">
                                        <!-- Gọi hàm JavaScript mở 1 Modal sửa chung duy nhất -->
                                        <button class="btn btn-sm btn-outline-warning me-1" onclick="openEditMovieModal('${m.id}', '${m.title}', '${m.posterUrl}', '${m.duration}', '${m.status}', '${m.ageRating}', '${m.hot}', '${m.description}')" title="Sửa">
                                            <i class="fa-solid fa-pen-to-square"></i>
                                        </button>
                                        <!-- Nút Xóa -->
                                        <a href="${pageContext.request.contextPath}/admin/movies?action=delete&id=${m.id}" class="btn btn-sm btn-outline-danger" title="Xóa" onclick="return confirm('Bạn có chắc chắn muốn xóa phim: ${m.title}?');">
                                            <i class="fa-solid fa-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                            </c:forEach>
                        </c:when>
                        <c:otherwise>
                            <tr>
                                <td colspan="7" class="text-center text-muted py-4">Chưa có dữ liệu phim nào trong hệ thống!</td>
                            </tr>
                        </c:otherwise>
                    </c:choose>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- MỘT MODAL SỬA PHIM DÙNG CHUNG (TỐI ƯU HÓA KHÔNG LAG) -->
<div class="modal fade" id="sharedEditMovieModel" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg text-start">
        <div class="modal-content bg-white text-dark border border-secondary shadow-lg">
            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold text-warning">
                    <i class="fa-solid fa-pen-to-square me-2"></i> Cập Nhật Thông Tin Phim
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="${pageContext.request.contextPath}/admin/movies" method="POST">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="id" id="editMovieId">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Tên Phim</label>
                        <input type="text" class="form-control" name="title" id="editMovieTitle" required>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Đường dẫn Poster (URL hoặc thư mục ảnh)</label>
                            <input type="text" class="form-control" name="posterUrl" id="editMoviePoster" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Thời Lượng (phút)</label>
                            <input type="number" class="form-control" name="duration" id="editMovieDuration" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-bold">Trạng Thái</label>
                            <select class="form-select" name="status" id="editMovieStatus">
                                <option value="1">Đang chiếu</option>
                                <option value="2">Sắp chiếu</option>
                                <option value="3">Chiếu sớm</option>
                            </select>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-bold">Phân Loại Độ Tuổi</label>
                            <select class="form-select" name="ageRating" id="editMovieAgeRating">
                                <option value="P">P (Mọi lứa tuổi)</option>
                                <option value="C13">C13 (Dưới 13 tuổi cấm)</option>
                                <option value="C16">C16 (Dưới 16 tuổi cấm)</option>
                                <option value="C18">C18 (Dưới 18 tuổi cấm)</option>
                            </select>
                        </div>
                        <div class="col-md-4 mb-3 d-flex align-items-center">
                            <div class="form-check mt-4">
                                <input class="form-check-input" type="checkbox" name="isHot" value="true" id="editMovieIsHot">
                                <label class="form-check-label fw-bold text-danger" for="editMovieIsHot">
                                    Đánh dấu Phim HOT 🔥
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Mô Tả Nội Dung</label>
                        <textarea class="form-control" name="description" id="editMovieDescription" rows="3"></textarea>
                    </div>
                </div>
                <div class="modal-footer border-top">
                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Hủy bỏ</button>
                    <button type="submit" class="btn btn-warning btn-sm fw-bold text-dark">Lưu Thay Đổi</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- MODAL THÊM PHIM MỚI -->
<div class="modal fade" id="addMovieModal" tabindex="-1" aria-labelledby="addMovieModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg text-start">
        <div class="modal-content bg-white text-dark border border-secondary shadow-lg">
            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold text-danger" id="addMovieModalLabel">
                    <i class="fa-solid fa-film me-2"></i> Thêm Phim Mới Vào Hệ Thống
                </h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="${pageContext.request.contextPath}/admin/movies" method="POST">
                <input type="hidden" name="action" value="add">
                <div class="modal-body">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Tên Phim</label>
                        <input type="text" class="form-control" name="title" required placeholder="Nhập tên phim...">
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Đường dẫn Poster (URL hoặc thư mục ảnh)</label>
                            <input type="text" class="form-control" name="posterUrl" required placeholder="images/ten_anh.jpg">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Thời Lượng (phút)</label>
                            <input type="number" class="form-control" name="duration" required placeholder="Ví dụ: 120">
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-bold">Trạng Thái</label>
                            <select class="form-select" name="status">
                                <option value="1">Đang chiếu</option>
                                <option value="2">Sắp chiếu</option>
                                <option value="3">Chiếu sớm</option>
                            </select>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label class="form-label fw-bold">Phân Loại Độ Tuổi</label>
                            <select class="form-select" name="ageRating">
                                <option value="P">P (Mọi lứa tuổi)</option>
                                <option value="C13">C13 (Dưới 13 tuổi cấm)</option>
                                <option value="C16">C16 (Dưới 16 tuổi cấm)</option>
                                <option value="C18">C18 (Dưới 18 tuổi cấm)</option>
                            </select>
                        </div>
                        <div class="col-md-4 mb-3 d-flex align-items-center">
                            <div class="form-check mt-4">
                                <input class="form-check-input" type="checkbox" name="isHot" value="true" id="isHotCheckAdd">
                                <label class="form-check-label fw-bold text-danger" for="isHotCheckAdd">
                                    Đánh dấu Phim HOT 🔥
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Mô Tả Nội Dung</label>
                        <textarea class="form-control" name="description" rows="3" placeholder="Nhập tóm tắt nội dung phim..."></textarea>
                    </div>
                </div>
                <div class="modal-footer border-top">
                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Hủy bỏ</button>
                    <button type="submit" class="btn btn-danger btn-sm fw-bold">Lưu Phim Mới</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    function openEditMovieModal(id, title, posterUrl, duration, status, ageRating, isHot, description) {
        document.getElementById('editMovieId').value = id;
        document.getElementById('editMovieTitle').value = title;
        document.getElementById('editMoviePoster').value = posterUrl;
        document.getElementById('editMovieDuration').value = duration;
        document.getElementById('editMovieStatus').value = status;
        document.getElementById('editMovieAgeRating').value = ageRating;
        document.getElementById('editMovieIsHot').checked = (isHot === 'true');
        document.getElementById('editMovieDescription').value = description;

        var editModal = new bootstrap.Modal(document.getElementById('sharedEditMovieModel'));
        editModal.show();
    }
</script>
</body>
</html>