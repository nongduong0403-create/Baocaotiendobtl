<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Quản Lý Đặt Vé - Admin Portal</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { background-color: #f8fafc; color: #1e293b; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .wrapper { display: flex; width: 100%; align-items: stretch; min-height: 100vh; }
        #sidebar { min-width: 260px; max-width: 260px; background: #ffffff; color: #1e293b; border-right: 1px solid #e2e8f0; box-shadow: 2px 0 10px rgba(0,0,0,0.02); }
        #sidebar .sidebar-header { padding: 20px; background: #ffffff; font-weight: bold; font-size: 1.1rem; border-bottom: 1px solid #e2e8f0; color: #0f172a; }
        #sidebar ul.components { padding: 15px 0; }
        #sidebar ul li a { padding: 12px 20px; font-size: 0.9rem; display: block; color: #64748b; text-decoration: none; transition: 0.2s; }
        #sidebar ul li a:hover, #sidebar ul li.active a { color: #fff; background: #dc3545; border-radius: 0 25px 25px 0; margin-right: 15px; }
        #sidebar ul li a i { margin-right: 10px; width: 20px; }
        #content { width: 100%; padding: 30px; }
        .admin-card { background-color: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.03); }
        .table-light-custom { background-color: #ffffff; color: #1e293b; }
        .table-light-custom th, .table-light-custom td { background-color: #ffffff !important; color: #1e293b !important; border-color: #f1f5f9 !important; vertical-align: middle; }
    </style>
</head>
<body>

<div class="wrapper">
    <!-- SIDEBAR -->
    <nav id="sidebar">
        <div class="sidebar-header">
            <i class="fa-solid fa-shield-halved text-danger me-2"></i>
            <c:choose>
                <c:when test="${sessionScope.user.role == 'MANAGER'}">ADMIN PORTAL</c:when>
                <c:when test="${sessionScope.user.role == 'ADMIN'}">MANAGER PORTAL</c:when>
                <c:otherwise>MANAGEMENT PORTAL</c:otherwise>
            </c:choose>
        </div>
        <ul class="list-unstyled components">
            <li>
                <a href="${pageContext.request.contextPath}/AdminServlet"><i class="fa-solid fa-building"></i> Quản lý rạp, phòng, ghế</a>
            </li>
            <li>
                <a href="${pageContext.request.contextPath}/admin/movies"><i class="fa-solid fa-film"></i> Quản lý phim, thể loại</a>
            </li>
            <li>
                <a href="${pageContext.request.contextPath}/admin/showtimes"><i class="fa-solid fa-calendar-days"></i> Quản lý lịch chiếu</a>
            </li>
            <li class="active">
                <a href="${pageContext.request.contextPath}/admin/tickets"><i class="fa-solid fa-ticket"></i> Quản lý đặt vé</a>
            </li>
            <c:if test="${sessionScope.user.role == 'ADMIN'}">
                <li>
                    <a href="${pageContext.request.contextPath}/admin/users"><i class="fa-solid fa-users"></i> Khách hàng & Nhân viên</a>
                </li>
                <li>
                    <a href="${pageContext.request.contextPath}/admin/reports"><i class="fa-solid fa-chart-line"></i> Báo cáo doanh thu</a>
                </li>
            </c:if>
            <hr class="text-secondary mx-3">
            <li>
                <a href="${pageContext.request.contextPath}/logout" class="text-danger"><i class="fa-solid fa-right-from-bracket"></i> Đăng xuất</a>
            </li>
        </ul>
    </nav>

    <!-- NỘI DUNG CHÍNH -->
    <div id="content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="fw-bold text-dark mb-1"><i class="fa-solid fa-ticket text-warning me-2"></i> Quản Lý Danh Sách Đặt Vé</h3>
                <p class="text-muted small mb-0">Theo dõi thông tin vé và lịch sử giao dịch của khách hàng.</p>
            </div>
        </div>

        <div class="admin-card p-4">
            <div class="table-responsive">
                <table class="table table-light-custom table-hover align-middle">
                    <thead>
                    <tr>
                        <th scope="col" style="width: 8%;">Mã Vé</th>
                        <th scope="col" style="width: 15%;">Khách Hàng</th>
                        <th scope="col" style="width: 25%;">Tên Phim</th>
                        <th scope="col" style="width: 15%;">Phòng & Ghế</th>
                        <th scope="col" style="width: 12%;">Giá Tiền</th>
                        <th scope="col" style="width: 15%;">Thời Gian Đặt</th>
                        <th scope="col" style="width: 10%; text-align: center;">Trạng Thái</th>
                    </tr>
                    </thead>
                    <tbody>
                    <c:choose>
                        <c:when test="${not empty ticketList}">
                            <c:forEach items="${ticketList}" var="t">
                                <tr>
                                    <td class="fw-bold">#${t.id}</td>
                                    <td class="fw-bold text-primary"><i class="fa-solid fa-user me-1"></i> ${t.userName}</td>
                                    <td class="fw-bold text-dark">${t.movieTitle}</td>
                                    <td>
                                        <div class="fw-semibold text-secondary">${t.roomName}</div>
                                        <span class="badge bg-secondary">Ghế: ${t.seatName}</span>
                                    </td>
                                    <td class="text-success fw-bold">${t.price} đ</td>
                                    <td><small class="text-muted">${t.bookingTime}</small></td>
                                    <td class="text-center">
                                        <c:choose>
                                            <c:when test="${t.status == 1}">
                                                <span class="badge bg-success">Thành công</span>
                                            </c:when>
                                            <c:otherwise>
                                                <span class="badge bg-danger">Đã hủy</span>
                                            </c:otherwise>
                                        </c:choose>
                                    </td>
                                </tr>
                            </c:forEach>
                        </c:when>
                        <c:otherwise>
                            <tr>
                                <td colspan="7" class="text-center text-muted py-4">Chưa có giao dịch đặt vé nào trong hệ thống!</td>
                            </tr>
                        </c:otherwise>
                    </c:choose>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>