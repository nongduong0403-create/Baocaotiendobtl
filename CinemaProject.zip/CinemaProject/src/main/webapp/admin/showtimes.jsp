<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Quản Lý Lịch Chiếu - Admin Portal</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { background-color: #f8fafc; color: #1e293b; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .wrapper { display: flex; width: 100%; align-items: stretch; min-height: 100vh; }
        #sidebar { min-width: 260px; max-width: 260px; background: #ffffff; color: #1e293b; border-right: 1px solid #e2e8f0; box-shadow: 2px 0 10px rgba(0,0,0,0.02); }
        #sidebar .sidebar-header { padding: 20px; background: #ffffff; font-weight: bold; font-size: 1.1rem; border-bottom: 1px solid #e2e8f0; color: #0f172a; }
        #sidebar ul.components { padding: 15px 0; }
        #sidebar ul li a { padding: 12px 20px; font-size: 0.9rem; display: block; color: #64748b; text-decoration: none; transition: 0.2s; }
        #sidebar ul li a:hover, #sidebar ul li.active a { color: #fff; background: #dc3545; border-radius: 0 25px 25px 0; margin-right: 15px; }
        #sidebar ul li a i { margin-right: 10px; width: 20px; }
        #content { width: 100%; padding: 30px; }
        .admin-card { background-color: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.03); }
        .table-dark-custom { background-color: #ffffff; color: #1e293b; }
        .table-dark-custom th, .table-dark-custom td { background-color: #ffffff !important; color: #1e293b !important; border-color: #f1f5f9 !important; vertical-align: middle; }
    </style>
</head>
<body>

<div class="wrapper">
    <!-- SIDEBAR -->
    <nav id="sidebar">
        <div class="sidebar-header">
            <i class="fa-solid fa-shield-halved text-danger me-2"></i>
            <c:choose>
                <c:when test="${sessionScope.user.role == 'MANAGER'}">ADMIN PORTAL</c:when>
                <c:when test="${sessionScope.user.role == 'ADMIN'}">MANAGER PORTAL</c:when>
                <c:otherwise>MANAGEMENT PORTAL</c:otherwise>
            </c:choose>
        </div>
        <ul class="list-unstyled components">
            <li>
                <a href="${pageContext.request.contextPath}/AdminServlet"><i class="fa-solid fa-building"></i> Quản lý rạp, phòng, ghế</a>
            </li>
            <li>
                <a href="${pageContext.request.contextPath}/admin/movies"><i class="fa-solid fa-film"></i> Quản lý phim, thể loại</a>
            </li>
            <li class="active">
                <a href="${pageContext.request.contextPath}/admin/showtimes"><i class="fa-solid fa-calendar-days"></i> Quản lý lịch chiếu</a>
            </li>
            <li>
                <a href="${pageContext.request.contextPath}/admin/tickets"><i class="fa-solid fa-ticket"></i> Quản lý đặt vé</a>
            </li>
            <c:if test="${sessionScope.user.role == 'ADMIN'}">
                <li>
                    <a href="${pageContext.request.contextPath}/admin/users"><i class="fa-solid fa-users"></i> Khách hàng & Nhân viên</a>
                </li>
                <li>
                    <a href="${pageContext.request.contextPath}/admin/reports"><i class="fa-solid fa-chart-line"></i> Báo cáo doanh thu</a>
                </li>
            </c:if>
            <hr class="text-secondary mx-3">
            <li>
                <a href="${pageContext.request.contextPath}/logout" class="text-danger"><i class="fa-solid fa-right-from-bracket"></i> Đăng xuất</a>
            </li>
        </ul>
    </nav>

    <!-- NỘI DUNG CHÍNH -->
    <div id="content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="fw-bold text-dark mb-1"><i class="fa-solid fa-calendar-days text-warning me-2"></i> Quản Lý Lịch Chiếu</h3>
                <p class="text-muted small mb-0">Theo dõi toàn bộ các suất chiếu phim trong hệ thống.</p>
            </div>
            <button class="btn btn-danger btn-sm fw-bold" data-bs-toggle="modal" data-bs-target="#addShowtimeModal">
                <i class="fa-solid fa-plus me-1"></i> Thêm Suất Chiếu
            </button>
        </div>

        <div class="admin-card p-4">
            <div class="table-responsive">
                <table class="table table-dark-custom table-hover align-middle">
                    <thead>
                    <tr>
                        <th scope="col" style="width: 8%;">ID</th>
                        <th scope="col" style="width: 12%;">Mã Phim</th>
                        <th scope="col" style="width: 20%;">Rạp & Phòng Chiếu</th>
                        <th scope="col" style="width: 25%;">Ngày & Giờ Chiếu</th>
                        <th scope="col" style="width: 15%;">Giá Vé</th>
                        <th scope="col" style="width: 20%; text-align: center;">Hành Động</th>
                    </tr>
                    </thead>
                    <tbody>
                    <c:choose>
                        <c:when test="${not empty showtimeList}">
                            <c:forEach items="${showtimeList}" var="s">
                                <tr>
                                    <td>#${s.id}</td>
                                    <td><span class="badge bg-info text-dark">Phim ID: ${s.movieId}</span></td>
                                    <td>
                                        <div class="fw-bold text-danger">${s.cinemaName}</div>
                                        <small class="text-muted"><i class="fa-solid fa-door-open me-1"></i>${s.roomName}</small>
                                    </td>
                                    <td>
                                        <div class="fw-bold"><i class="fa-regular fa-calendar me-1 text-primary"></i> ${s.showDate}</div>
                                        <small class="text-success"><i class="fa-regular fa-clock me-1"></i> ${s.showTime}</small>
                                    </td>
                                    <td class="fw-bold text-dark">${s.price} đ</td>
                                    <td class="text-center">
                                        <!-- Gọi hàm JS mở 1 modal chung duy nhất -->
                                        <button class="btn btn-sm btn-outline-warning me-1" onclick="openEditModal('${s.id}', '${s.movieId}', '${s.roomId}', '${s.showDate}', '${s.showTime}', '${s.price}')" title="Sửa">
                                            <i class="fa-solid fa-pen-to-square"></i>
                                        </button>
                                        <a href="${pageContext.request.contextPath}/admin/showtimes?action=delete&id=${s.id}" class="btn btn-sm btn-outline-danger" onclick="return confirm('Xóa lịch chiếu này có thể ảnh hưởng đến vé đã đặt. Bạn có chắc chắn xóa?');" title="Xóa">
                                            <i class="fa-solid fa-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                            </c:forEach>
                        </c:when>
                        <c:otherwise>
                            <tr>
                                <td colspan="6" class="text-center text-muted py-4">Chưa có lịch chiếu nào trong hệ thống!</td>
                            </tr>
                        </c:otherwise>
                    </c:choose>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- MỘT MODAL SỬA LỊCH CHIẾU DÙNG CHUNG (TỐI ƯU HÓA KHÔNG BỊ LAG) -->
<div class="modal fade" id="sharedEditModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog text-start">
        <div class="modal-content bg-white text-dark border border-secondary shadow-lg">
            <div class="modal-header border-bottom">
                <h5 class="modal-title text-warning fw-bold"><i class="fa-solid fa-pen-to-square"></i> Cập Nhật Lịch Chiếu</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="${pageContext.request.contextPath}/admin/showtimes" method="POST">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="id" id="editId">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">ID Phim</label>
                            <input type="number" class="form-control" name="movieId" id="editMovieId" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">ID Phòng Chiếu</label>
                            <input type="number" class="form-control" name="roomId" id="editRoomId" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Ngày Chiếu</label>
                            <input type="date" class="form-control" name="showDate" id="editShowDate" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Giờ Chiếu</label>
                            <input type="time" class="form-control" name="showTime" id="editShowTime" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Giá Vé Căn Bản (VNĐ)</label>
                        <input type="number" class="form-control" name="price" id="editPrice" required>
                    </div>
                </div>
                <div class="modal-footer border-top">
                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Hủy</button>
                    <button type="submit" class="btn btn-warning btn-sm fw-bold text-dark">Lưu Thay Đổi</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- MODAL THÊM LỊCH CHIẾU MỚI -->
<div class="modal fade" id="addShowtimeModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog text-start">
        <div class="modal-content bg-white text-dark border border-secondary shadow-lg">
            <div class="modal-header border-bottom">
                <h5 class="modal-title fw-bold text-danger"><i class="fa-solid fa-calendar-plus me-2"></i> Thêm Lịch Chiếu Mới</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form action="${pageContext.request.contextPath}/admin/showtimes" method="POST">
                <input type="hidden" name="action" value="add">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">ID Phim</label>
                            <input type="number" class="form-control" name="movieId" placeholder="Ví dụ: 1" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">ID Phòng Chiếu</label>
                            <input type="number" class="form-control" name="roomId" placeholder="Ví dụ: 2" required>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Ngày Chiếu</label>
                            <input type="date" class="form-control" name="showDate" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Giờ Chiếu</label>
                            <input type="time" class="form-control" name="showTime" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Giá Vé Căn Bản (VNĐ)</label>
                        <input type="number" class="form-control" name="price" value="50000" required>
                    </div>
                </div>
                <div class="modal-footer border-top">
                    <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Hủy</button>
                    <button type="submit" class="btn btn-danger btn-sm fw-bold">Tạo Suất Chiếu</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
    function openEditModal(id, movieId, roomId, showDate, showTime, price) {
        document.getElementById('editId').value = id;
        document.getElementById('editMovieId').value = movieId;
        document.getElementById('editRoomId').value = roomId;
        document.getElementById('editShowDate').value = showDate;
        document.getElementById('editShowTime').value = showTime;
        document.getElementById('editPrice').value = price;

        var myModal = new bootstrap.Modal(document.getElementById('sharedEditModal'));
        myModal.show();
    }
</script>
</body>
</html>