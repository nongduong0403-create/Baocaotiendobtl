<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Đăng nhập - Hệ thống Rạp Phim</title>

    <!-- KÍCH HOẠT CHUẨN MOBILE ĐỂ BÀN PHÍM ĐIỆN THOẠI HIỆN LÊN KHÔNG BỊ VỠ FORM -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f8f9fa;
            color: #212529;
        }
        .auth-card {
            max-width: 420px;
            margin: 0 auto; /* Đã tinh chỉnh lại margin */
            background: #ffffff;
            border-radius: 12px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.08);
            border: 1px solid #e9ecef;
        }

        /* Chỉnh nhẹ nút bấm cho Mobile */
        .btn-login:active {
            transform: scale(0.97);
        }

        /* Tối ưu khoảng cách trên điện thoại */
        @media (max-width: 768px) {
            .auth-card {
                padding: 1.5rem !important;
                box-shadow: 0 5px 15px rgba(0,0,0,0.05);
            }
        }
    </style>
</head>
<body class="d-flex flex-column" style="min-height: 100vh;">

<!-- NHÚNG HEADER -->
<jsp:include page="header.jsp" />

<!-- Căn giữa form đăng nhập (Dùng my-4 cho mobile, my-md-5 cho PC) -->
<div class="container flex-grow-1 d-flex align-items-center justify-content-center my-4 my-md-5 px-3">
    <div class="card auth-card p-4 w-100">
        <div class="text-center mb-4">
            <h3 class="fw-bold text-primary">🎬 CINEMA EAUT</h3>
            <p class="text-muted small">Vui lòng đăng nhập để tiếp tục</p>
        </div>

        <p class="text-danger text-center fw-bold small">${requestScope.error}</p>

        <!-- Hiển thị thông báo khi bị yêu cầu đăng nhập từ trang khác -->
        <% String message = request.getParameter("message");
            if (message != null) { %>
        <p class="text-info text-center fw-bold small"><%= message %></p>
        <% } %>

        <form action="login" method="post">
            <!-- ĐOẠN CODE HỨNG ĐƯỜNG DẪN QUAY LẠI TRANG CHỌN GHẾ -->
            <% String redirectParam = request.getParameter("redirect"); %>
            <input type="hidden" name="redirect" value="<%= redirectParam != null ? redirectParam : "" %>">

            <div class="mb-3">
                <label class="form-label fw-medium small text-secondary">Tài khoản</label>
                <!-- Đổi thẻ input thành chuẩn form để mobile dễ chạm hơn -->
                <input type="text" class="form-control form-control-lg fs-6" name="txtUser" required placeholder="Nhập tên đăng nhập...">
            </div>
            <div class="mb-4">
                <label class="form-label fw-medium small text-secondary">Mật khẩu</label>
                <input type="password" class="form-control form-control-lg fs-6" name="txtPass" required placeholder="Nhập mật khẩu...">
            </div>
            <button type="submit" class="btn btn-warning btn-login w-100 fw-bold py-2 text-dark mb-3 transition-all">ĐĂNG NHẬP</button>
        </form>

        <div class="text-center small">
            <span class="text-muted">Chưa có tài khoản?</span>
            <a href="register" class="text-decoration-none fw-bold text-primary p-2">Đăng ký ngay</a>
        </div>
    </div>
</div>

<!-- NHÚNG FOOTER -->
<jsp:include page="footer.jsp" />

</body>
</html>