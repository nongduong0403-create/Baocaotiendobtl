<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<html>
<head>
    <title>Chi tiết phim - ${not empty movie.title ? movie.title : 'Mai'}</title>

    <!-- KÍCH HOẠT CHUẨN MOBILE TẠI ĐÂY -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { background-color: #f4f6f9; padding-bottom: 90px; }

        /* Banner thiết kế chuẩn App */
        .app-banner { position: relative; width: 100%; min-height: 280px; overflow: hidden; display: flex; align-items: flex-end; padding: 30px 20px; background: #1a1a1a; }
        .app-banner-bg { position: absolute; top: -20px; left: -20px; right: -20px; bottom: -20px; background-size: cover; background-position: center; filter: blur(12px); z-index: 1; opacity: 0.6; }
        .app-banner-overlay { position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: linear-gradient(to top, rgba(0,0,0,1) 0%, rgba(0,0,0,0.2) 100%); z-index: 2; }

        .banner-content { position: relative; z-index: 3; display: flex; gap: 20px; width: 100%; max-width: 800px; margin: 0 auto; align-items: flex-end; }
        .poster-img { width: 120px; height: 175px; object-fit: cover; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.5); border: 2px solid rgba(255,255,255,0.2); background: #333; }

        .movie-info { color: white; margin-bottom: 5px; }
        .movie-title { font-size: 26px; font-weight: 800; margin-bottom: 8px; letter-spacing: 0.5px; }
        .tag { display: inline-block; padding: 4px 12px; border-radius: 12px; background: rgba(255,255,255,0.15); font-size: 11px; font-weight: bold; margin-right: 5px; margin-bottom: 8px; border: 1px solid rgba(255,255,255,0.3); }
        .tag.age-restrict { background: #ff3333; border-color: #ff3333; }

        /* Phần nội dung chi tiết */
        .content-section { background: white; border-radius: 12px; padding: 25px; margin-top: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.04); }
        .section-title { font-weight: 800; font-size: 18px; margin-bottom: 15px; border-left: 4px solid #0056b3; padding-left: 12px; color: #333; }

        .cast-item { background: #f8f9fa; padding: 10px 15px; border-radius: 8px; border: 1px solid #e9ecef; margin-bottom: 10px; }

        /* Thanh đặt vé cố định ở đáy */
        .bottom-bar { position: fixed; bottom: 0; left: 0; width: 100%; background: white; box-shadow: 0 -4px 20px rgba(0,0,0,0.1); padding: 15px 20px; z-index: 1000; display: flex; justify-content: center; }
        .book-btn { background: #ff3333; color: white; border: none; border-radius: 25px; padding: 12px 0; font-weight: bold; font-size: 16px; width: 100%; max-width: 500px; text-decoration: none; text-align: center; text-transform: uppercase; letter-spacing: 1px; transition: 0.2s; }

        /* Hiệu ứng hover cho PC */
        @media (hover: hover) {
            .book-btn:hover { background: #cc0000; color: white; transform: translateY(-2px); }
        }

        /* TINH CHỈNH CSS CHO RIÊNG MOBILE */
        @media (max-width: 768px) {
            .app-banner { min-height: 240px; padding: 20px 15px; }
            .banner-content { gap: 15px; }
            .poster-img { width: 100px; height: 145px; }
            .movie-title { font-size: 22px; margin-bottom: 5px; }
            .tag { font-size: 10px; padding: 3px 10px; }
            .content-section { padding: 15px; margin-top: 15px; }
            .section-title { font-size: 16px; margin-bottom: 12px; }
            /* Hiệu ứng nhún mượt mà khi tap trên mobile */
            .book-btn:active { transform: scale(0.96); background: #cc0000; color: white; }
        }
    </style>
</head>
<body>

<jsp:include page="header.jsp" />

<!-- Khởi tạo biến chứa link ảnh mặc định -->
<c:set var="defaultPoster" value="https://upload.wikimedia.org/wikipedia/vi/a/a8/Mai_2024_poster.jpg" />
<c:set var="finalPoster" value="${not empty movie.posterUrl ? movie.posterUrl : defaultPoster}" />

<!-- 1. Banner phong cách App -->
<div class="app-banner">
    <div class="app-banner-bg" style="background-image: url('${finalPoster}');"></div>
    <div class="app-banner-overlay"></div>

    <div class="banner-content">
        <img src="${finalPoster}" alt="Poster Phim" class="poster-img" onerror="this.src='https://via.placeholder.com/120x175.png?text=No+Image';">
        <div class="movie-info">
            <div class="movie-title">${not empty movie.title ? movie.title : 'Mai'}</div>
            <div>
                <span class="tag age-restrict">T18</span>
                <span class="tag">Tâm lý, Tình cảm</span>
            </div>
            <div class="small mt-1 text-light"><i class="fa-regular fa-clock me-1"></i> ${not empty movie.duration ? movie.duration : '120'} phút</div>
            <div class="small mt-1 text-light"><i class="fa-solid fa-calendar-days me-1"></i> Khởi chiếu: 10/02/2024</div>
        </div>
    </div>
</div>

<div class="container pb-4" style="max-width: 800px;">

    <!-- 2. Nội dung phim -->
    <div class="content-section">
        <div class="section-title">Nội dung phim</div>
        <p class="text-muted" style="font-size: 14.5px; line-height: 1.7; text-align: justify; margin-bottom: 0;">
            ${not empty movie.description ? movie.description : 'Mai là câu chuyện về cuộc đời của một người phụ nữ đẹp nhưng truân chuyên. Làm nghề mát-xa, Mai thường xuyên phải đối mặt với ánh nhìn soi mói, phán xét từ những người xung quanh. Cuộc đời cô bắt đầu có những ngã rẽ khi cô gặp Dương, một chàng trai trẻ đam mê âm nhạc. Liệu Mai có thể tìm được hạnh phúc cho riêng mình hay quá khứ và những định kiến xã hội sẽ mãi ám ảnh cô?'}
        </p>
    </div>

    <!-- 3. Đạo diễn & Diễn viên -->
    <div class="content-section">
        <div class="section-title">Ê-kíp sản xuất</div>
        <div class="row g-3">
            <div class="col-12 col-md-6">
                <div class="cast-item m-0">
                    <span class="text-muted small d-block">Đạo diễn</span>
                    <span class="fw-bold text-dark">Trấn Thành</span>
                </div>
            </div>
            <div class="col-12 col-md-6">
                <div class="cast-item m-0">
                    <span class="text-muted small d-block">Diễn viên chính</span>
                    <span class="fw-bold text-dark">Phương Anh Đào, Tuấn Trần, Hồng Đào</span>
                </div>
            </div>
        </div>
    </div>

</div>

<!-- 4. Thanh đặt vé dính dưới đáy -->
<div class="bottom-bar">
    <a href="showtimes?movieId=${movie.id}" class="btn btn-danger w-100 fw-bold fs-5">ĐẶT VÉ NGAY</a>
</div>

<jsp:include page="footer.jsp" />

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>