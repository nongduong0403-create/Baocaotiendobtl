<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Yêu cầu hoàn vé</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
<div class="container mt-5" style="max-width: 500px;">
    <div class="card shadow-sm">
        <div class="card-body text-center">
            <h4 class="text-danger fw-bold">XÁC NHẬN HOÀN VÉ</h4>
            <p>Mã đơn hàng của bạn: <strong class="text-primary">#BK-<%= request.getParameter("bookingId") %></strong></p>
            <p class="mb-3 text-muted small">Ghế sẽ hủy: <strong><%= request.getParameter("seats") %></strong></p>
            <hr>

            <!-- ĐÃ SỬA: Đổi action thành refund-ticket cho khớp Servlet -->
            <form action="refund-ticket" method="POST">

                <!-- THÊM DỮ LIỆU ẨN ĐỂ BACKEND BIẾT ĐƯỜNG XÓA GHẾ TRONG CSDL -->
                <input type="hidden" name="bookingId" value="<%= request.getParameter("bookingId") %>">
                <input type="hidden" name="showtimeId" value="<%= request.getParameter("showtimeId") %>">
                <input type="hidden" name="seats" value="<%= request.getParameter("seats") %>">
                <input type="hidden" name="ticketCode" value="<%= request.getParameter("ticketCode") %>">

                <div class="mb-3 text-start">
                    <label class="form-label">Lý do hoàn vé:</label>
                    <textarea class="form-control" name="reason" rows="3" required></textarea>
                </div>
                <div class="mb-3 text-start">
                    <label class="form-label">Số tài khoản nhận tiền hoàn:</label>
                    <input type="text" class="form-control" name="bankAccount" required>
                </div>
                <button type="submit" class="btn btn-danger w-100">Gửi Yêu Cầu Hoàn Tiền</button>
                <a href="home" class="btn btn-outline-secondary w-100 mt-2">Quay lại trang chủ</a>
            </form>
        </div>
    </div>
</div>
</body>
</html>