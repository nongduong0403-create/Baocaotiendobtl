<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<html>
<head>
    <title>Đăng ký tài khoản - CINEMA EAUT</title>

    <!-- KÍCH HOẠT CHUẨN MOBILE TẠI ĐÂY -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8f9fa; }
        .register-card {
            max-width: 420px;
            margin: 0 auto;
            border-radius: 12px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.05);
        }

        /* Hiệu ứng nhún mượt mà khi bấm trên điện thoại */
        .btn-register:active {
            transform: scale(0.97);
        }

        /* Tối ưu riêng cho màn hình nhỏ */
        @media (max-width: 768px) {
            .register-card { padding: 1.5rem !important; }
        }
    </style>
</head>
<body class="d-flex flex-column" style="min-height: 100vh;">

<div class="container flex-grow-1 d-flex align-items-center justify-content-center my-4 my-md-5 px-3">
    <div class="card register-card border-0 p-4 w-100 bg-white">
        <div class="text-center mb-4">
            <h3 class="fw-bold text-primary">🎬 CINEMA EAUT</h3>
            <p class="text-muted small">Tạo tài khoản mới để đặt vé xem phim</p>
        </div>

        <!-- Hiển thị thông báo lỗi nếu có -->
        <c:if test="${not empty error}">
            <div class="alert alert-danger py-2 small text-center">${error}</div>
        </c:if>

        <form action="register" method="POST">
            <div class="mb-3">
                <label class="form-label fw-medium small text-secondary">Tên đăng nhập</label>
                <input type="text" name="username" class="form-control form-control-lg fs-6" required placeholder="Nhập tên đăng nhập...">
            </div>
            <div class="mb-3">
                <label class="form-label fw-medium small text-secondary">Mật khẩu</label>
                <input type="password" name="password" class="form-control form-control-lg fs-6" required placeholder="Nhập mật khẩu...">
            </div>
            <div class="mb-4">
                <label class="form-label fw-medium small text-secondary">Nhập lại mật khẩu</label>
                <input type="password" name="confirmPassword" class="form-control form-control-lg fs-6" required placeholder="Xác nhận mật khẩu...">
            </div>
            <button type="submit" class="btn btn-primary btn-register w-100 fw-bold py-2 mb-3 shadow-sm">ĐĂNG KÝ</button>
        </form>

        <div class="text-center small">
            <span class="text-muted">Đã có tài khoản?</span>
            <a href="login.jsp" class="text-decoration-none fw-bold text-primary p-2">Đăng nhập ngay</a>
        </div>
    </div>
</div>

</body>
</html>