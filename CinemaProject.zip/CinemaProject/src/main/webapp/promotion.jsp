<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Khuyến Mãi - Cinema EAUT</title>

    <!-- KÍCH HOẠT CHUẨN MOBILE TẠI ĐÂY -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        body { background-color: #f8f9fa; }
        .promo-card { transition: transform 0.2s ease, box-shadow 0.2s ease; }

        /* Hiệu ứng di chuột trên PC */
        @media (hover: hover) {
            .promo-card:hover { transform: translateY(-5px); box-shadow: 0 10px 20px rgba(0,0,0,0.15); }
        }

        /* TINH CHỈNH RIÊNG CHO ĐIỆN THOẠI */
        @media (max-width: 768px) {
            .page-title { font-size: 1.4rem; }
            .promo-banner-img { height: 200px !important; } /* Thu nhỏ ảnh trên mobile */

            /* Hiệu ứng nhún khi chạm ngón tay */
            .promo-card:active { transform: scale(0.97); box-shadow: 0 5px 10px rgba(0,0,0,0.1); }
            .btn-promo:active { transform: scale(0.95); }
        }
    </style>
</head>
<body class="d-flex flex-column" style="min-height: 100vh;">

<!-- HEADER -->
<jsp:include page="header.jsp" />

<div class="container flex-grow-1 my-4 my-md-5">
    <h2 class="fw-bold text-primary mb-4 border-start border-primary border-4 ps-3 page-title">🎉 CHƯƠNG TRÌNH KHUYẾN MÃI</h2>

    <!-- Thêm g-4 cho PC và g-3 cho Mobile để căn chỉnh khoảng cách các thẻ -->
    <div class="row g-3 g-md-4 px-2 px-md-0">
        <!-- Banner Khuyến mãi 1 (Mã Voucher cậu đã làm) -->
        <div class="col-12 col-md-6">
            <div class="card promo-card border-0 shadow-sm rounded-4 overflow-hidden h-100">
                <img src="https://images.unsplash.com/photo-1574267432553-4b4628081c31?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" class="card-img-top promo-banner-img" alt="Khuyến mãi sinh viên" style="height: 250px; object-fit: cover;">
                <div class="card-body p-4 d-flex flex-column">
                    <div>
                        <span class="badge bg-danger mb-2">HOT</span>
                        <h4 class="fw-bold fs-5 fs-md-4">Ưu đãi sinh viên EAUT</h4>
                        <p class="text-muted small">Nhập mã <strong class="text-dark">EAUT50K</strong> ở bước thanh toán để được giảm ngay 50.000đ cho mọi cụm rạp. Áp dụng đến hết tháng này.</p>
                    </div>
                    <button class="btn btn-outline-primary fw-bold rounded-pill mt-auto btn-promo py-2" onclick="alert('Đã copy mã: EAUT50K')">Copy Mã</button>
                </div>
            </div>
        </div>

        <!-- Banner Khuyến mãi 2 -->
        <div class="col-12 col-md-6">
            <div class="card promo-card border-0 shadow-sm rounded-4 overflow-hidden h-100">
                <img src="https://images.unsplash.com/photo-1585647347384-2593bc35786b?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&q=80" class="card-img-top promo-banner-img" alt="Đồng giá" style="height: 250px; object-fit: cover;">
                <div class="card-body p-4 d-flex flex-column">
                    <div>
                        <span class="badge bg-success mb-2">NEW</span>
                        <h4 class="fw-bold fs-5 fs-md-4">Thứ 3 Vui Vẻ - Đồng giá 55K</h4>
                        <p class="text-muted small">Tận hưởng ngày thứ 3 hàng tuần với mức giá ưu đãi chỉ 55.000đ cho mọi suất chiếu 2D tiêu chuẩn.</p>
                    </div>
                    <a href="home" class="btn btn-primary fw-bold rounded-pill mt-auto btn-promo py-2">Đặt vé ngay</a>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- FOOTER -->
<jsp:include page="footer.jsp" />
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>