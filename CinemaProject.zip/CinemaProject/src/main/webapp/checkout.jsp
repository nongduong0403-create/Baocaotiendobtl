<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<html>
<head>
    <title>Thanh toán vé</title>

    <!-- KÍCH HOẠT CHUẨN MOBILE (Chống zoom vỡ màn hình) -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { background-color: #f4f6f9; padding-bottom: 90px; }

        /* Header trang thanh toán */
        .header-checkout { background: #00224c; color: white; padding: 15px 20px; display: flex; align-items: center; gap: 15px; position: sticky; top: 0; z-index: 100; }
        .back-btn { color: white; font-size: 20px; text-decoration: none; cursor: pointer; }
        .header-title { font-size: 18px; font-weight: bold; margin: 0; }

        /* Card thông tin vé */
        .ticket-card { background: white; border-radius: 12px; padding: 20px; margin: 20px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); border-top: 5px solid #ff3333; }
        .movie-title { font-size: 20px; font-weight: 800; color: #333; margin-bottom: 5px; }
        .cinema-info { font-size: 14px; color: #666; margin-bottom: 15px; padding-bottom: 15px; border-bottom: 1px dashed #dee2e6; }

        .ticket-detail-row { display: flex; justify-content: space-between; margin-bottom: 10px; font-size: 15px; }
        .ticket-detail-label { color: #6c757d; }
        .ticket-detail-value { font-weight: 600; color: #333; text-align: right; }

        /* Phương thức thanh toán */
        .payment-section { margin: 0 20px; }
        .payment-title { font-weight: bold; color: #333; margin-bottom: 15px; font-size: 16px; }
        .payment-method { background: white; border-radius: 10px; padding: 15px; margin-bottom: 10px; display: flex; align-items: center; justify-content: space-between; border: 1px solid #e9ecef; cursor: pointer; transition: transform 0.1s ease, border 0.2s ease; }

        /* Hiệu ứng nhún (scale) mượt mà khi người dùng tap trên điện thoại */
        .payment-method:active { transform: scale(0.96); background: #f8f9fa; }
        .payment-method.active { border: 2px solid #0d6efd; background: #f0f8ff; }

        .payment-logo { width: 35px; height: 35px; object-fit: contain; margin-right: 15px; }
        .payment-name { font-weight: 600; font-size: 15px; color: #333; }

        /* Thanh bottom */
        .bottom-bar { position: fixed; bottom: 0; left: 0; width: 100%; background: white; box-shadow: 0 -4px 15px rgba(0,0,0,0.08); padding: 15px 20px; z-index: 1000; display: flex; justify-content: space-between; align-items: center; }
        .total-amount-label { font-size: 13px; color: #666; }
        .total-amount { font-size: 22px; font-weight: bold; color: #ff3333; }
        .pay-btn { background: #ff3333; color: white; border: none; border-radius: 25px; padding: 10px 30px; font-weight: bold; font-size: 16px; cursor: pointer; transition: 0.2s; }
        .pay-btn:active { transform: scale(0.95); background: #cc0000; }
        .pay-btn:disabled { background: #ffa6a6; cursor: not-allowed; transform: none; }
    </style>
</head>
<body>

<!-- Header -->
<div class="header-checkout">
    <a href="javascript:history.back()" class="back-btn"><i class="fa-solid fa-arrow-left"></i></a>
    <h1 class="header-title">Thanh toán an toàn</h1>
</div>

<div class="container p-0" style="max-width: 600px; margin: 0 auto;">

    <!-- 1. Thông tin vé -->
    <div class="ticket-card">
        <div class="movie-title">${not empty movieName ? movieName : 'Tên phim đang tải...'}</div>
        <div class="cinema-info">
            <div class="fw-bold text-dark mb-1">${not empty cinemaName ? cinemaName : 'Cinema EAUT'}</div>
            <div>${not empty showDate ? showDate : '...'} | ${not empty showTime ? showTime : '...'} | ${not empty roomName ? roomName : 'Phòng ...'}</div>
        </div>

        <div class="ticket-detail-row">
            <span class="ticket-detail-label">Ghế đã chọn:</span>
            <span class="ticket-detail-value text-primary" id="display-seats">Đang tải...</span>
        </div>
        <div class="ticket-detail-row">
            <span class="ticket-detail-label">Phí tiện ích:</span>
            <span class="ticket-detail-value">0 đ</span>
        </div>
    </div>

    <!-- 2. Phương thức thanh toán -->
    <div class="payment-section">
        <div class="payment-title">Phương thức thanh toán</div>

        <div class="payment-method active" onclick="selectPayment(this, 'momo')">
            <div class="d-flex align-items-center">
                <img src="https://upload.wikimedia.org/wikipedia/vi/f/fe/MoMo_Logo.png" class="payment-logo" alt="MoMo">
                <span class="payment-name">Ví MoMo</span>
            </div>
            <i class="fa-solid fa-circle-check text-primary fs-5 check-icon"></i>
        </div>

        <div class="payment-method" onclick="selectPayment(this, 'zalo')">
            <div class="d-flex align-items-center">
                <img src="https://cdn.haitrieu.com/wp-content/uploads/2022/10/Logo-ZaloPay-Square.png" class="payment-logo" alt="ZaloPay">
                <span class="payment-name">Ví ZaloPay</span>
            </div>
            <i class="fa-regular fa-circle text-muted fs-5 check-icon"></i>
        </div>

        <div class="payment-method" onclick="selectPayment(this, 'atm')">
            <div class="d-flex align-items-center">
                <img src="https://cdn.haitrieu.com/wp-content/uploads/2022/10/Logo-VNPAY-QR-1.png" class="payment-logo" alt="VNPay">
                <span class="payment-name">Thẻ ATM / VNPay</span>
            </div>
            <i class="fa-regular fa-circle text-muted fs-5 check-icon"></i>
        </div>
    </div>

</div>

<!-- 3. Thanh toán dính dưới đáy -->
<div class="bottom-bar">
    <div>
        <div class="total-amount-label">Cần thanh toán</div>
        <div class="total-amount" id="display-total">0 đ</div>
    </div>
    <button class="pay-btn" onclick="processPayment()">Thanh toán</button>
</div>

<script>
    const urlParams = new URLSearchParams(window.location.search);
    const seatsParam = urlParams.get('seats');

    let totalPrice = 0;

    if (seatsParam) {
        const seatsArray = seatsParam.split(',');
        document.getElementById('display-seats').innerText = seatsArray.join(', ');

        seatsArray.forEach(seat => {
            seat = seat.trim();
            if (seat.startsWith('M')) {
                totalPrice += 100000;
            } else if (['E', 'F', 'G', 'H', 'I', 'J', 'K', 'L'].some(row => seat.startsWith(row))) {
                totalPrice += 50000;
            } else {
                totalPrice += 45000;
            }
        });

        document.getElementById('display-total').innerText = totalPrice.toLocaleString('vi-VN') + ' đ';
    } else {
        document.getElementById('display-seats').innerText = "Chưa chọn ghế";
        document.getElementById('display-seats').classList.replace('text-primary', 'text-danger');
    }

    let selectedPaymentMethod = 'momo';

    function selectPayment(element, methodCode) {
        document.querySelectorAll('.payment-method').forEach(el => {
            el.classList.remove('active');
            let icon = el.querySelector('.check-icon');
            icon.classList.remove('fa-solid', 'fa-circle-check', 'text-primary');
            icon.classList.add('fa-regular', 'fa-circle', 'text-muted');
        });

        element.classList.add('active');
        let activeIcon = element.querySelector('.check-icon');
        activeIcon.classList.remove('fa-regular', 'fa-circle', 'text-muted');
        activeIcon.classList.add('fa-solid', 'fa-circle-check', 'text-primary');

        selectedPaymentMethod = methodCode;
    }

    function processPayment() {
        const urlParams = new URLSearchParams(window.location.search);
        const bookingId = urlParams.get('bookingId');
        const seatsParam = urlParams.get('seats');

        if (!bookingId) {
            alert("Lỗi: Không tìm thấy mã đơn hàng. Vui lòng quay lại chọn ghế!");
            return;
        }

        const btn = document.querySelector('.pay-btn');
        btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Đang tải...';
        btn.disabled = true;

        window.location.href = "ticket.jsp?bookingId=" + bookingId + "&seats=" + encodeURIComponent(seatsParam) + "&total=" + totalPrice + "&method=" + selectedPaymentMethod;
    }
</script>

</body>
</html>