<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Trang Quản Lý Cụm Rạp</title>

    <!-- KÍCH HOẠT CHUẨN MOBILE -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        /* Hiệu ứng nhún mượt mà khi người dùng chạm trên điện thoại */
        .manager-card {
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        .manager-card:active {
            transform: scale(0.97);
            box-shadow: 0 2px 8px rgba(0,0,0,0.1) !important;
        }

        /* Tối ưu khoảng cách và kích thước chữ cho Mobile */
        @media (max-width: 768px) {
            .main-container { margin-top: 20px !important; padding: 0 15px; }
            h2 { font-size: 1.4rem; }
        }
    </style>
</head>
<body class="bg-light">
<div class="container mt-5 main-container">
    <div class="card shadow border-0 rounded-4 p-4">
        <h2 class="text-primary fw-bold">📊 HỆ THỐNG QUẢN LÝ CỤM RẠP</h2>
        <hr>
        <p class="mb-1">Xin chào quản lý: <span class="fw-bold text-success">${sessionScope.user.fullName}</span></p>
        <p class="text-muted small">Khu vực dành riêng cho cấp bậc: <strong>${sessionScope.user.role}</strong></p>

        <!-- Thêm class g-3 (gap-3) để tạo khoảng cách an toàn giữa các khối khi xếp dọc trên điện thoại -->
        <div class="row mt-4 g-3">
            <div class="col-12 col-md-4">
                <!-- Thêm h-100 để các thẻ cao bằng nhau nếu text bên trong dài ngắn khác nhau -->
                <div class="card p-3 bg-white border-primary shadow-sm manager-card h-100 d-flex flex-column">
                    <h5>Quản lý Lịch chiếu</h5>
                    <p class="small text-muted mb-3 flex-grow-1">Thêm, sửa, xóa suất chiếu các phim.</p>
                    <a href="#" class="btn btn-sm btn-outline-primary mt-auto fw-bold">Truy cập</a>
                </div>
            </div>
            <div class="col-12 col-md-4">
                <div class="card p-3 bg-white border-success shadow-sm manager-card h-100 d-flex flex-column">
                    <h5>Báo cáo Doanh thu</h5>
                    <p class="small text-muted mb-3 flex-grow-1">Thống kê vé bán ra theo ngày/tháng.</p>
                    <a href="#" class="btn btn-sm btn-outline-success mt-auto fw-bold">Truy cập</a>
                </div>
            </div>
        </div>

        <div class="mt-4 text-end">
            <!-- Đổi icon và làm nổi bật nút đăng xuất -->
            <a href="LogoutServlet" class="btn btn-danger px-4 fw-bold shadow-sm">Đăng xuất</a>
        </div>
    </div>
</div>
</body>
</html>