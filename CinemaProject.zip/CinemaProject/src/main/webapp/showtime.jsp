<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Đặt vé theo phim - ${movie.title}</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { background-color: #f4f6f9; }
        .app-banner { position: relative; width: 100%; min-height: 280px; overflow: hidden; display: flex; align-items: center; justify-content: center; text-align: center; color: white; padding: 25px 0 15px 0; }
        .app-banner-bg { position: absolute; top: -20px; left: -20px; right: -20px; bottom: -20px; background-size: cover; background-position: center; filter: blur(20px); z-index: 1; }
        .app-banner-overlay { position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: linear-gradient(to bottom, rgba(255,255,255,0.4), rgba(255,255,255,1)); z-index: 2; }
        .app-banner-content { position: relative; z-index: 3; }
        .detail-btn { background: transparent; border: 1.5px solid #0056b3; color: #0056b3; border-radius: 20px; padding: 6px 20px; font-weight: bold; font-size: 13px; margin-top: 5px; display: inline-block; transition: 0.2s; }
        .detail-btn:hover { background: #0056b3; color: white; text-decoration: none; }

        .date-scroll-app { display: flex; gap: 20px; overflow-x: auto; padding: 15px 10px; justify-content: flex-start; background: white; -webkit-overflow-scrolling: touch; scrollbar-width: none; -ms-overflow-style: none; }
        .date-scroll-app::-webkit-scrollbar { display: none; }
        .date-item { text-align: center; cursor: pointer; color: #6c757d; min-width: 55px; user-select: none; flex-shrink: 0; text-decoration: none; }
        .date-item:hover { color: #dc3545; }
        .date-item.active { color: #dc3545; border-bottom: 2px solid #dc3545; padding-bottom: 5px; }
        .date-item.active .date-num { font-weight: bold; }

        .region-bar { padding: 15px 15px 10px 15px; }
        .cinema-list-card { background: white; border-radius: 12px; padding: 16px; margin: 0 15px 12px 15px; border: 1px solid #e9ecef; cursor: pointer; user-select: none; transition: 0.1s;}
        .cinema-list-card:active { transform: scale(0.98); }
        .time-slot-btn { border: 1px solid #b0c4de; background: #f0f8ff; color: #0056b3; border-radius: 20px; padding: 8px 15px; text-align: center; text-decoration: none; display: inline-block; min-width: 90px; transition: 0.2s; }
        .time-slot-btn:hover, .time-slot-btn:active { background: #0056b3; color: white; text-decoration: none; }

        @media (max-width: 768px) {
            .app-banner { min-height: 240px; padding: 15px 0 10px 0; }
            .app-banner img { height: 110px !important; margin-bottom: 10px !important; }
            .app-banner h4 { font-size: 1.2rem; }
            .cinema-list-card { padding: 12px; margin: 0 10px 10px 10px; }
            .time-slot-btn { min-width: 75px; padding: 6px 12px; }
            .time-slot-btn .fs-6 { font-size: 0.9rem !important; }
        }
    </style>
</head>
<body>

<jsp:include page="header.jsp" />

<div class="app-banner">
    <div class="app-banner-bg" style="background-image: url('${not empty movie.posterUrl ? movie.posterUrl : 'https://via.placeholder.com/300'}');"></div>
    <div class="app-banner-overlay"></div>

    <div class="app-banner-content text-dark d-flex flex-column align-items-center">
        <c:if test="${not empty movie.posterUrl}">
            <img src="${movie.posterUrl}" alt="${movie.title}" style="height: 130px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.2); margin-bottom: 15px;">
        </c:if>
        <h4 class="fw-bold mb-1" style="color: #000;">${not empty movie.title ? movie.title : 'Tên phim'}</h4>
        <p class="small text-muted mb-2">Tâm lý, Gia đình | ${not empty movie.duration ? movie.duration : '--'} phút</p>
        <a href="movie-detail?id=${movie.id}" class="detail-btn text-decoration-none">Chi tiết phim</a>
    </div>
</div>

<div class="date-scroll-app" style="max-width: 600px; margin: 0 auto;">
    <a href="showtimes?movieId=${movie.id}&date=2026-09-20" class="date-item active">
        <div class="fs-4 date-num">20</div>
        <div class="small fw-semibold">Hôm nay</div>
    </a>
    <a href="showtimes?movieId=${movie.id}&date=2026-09-21" class="date-item">
        <div class="fs-4 date-num">21</div>
        <div class="small">Th 2</div>
    </a>
    <a href="showtimes?movieId=${movie.id}&date=2026-09-22" class="date-item">
        <div class="fs-4 date-num">22</div>
        <div class="small">Th 3</div>
    </a>
    <a href="showtimes?movieId=${movie.id}&date=2026-09-23" class="date-item">
        <div class="fs-4 date-num">23</div>
        <div class="small">Th 4</div>
    </a>
</div>

<div class="container pb-5" style="max-width: 600px; margin: 0 auto;">
    <div class="region-bar">
        <span class="fw-bold text-secondary" style="font-size: 15px;">Danh sách rạp tại Hà Nội</span>
    </div>

    <div id="cinema-list">

        <!-- Rạp 1: CINEMA EAUT Cầu Giấy -->
        <div class="cinema-list-card" onclick="toggleCinema(this)">
            <div class="d-flex justify-content-between align-items-center">
                <span class="fs-6 text-dark cinema-title fw-bold">CINEMA EAUT Cầu Giấy</span>
                <span class="text-primary small" style="color: #4a90e2 !important;">3.7 km <i class="fa-solid fa-chevron-down ms-2 text-dark"></i></span>
            </div>
            <div class="time-slots-wrapper mt-3 pt-3 border-top" style="display: none;">
                <div class="d-flex flex-wrap gap-2">
                    <c:set var="hasShowtime1" value="false" />
                    <c:forEach items="${showtimeList}" var="s">
                        <c:if test="${s.cinemaName eq 'CINEMA EAUT Cầu Giấy'}">
                            <c:set var="hasShowtime1" value="true" />
                            <a href="seat?showtimeId=${s.id}" class="time-slot-btn">
                                <div class="fw-bold fs-6">${s.showTime.substring(11, 16)}</div>
                                <small style="font-size: 9px; color: #6c757d;">${s.roomName}</small>
                            </a>
                        </c:if>
                    </c:forEach>
                    <c:if test="${!hasShowtime1}">
                        <div class="small text-muted">Hiện chưa có suất chiếu.</div>
                    </c:if>
                </div>
            </div>
        </div>

        <!-- Rạp 2: CINEMA EAUT Hà Đông -->
        <div class="cinema-list-card" onclick="toggleCinema(this)">
            <div class="d-flex justify-content-between align-items-center">
                <span class="fs-6 text-dark cinema-title fw-bold">CINEMA EAUT Hà Đông</span>
                <span class="text-primary small" style="color: #4a90e2 !important;">4.2 km <i class="fa-solid fa-chevron-down ms-2 text-dark"></i></span>
            </div>
            <div class="time-slots-wrapper mt-3 pt-3 border-top" style="display: none;">
                <div class="d-flex flex-wrap gap-2">
                    <c:set var="hasShowtime2" value="false" />
                    <c:forEach items="${showtimeList}" var="s">
                        <c:if test="${s.cinemaName eq 'CINEMA EAUT Hà Đông'}">
                            <c:set var="hasShowtime2" value="true" />
                            <a href="seat?showtimeId=${s.id}" class="time-slot-btn">
                                <div class="fw-bold fs-6">${s.showTime.substring(11, 16)}</div>
                                <small style="font-size: 9px; color: #6c757d;">${s.roomName}</small>
                            </a>
                        </c:if>
                    </c:forEach>
                    <c:if test="${!hasShowtime2}">
                        <div class="small text-muted">Hiện chưa có suất chiếu.</div>
                    </c:if>
                </div>
            </div>
        </div>

        <!-- Rạp 3: CINEMA EAUT Hai Bà Trưng -->
        <div class="cinema-list-card" onclick="toggleCinema(this)">
            <div class="d-flex justify-content-between align-items-center">
                <span class="fs-6 text-dark cinema-title fw-bold">CINEMA EAUT Hai Bà Trưng</span>
                <span class="text-primary small" style="color: #4a90e2 !important;">6.7 km <i class="fa-solid fa-chevron-down ms-2 text-dark"></i></span>
            </div>
            <div class="time-slots-wrapper mt-3 pt-3 border-top" style="display: none;">
                <div class="d-flex flex-wrap gap-2">
                    <c:set var="hasShowtime3" value="false" />
                    <c:forEach items="${showtimeList}" var="s">
                        <c:if test="${s.cinemaName eq 'CINEMA EAUT Hai Bà Trưng'}">
                            <c:set var="hasShowtime3" value="true" />
                            <a href="seat?showtimeId=${s.id}" class="time-slot-btn">
                                <div class="fw-bold fs-6">${s.showTime.substring(11, 16)}</div>
                                <small style="font-size: 9px; color: #6c757d;">${s.roomName}</small>
                            </a>
                        </c:if>
                    </c:forEach>
                    <c:if test="${!hasShowtime3}">
                        <div class="small text-muted">Hiện chưa có suất chiếu.</div>
                    </c:if>
                </div>
            </div>
        </div>

    </div>
</div>

<jsp:include page="footer.jsp" />

<script>
    function toggleCinema(cardElement) {
        const wrapper = cardElement.querySelector('.time-slots-wrapper');
        const icon = cardElement.querySelector('.fa-chevron-down, .fa-chevron-up');
        if (event.target.closest('.time-slot-btn')) return;

        if (wrapper.style.display === 'none' || wrapper.style.display === '') {
            wrapper.style.display = 'block';
            if (icon) {
                icon.classList.remove('fa-chevron-down');
                icon.classList.add('fa-chevron-up');
            }
        } else {
            wrapper.style.display = 'none';
            if (icon) {
                icon.classList.remove('fa-chevron-up');
                icon.classList.add('fa-chevron-down');
            }
        }
    }
</script>

</body>
</html>