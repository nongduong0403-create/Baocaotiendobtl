<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">

<style>
    /* 1. THANH ĐIỀU HƯỚNG DƯỚI ĐÁY CHO MOBILE */
    .mobile-bottom-nav {
        display: none; /* Mặc định ẩn trên PC */
        position: fixed;
        bottom: 0;
        left: 0;
        width: 100%;
        background-color: #ffffff;
        box-shadow: 0 -4px 15px rgba(0,0,0,0.05);
        z-index: 1000;
        justify-content: space-around;
        padding: 10px 0 15px 0;
        border-top: 1px solid #e9ecef;
    }
    .mobile-nav-item {
        text-align: center;
        color: #6c757d;
        text-decoration: none;
        font-size: 0.75rem;
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 4px;
        width: 25%;
        -webkit-tap-highlight-color: transparent;
    }
    .mobile-nav-item i {
        font-size: 1.4rem;
        transition: transform 0.2s;
    }
    .mobile-nav-item.active {
        color: #0d6efd;
        font-weight: bold;
    }
    .mobile-nav-item.active i {
        transform: scale(1.1);
    }
    .mobile-nav-item:active i {
        transform: scale(0.9);
    }

    /* 2. CHUYỂN ĐỔI HIỂN THỊ KHI XUỐNG MOBILE */
    @media (max-width: 768px) {
        .pc-footer {
            display: none; /* Ẩn chữ ký đồ án PC đi cho gọn */
        }
        .mobile-bottom-nav {
            display: flex; /* Hiện thanh tab menu */
        }
        /* Đẩy nội dung toàn bộ trang lên một chút để không bị thanh menu che khuất */
        body {
            padding-bottom: 70px !important;
        }
    }
</style>

<!-- CHÂN TRANG MẶC ĐỊNH CHO PC -->
<footer class="bg-white text-dark text-center py-4 mt-5 border-top shadow-sm pc-footer">
    <div class="container">
        <p class="mb-0 fw-bold">© 2026 Cinema System. Đồ án phát triển bởi Dương Nông Dưỡng.</p>
        <small class="text-muted">Khoa Công nghệ Thông tin - Trường Đại học Công nghệ Đông Á</small>
    </div>
</footer>

