<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<html>
<head>
    <title>Hệ Thống Rạp - Cinema EAUT</title>

    <!-- KÍCH HOẠT CHUẨN MOBILE TẠI ĐÂY -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        body { background-color: #f8f9fa; color: #333; }
        .cinema-card {
            background-color: #ffffff;
            border: 1px solid #e9ecef;
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }

        /* Hiệu ứng hover cho PC */
        @media (hover: hover) {
            .cinema-card:hover {
                transform: translateY(-5px);
                box-shadow: 0 10px 20px rgba(0,0,0,0.1);
                border-color: #0d6efd;
            }
        }

        .banner-img {
            height: 350px;
            object-fit: cover;
            filter: brightness(0.8);
        }

        /* TINH CHỈNH RIÊNG CHO ĐIỆN THOẠI */
        @media (max-width: 768px) {
            .banner-img { height: 200px !important; } /* Thu nhỏ banner trên mobile */
            .banner-title { font-size: 1.6rem !important; }
            .banner-desc { font-size: 0.9rem !important; }

            /* Hiệu ứng nhún khi chạm ngón tay */
            .cinema-card:active { transform: scale(0.97); }
            .btn-action:active { transform: scale(0.95); }
        }
    </style>
</head>
<body class="d-flex flex-column" style="min-height: 100vh;">

<jsp:include page="header.jsp" />

<!-- BANNER -->
<div class="mb-4 mb-md-5 position-relative">
    <img src="https://images.unsplash.com/photo-1517604931442-7e0c8ed2963c?ixlib=rb-4.0.3&auto=format&fit=crop&w=1200&q=80" class="w-100 banner-img" alt="Banner">
    <div class="position-absolute top-50 start-50 translate-middle text-center w-100 px-3">
        <h1 class="fw-bold text-white display-5 text-uppercase banner-title">Hệ Thống Rạp EAUT</h1>
        <p class="text-light fs-5 banner-desc mb-0">Cơ sở vật chất hiện đại - Trải nghiệm điện ảnh đỉnh cao</p>
    </div>
</div>

<!-- DANH SÁCH RẠP -->
<div class="container mb-5 flex-grow-1">
    <div class="row g-3 g-md-4">
        <c:forEach items="${roomList}" var="r">
            <div class="col-12 col-md-4">
                <div class="card cinema-card rounded-4 h-100 p-3 text-center d-flex flex-column shadow-sm">
                    <div class="card-body">
                        <i class="bi bi-camera-reels fs-1 text-primary mb-2"></i>
                        <h4 class="card-title text-primary fw-bold">${r.name}</h4>
                        <p class="card-text text-muted small">Trang bị ghế VIP, không gian hiện đại, sẵn sàng phục vụ.</p>
                        <p class="text-secondary small"><i class="bi bi-people-fill me-1"></i> Không gian hiện đại, âm thanh vòm</p>
                    </div>
                    <div class="card-footer bg-transparent border-0 pb-3 mt-auto">
                        <a href="seats?roomId=${r.id}" class="btn btn-warning w-100 fw-bold rounded-pill shadow-sm text-dark btn-action py-2">
                            <i class="bi bi-ticket-perforated me-1"></i> Đặt Vé / Chọn Ghế
                        </a>
                    </div>
                </div>
            </div>
        </c:forEach>
    </div>
</div>

<jsp:include page="footer.jsp" />
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>