<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<html>
<head>
    <title>Hỗ Trợ Khách Hàng - Nhân Viên</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { background-color: #f8f9fa; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .wrapper { display: flex; width: 100%; align-items: stretch; }
        #sidebar { min-width: 260px; max-width: 260px; background: #1b212d; color: #fff; min-height: 100vh; }
        #sidebar .sidebar-header { padding: 20px; background: #141821; font-weight: bold; font-size: 1.1rem; }
        #sidebar ul.components { padding: 20px 0; }
        #sidebar ul li a { padding: 12px 20px; font-size: 0.95rem; display: block; color: #b0c4de; text-decoration: none; transition: 0.2s; }
        #sidebar ul li a:hover, #sidebar ul li.active a { color: #fff; background: #0d6efd; border-radius: 0 25px 25px 0; margin-right: 15px; }
        #sidebar ul li a i { margin-right: 10px; width: 20px; }
        #content { width: 100%; padding: 30px; }
        .card-custom { border: none; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
    </style>
</head>
<body>

<div class="wrapper">
    <!-- SIDEBAR MENU -->
    <nav id="sidebar">
        <div class="sidebar-header">
            <i class="fa-solid fa-clapperboard text-danger me-2"></i> CINEMA STAFF PORTAL
        </div>
        <ul class="list-unstyled components">
            <li>
                <a href="dashboard"><i class="fa-solid fa-chart-line"></i> Dashboard</a>
            </li>
            <li>
                <a href="../pos.jsp"><i class="fa-solid fa-qrcode"></i> Kiểm tra & Soát vé</a>
            </li>
            <li>
                <a href="../home"><i class="fa-solid fa-ticket"></i> Đặt vé tại quầy</a>
            </li>
            <li class="active">
                <a href="support.jsp"><i class="fa-solid fa-headset"></i> Hỗ trợ khách hàng</a>
            </li>
            <li>
                <a href="history"><i class="fa-solid fa-clock-rotate-left"></i> Lịch sử giao dịch</a>
            </li>
            <hr class="text-secondary mx-3">
            <li>
                <a href="../LogoutServlet" class="text-danger"><i class="fa-solid fa-right-from-bracket"></i> Đăng xuất</a>
            </li>
        </ul>
    </nav>

    <!-- NỘI DUNG CHÍNH -->
    <div id="content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="fw-bold text-dark mb-1">Trung tâm hỗ trợ khách hàng tại quầy</h3>
                <p class="text-muted small mb-0">Xử lý khiếu nại, tra cứu thông tin vé và hướng dẫn hoàn vé.</p>
            </div>
            <div class="bg-white px-3 py-2 rounded-pill shadow-sm border">
                <i class="fa-solid fa-user-tie text-primary me-2"></i> NV: <strong>${sessionScope.user.fullName}</strong>
            </div>
        </div>

        <div class="row g-4">
            <!-- Thẻ 1: Tra cứu đơn hàng bằng mã -->
            <div class="col-md-6">
                <div class="card card-custom p-4 bg-white h-100">
                    <h5 class="fw-bold text-primary mb-3"><i class="fa-solid fa-magnifying-glass me-2"></i>Tra cứu & Kiểm tra vé</h5>
                    <p class="text-muted small">Nhập mã đơn hàng hoặc mã vé để kiểm tra tính hợp lệ và giờ chiếu.</p>
                    <form action="../pos.jsp" method="GET">
                        <div class="input-group mb-3">
                            <input type="text" name="ticketCode" class="form-control" placeholder="Nhập mã BK- hoặc TCK-..." required>
                            <button class="btn btn-primary" type="submit">Kiểm tra ngay</button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Thẻ 2: Hướng dẫn chính sách hoàn/đổi -->
            <div class="col-md-6">
                <div class="card card-custom p-4 bg-white h-100">
                    <h5 class="fw-bold text-danger mb-3"><i class="fa-solid fa-rotate-left me-2"></i>Quy định hoàn & hủy vé</h5>
                    <ul class="text-muted small mb-3 ps-3">
                        <li>Hoàn vé chỉ áp dụng trước giờ chiếu ít nhất <strong>2 tiếng</strong>.</li>
                        <li>Vé đã qua cửa soát vé (trạng thái USED) không thể hoàn.</li>
                        <li>Phí hủy dịch vụ là 20% trên tổng giá trị hóa đơn.</li>
                    </ul>
                    <a href="../pos.jsp" class="btn btn-outline-danger btn-sm mt-auto">Mở cổng soát vé & hỗ trợ</a>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>