<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<html>
<head>
    <title>Dashboard Nhân Viên - Quầy Vé</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { background-color: #f8f9fa; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .wrapper { display: flex; width: 100%; align-items: stretch; }
        #sidebar { min-width: 260px; max-width: 260px; background: #1b212d; color: #fff; min-height: 100vh; transition: all 0.3s; }
        #sidebar .sidebar-header { padding: 20px; background: #141821; font-weight: bold; font-size: 1.1rem; }
        #sidebar ul.components { padding: 20px 0; }
        #sidebar ul li a { padding: 12px 20px; font-size: 0.95rem; display: block; color: #b0c4de; text-decoration: none; transition: 0.2s; }
        #sidebar ul li a:hover, #sidebar ul li.active a { color: #fff; background: #0d6efd; border-radius: 0 25px 25px 0; margin-right: 15px; }
        #sidebar ul li a i { margin-right: 10px; width: 20px; }
        #content { width: 100%; padding: 30px; }
        .stat-card { border: none; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); transition: 0.2s; }
        .stat-card:hover { transform: translateY(-3px); }
    </style>
</head>
<body>

<div class="wrapper">
    <!-- SIDEBAR MENU CỦA NHÂN VIÊN -->
    <nav id="sidebar">
        <div class="sidebar-header">
            <i class="fa-solid fa-clapperboard text-danger me-2"></i> CINEMA STAFF PORTAL
        </div>
        <ul class="list-unstyled components">
            <li class="active">
                <a href="${pageContext.request.contextPath}/staff/dashboard"><i class="fa-solid fa-chart-line"></i> Dashboard</a>
            </li>
            <li>
                <a href="${pageContext.request.contextPath}/PosServlet"><i class="fa-solid fa-qrcode"></i> Kiểm tra & Soát vé</a>
            </li>
            <li>
                <a href="${pageContext.request.contextPath}/home"><i class="fa-solid fa-ticket"></i> Đặt vé tại quầy</a>
            </li>
            <li>
                <a href="${pageContext.request.contextPath}/staff/support.jsp"><i class="fa-solid fa-headset"></i> Hỗ trợ khách hàng</a>
            </li>
            <li>
                <a href="${pageContext.request.contextPath}/staff/history"><i class="fa-solid fa-clock-rotate-left"></i> Lịch sử giao dịch</a>
            </li>
            <hr class="text-secondary mx-3">
            <li>
                <a href="${pageContext.request.contextPath}/logout" class="text-danger"><i class="fa-solid fa-right-from-bracket"></i> Đăng xuất</a>
            </li>
        </ul>
    </nav>

    <!-- NỘI DUNG CHÍNH CỦA DASHBOARD -->
    <div id="content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="fw-bold text-dark mb-1">Tổng quan ca trực</h3>
                <p class="text-muted small mb-0">Hôm nay: <span class="fw-semibold">${currentDate}</span></p>
            </div>
            <div class="bg-white px-3 py-2 rounded-pill shadow-sm border">
                <i class="fa-solid fa-user-tie text-primary me-2"></i> NV Trực: <strong class="text-dark">${sessionScope.user.fullName}</strong>
            </div>
        </div>

        <!-- CÁC THẺ THỐNG KÊ (CARDS) -->
        <div class="row g-4 mb-4">
            <div class="col-12 col-md-4">
                <div class="card stat-card p-4 bg-white border-start border-primary border-4">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <p class="text-muted small mb-1">Tổng vé bán tại quầy</p>
                            <h3 class="fw-bold text-dark mb-0">${totalTicketsSold} <span class="fs-6 fw-normal text-muted">vé</span></h3>
                        </div>
                        <div class="bg-primary bg-opacity-10 p-3 rounded-circle text-primary">
                            <i class="fa-solid fa-ticket fs-4"></i>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-12 col-md-4">
                <div class="card stat-card p-4 bg-white border-start border-success border-4">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <p class="text-muted small mb-1">Doanh thu ca trực</p>
                            <h3 class="fw-bold text-success mb-0">${totalRevenue != null ? totalRevenue : 0} <span class="fs-6 fw-normal text-muted">đ</span></h3>
                        </div>
                        <div class="bg-success bg-opacity-10 p-3 rounded-circle text-success">
                            <i class="fa-solid fa-wallet fs-4"></i>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-12 col-md-4">
                <div class="card stat-card p-4 bg-white border-start border-warning border-4">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <p class="text-muted small mb-1">Khách đã Check-in</p>
                            <h3 class="fw-bold text-warning mb-0">${totalCheckedIn} <span class="fs-6 fw-normal text-muted">khách</span></h3>
                        </div>
                        <div class="bg-warning bg-opacity-10 p-3 rounded-circle text-warning">
                            <i class="fa-solid fa-user-check fs-4"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- KHUNG TRẠNG THÁI NHANH -->
        <div class="card stat-card p-4 bg-white">
            <h5 class="fw-bold text-dark mb-3"><i class="fa-solid fa-circle-info text-primary me-2"></i> Hướng dẫn nhanh cho nhân viên</h5>
            <ul class="text-muted small mb-0 ps-3">
                <li class="mb-2">Sử dụng mục <b>Kiểm tra & Soát vé</b> để quét hoặc nhập mã vé xác thực khách vào phòng chiếu.</li>
                <li class="mb-2">Sử dụng mục <b>Đặt vé tại quầy</b> để bán trực tiếp cho khách vãng lai và thu tiền mặt/chuyển khoản.</li>
                <li>Mọi số liệu doanh thu và số lượng vé bán sẽ tự động cộng dồn theo mã tài khoản nhân viên của bạn trong ngày.</li>
            </ul>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>