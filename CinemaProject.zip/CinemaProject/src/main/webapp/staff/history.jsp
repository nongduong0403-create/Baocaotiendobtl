<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<html>
<head>
    <title>Lịch Sử Giao Dịch - Nhân Viên</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { background-color: #f8f9fa; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        .wrapper { display: flex; width: 100%; align-items: stretch; }
        #sidebar { min-width: 260px; max-width: 260px; background: #1b212d; color: #fff; min-height: 100vh; }
        #sidebar .sidebar-header { padding: 20px; background: #141821; font-weight: bold; font-size: 1.1rem; }
        #sidebar ul.components { padding: 20px 0; }
        #sidebar ul li a { padding: 12px 20px; font-size: 0.95rem; display: block; color: #b0c4de; text-decoration: none; transition: 0.2s; }
        #sidebar ul li a:hover, #sidebar ul li.active a { color: #fff; background: #0d6efd; border-radius: 0 25px 25px 0; margin-right: 15px; }
        #sidebar ul li a i { margin-right: 10px; width: 20px; }
        #content { width: 100%; padding: 30px; }
        .card-custom { border: none; border-radius: 12px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); }
    </style>
</head>
<body>

<div class="wrapper">
    <!-- SIDEBAR MENU (ĐÃ TÁCH BIỆT LINK VÀ KÍCH HOẠT SUPPORT) -->
    <nav id="sidebar">
        <div class="sidebar-header">
            <i class="fa-solid fa-clapperboard text-danger me-2"></i> CINEMA STAFF PORTAL
        </div>
        <ul class="list-unstyled components">
            <li>
                <a href="dashboard"><i class="fa-solid fa-chart-line"></i> Dashboard</a>
            </li>
            <li>
                <!-- Soát vé: Dẫn vào cổng POS nhập mã vé -->
                <a href="../pos.jsp"><i class="fa-solid fa-qrcode"></i> Kiểm tra & Soát vé</a>
            </li>
            <li>
                <!-- Đặt vé quầy: Dẫn ra trang chọn phim/suất chiếu -->
                <a href="../home"><i class="fa-solid fa-ticket"></i> Đặt vé tại quầy</a>
            </li>
            <li>
                <!-- Hỗ trợ: Dẫn sang trang support.jsp vừa tạo -->
                <a href="support.jsp"><i class="fa-solid fa-headset"></i> Hỗ trợ khách hàng</a>
            </li>
            <li class="active">
                <a href="history"><i class="fa-solid fa-clock-rotate-left"></i> Lịch sử giao dịch</a>
            </li>
            <hr class="text-secondary mx-3">
            <li>
                <a href="../LogoutServlet" class="text-danger"><i class="fa-solid fa-right-from-bracket"></i> Đăng xuất</a>
            </li>
        </ul>
    </nav>

    <!-- NỘI DUNG CHÍNH -->
    <div id="content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <div>
                <h3 class="fw-bold text-dark mb-1">Lịch sử giao dịch bán vé</h3>
                <p class="text-muted small mb-0">Danh sách các đơn hàng do nhân viên <strong class="text-primary">${sessionScope.user.fullName}</strong> đã thực hiện.</p>
            </div>
            <div class="bg-white px-3 py-2 rounded-pill shadow-sm border">
                <i class="fa-solid fa-user-tie text-primary me-2"></i> NV: <strong>${sessionScope.user.fullName}</strong>
            </div>
        </div>

        <!-- BẢNG HIỂN THỊ DANH SÁCH GIAO DỊCH -->
        <div class="card card-custom p-4 bg-white">
            <div class="table-responsive">
                <table class="table table-hover align-middle">
                    <thead class="table-light">
                    <tr>
                        <th>Mã Đơn (Booking ID)</th>
                        <th>Thời gian bán</th>
                        <th>Tổng tiền</th>
                        <th>Trạng thái</th>
                    </tr>
                    </thead>
                    <tbody>
                    <c:choose>
                        <c:when test="${not empty historyList}">
                            <c:forEach var="item" items="${historyList}">
                                <tr>
                                    <td><span class="fw-bold text-success">${item.bookingCode}</span></td>
                                    <td>${item.bookingTime}</td>
                                    <td><span class="fw-bold text-danger">${item.totalAmount} đ</span></td>
                                    <td>
                                            <span class="badge bg-${item.status == 'PAID' ? 'success' : (item.status == 'USED' ? 'secondary' : 'warning')}">
                                                    ${item.status}
                                            </span>
                                    </td>
                                </tr>
                            </c:forEach>
                        </c:when>
                        <c:otherwise>
                            <tr>
                                <td colspan="4" class="text-center text-muted py-4">Chưa có giao dịch nào được ghi nhận trong ca trực của bạn.</td>
                            </tr>
                        </c:otherwise>
                    </c:choose>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>