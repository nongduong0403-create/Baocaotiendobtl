<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<html>
<head>
    <title>Đặt vé thành công</title>

    <!-- KÍCH HOẠT CHUẨN MOBILE TẠI ĐÂY -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { background-color: #f8f9fa; }
        .success-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.08);
            max-width: 550px;
            margin: 20px auto 40px auto;
            padding: 25px;
            border-top: 6px solid #28a745;
        }
        .rule-box {
            background: #fff3cd;
            border-left: 4px solid #ffc107;
            padding: 12px 15px;
            font-size: 13px;
            text-align: left;
            border-radius: 4px;
            margin-top: 20px;
        }

        /* Hiệu ứng nhún khi chạm trên điện thoại */
        .btn-active:active {
            transform: scale(0.96);
        }

        /* Tối ưu riêng cho điện thoại */
        @media (max-width: 768px) {
            .success-card { margin: 15px; padding: 1rem; }
        }
    </style>
</head>
<body class="d-flex flex-column" style="min-height: 100vh;">

<jsp:include page="header.jsp" />

<div class="container flex-grow-1 my-3 my-md-4 px-3">

    <!-- HIỂN THỊ THÔNG BÁO KẾT QUẢ HOÀN VÉ (NẾU KHÁCH HÀNG VỪA GỬI YÊU CẦU) -->
    <%
        String error = request.getParameter("error");
        String success = request.getParameter("success");
        String amount = request.getParameter("amount");

        if ("timeout".equals(error)) {
            out.print("<div class='alert alert-danger text-center small'>❌ <b>Hoàn vé KHÔNG HỢP LỆ:</b> Đã quá thời hạn cho phép (Chỉ được hoàn vé trước giờ chiếu ít nhất 2 tiếng).</div>");
        } else if ("invalid_status".equals(error)) {
            out.print("<div class='alert alert-warning text-center small'>⚠️ Vé này đã được hoàn hoặc không ở trạng thái hợp lệ!</div>");
        } else if ("refunded".equals(success)) {
            out.print("<div class='alert alert-success text-center small'>✅ <b>Hoàn vé THÀNH CÔNG:</b> Hệ thống đã hoàn trả " + amount + " đ vào tài khoản của bạn và giải phóng ghế!</div>");
        }
    %>

    <div class="success-card text-center">
        <div class="mb-3">
            <i class="fa-solid fa-circle-check text-success fs-1"></i>
            <h3 class="fw-bold text-success mt-2 fs-4">Thanh toán thành công!</h3>
            <p class="text-muted small mb-0">Cảm ơn bạn đã đặt vé tại rạp chiếu phim EAUT.</p>
        </div>

        <hr class="text-muted">

        <div class="text-start mb-4">
            <div class="row mb-2">
                <div class="col-6 text-secondary small">Mã đơn hàng:</div>
                <div class="col-6 fw-bold text-dark small text-end">#BK-${param.bookingId}</div>
            </div>
            <div class="row mb-2">
                <div class="col-6 text-secondary small">Ghế của bạn:</div>
                <div class="col-6 fw-bold text-primary small text-end">${param.seats}</div>
            </div>
            <div class="row mb-2">
                <div class="col-6 text-secondary small">Mã vé điện tử:</div>
                <div class="col-6 fw-bold text-danger small text-end">TCK-${param.bookingId}9F8A</div>
            </div>
        </div>

        <!-- KHU VỰC NÚT YÊU CẦU HOÀN VÉ ĐÃ ĐƯỢC CHỈNH SỬA -->
        <div class="p-3 bg-light rounded border mb-3">
            <h6 class="fw-bold mb-2 text-dark" style="font-size: 0.95rem;">Bạn muốn thay đổi kế hoạch?</h6>
            <!-- CẬP NHẬT ĐƯỜNG LINK NÀY -->
            <a href="refund.jsp?bookingId=${param.bookingId}&seats=${param.seats}&showtimeId=${param.showtimeId}"
               class="btn btn-outline-danger btn-sm fw-bold px-4 btn-active py-1"
               onclick="return confirm('Hệ thống sẽ chuyển bạn sang trang điền thông tin hoàn vé. Phí hủy vé là 20% tổng giá trị. Bạn có muốn tiếp tục?');">
                Yêu cầu Hoàn Vé ngay
            </a>
        </div>

        <!-- HƯỚNG DẪN QUY ĐỊNH HOÀN VÉ HỢP LỆ / KHÔNG HỢP LỆ -->
        <div class="rule-box">
            <h6 class="fw-bold text-dark mb-1" style="font-size: 0.85rem;"><i class="fa-solid fa-circle-info text-warning"></i> Quy định hoàn vé của rạp:</h6>
            <ul class="mb-0 ps-3" style="font-size: 12px;">
                <li><b>Hợp lệ:</b> Yêu cầu hoàn vé phải được thực hiện <b>trước giờ chiếu ít nhất 2 tiếng</b>. Khách hàng sẽ nhận lại 80% tiền vé (trừ 20% phí dịch vụ).</li>
                <li><b>Không hợp lệ:</b> Nếu thời gian hiện tại đã sát giờ chiếu (dưới 2 tiếng) hoặc vé đã qua sử dụng, hệ thống sẽ tự động từ chối yêu cầu hoàn vé.</li>
            </ul>
        </div>

        <div class="mt-4">
            <a href="home" class="btn btn-primary px-5 fw-bold shadow-sm btn-active py-2">Về trang chủ</a>
        </div>
    </div>
</div>

<jsp:include page="footer.jsp" />
</body>
</html>