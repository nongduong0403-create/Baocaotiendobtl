<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ page import="java.sql.*, java.util.*, dal.DBContext" %>
<%
    // =========================================================================
    // LẤY TRỰC TIẾP TÊN GHẾ ĐÃ ĐẶT TỪ DATABASE VÀ ÉP VÀO MẢNG JAVASCRIPT
    // =========================================================================
    Object rawTargetId = request.getAttribute("showtimeId");
    if (rawTargetId == null) rawTargetId = request.getParameter("showtimeId");
    if (rawTargetId == null) rawTargetId = request.getAttribute("roomId");
    if (rawTargetId == null) rawTargetId = request.getParameter("roomId");

    int stId = 0;
    if (rawTargetId != null) {
        try { stId = Integer.parseInt(String.valueOf(rawTargetId).trim()); } catch(Exception ignored) {}
    }

    List<String> bookedList = new ArrayList<>();

    if (stId > 0) {
        try (Connection conn = DBContext.getConnection();
             PreparedStatement ps = conn.prepareStatement("SELECT seat_name FROM showtime_seat WHERE showtime_id = ?")) {
            ps.setInt(1, stId);
            try (ResultSet rs = ps.executeQuery()) {
                while(rs.next()) {
                    String sName = rs.getString("seat_name");
                    if (sName != null && !sName.trim().isEmpty()) {
                        bookedList.add("\"" + sName.trim().toUpperCase() + "\"");
                    }
                }
            }
        } catch(Exception e) {
            System.out.println("Lỗi đọc DB tại seat.jsp: " + e.getMessage());
        }
    }
    String jsBookedSeats = String.join(",", bookedList);
%>
<html>
<head>
    <title>Chọn ghế ngồi - ${not empty movie.title ? movie.title : 'Cinema'}</title>

    <!-- KÍCH HOẠT CHUẨN MOBILE -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        body { background-color: #f8f9fa; padding-bottom: 90px; }

        /* Banner làm mờ */
        .app-banner { position: relative; width: 100%; min-height: 160px; overflow: hidden; display: flex; align-items: center; justify-content: center; text-align: center; color: white; padding: 25px 0 15px 0; background: #000; }
        .app-banner-bg { position: absolute; top: -20px; left: -20px; right: -20px; bottom: -20px; background-size: cover; background-position: center; filter: blur(6px); z-index: 1; opacity: 0.6; }
        .app-banner-overlay { position: absolute; top: 0; left: 0; width: 100%; height: 100%; background: linear-gradient(to bottom, rgba(0, 34, 76, 0.3), rgba(0, 34, 76, 0.85)); z-index: 2; }
        .app-banner-content { position: relative; z-index: 3; }

        /* Chú thích ghế (Legend) */
        .legend-section { background: white; padding: 15px; border-bottom: 5px solid #f1f1f1; }
        .legend-item { display: flex; align-items: center; gap: 8px; font-size: 13px; color: #555; margin-bottom: 8px; }
        .price-item { display: flex; flex-direction: column; align-items: flex-end; font-size: 13px; color: #555; margin-bottom: 8px; text-align: right; }
        .price-item .fw-bold { font-size: 15px; color: #000; }

        /* Icon ghế mini trong chú thích */
        .seat-icon { width: 22px; height: 20px; border-radius: 4px; border: 1px solid #aaa; border-top: 4px solid #aaa; display: inline-block; background: #e9ecef; }
        .seat-icon.vip { border-color: #ff3333; border-top-color: #ff3333; background: #fff; }
        .seat-icon.couple { width: 32px; border-color: #ff3333; border-top-color: #ff3333; background: #fff; }
        .seat-icon.selected { background: #0056b3; border-color: #004494; border-top-color: #003370; }
        .seat-icon.booked { background: #ff3333; border-color: #cc0000; border-top-color: #cc0000; }
        .seat-icon.holding { background: #33ccff; border-color: #0099cc; border-top-color: #007399; }
        .seat-icon.pre-booked { background: #ffcc00; border-color: #cca300; border-top-color: #cca300; }

        /* Màn hình chiếu */
        .screen-container { margin: 25px auto 30px auto; width: 90%; max-width: 600px; text-align: center; position: relative; }
        .screen-curve { height: 25px; border-top: 3px solid #7c8ea3; border-radius: 50% 50% 0 0 / 100% 100% 0 0; box-shadow: 0 15px 20px -5px rgba(0,0,0,0.15); margin-bottom: 15px; }
        .screen-text { color: #888; font-weight: bold; font-size: 12px; text-transform: uppercase; letter-spacing: 2px; text-shadow: 0px 1px 2px rgba(0,0,0,0.1); position: absolute; top: 10px; width: 100%; text-align: center; }

        /* Khu vực cuộn ngang cho sơ đồ ghế trên Mobile */
        .seat-map-scroll {
            width: 100%;
            overflow-x: auto; /* Cho phép vuốt ngang */
            -webkit-overflow-scrolling: touch; /* Mượt mà trên iOS */
            padding: 10px 15px 30px 15px;
        }

        /* Vỏ bọc sơ đồ ghế để không bị ép nhỏ */
        .seat-map-wrapper {
            min-width: 650px; /* Đảm bảo sơ đồ ghế luôn đủ rộng, trên mobile tự vuốt ngang */
            margin: 0 auto;
            padding-bottom: 20px;
        }

        .seat-row { display: flex; justify-content: center; gap: 5px; margin-bottom: 8px; }

        /* Thiết kế ghế chuẩn chỉnh */
        .seat {
            width: 32px;
            height: 30px;
            font-size: 11px;
            font-weight: 700;
            border-radius: 6px 6px 4px 4px;
            border: 1px solid #adb5bd;
            border-top: 5px solid #adb5bd;
            background: #e9ecef;
            color: #333;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            user-select: none;
            transition: 0.1s;
        }
        .seat:active { transform: scale(0.9); }

        /* Loại ghế */
        .seat.vip { border: 1px solid #ff3333; border-top: 5px solid #ff3333; background: #fffafa; color: #ff3333; }
        .seat.couple { width: 70px; border: 1px solid #ff3333; border-top: 5px solid #ff3333; background: #fffafa; color: #ff3333; font-size: 11px; }

        /* Trạng thái */
        .seat.selected { background: #0056b3 !important; color: white !important; border-color: #004494 !important; border-top-color: #003370 !important; }
        .seat.booked { background: #ff3333 !important; color: white !important; border-color: #e60000 !important; border-top-color: #cc0000 !important; cursor: not-allowed; }

        /* Thanh bottom */
        .bottom-bar { position: fixed; bottom: 0; left: 0; width: 100%; background: white; box-shadow: 0 -4px 15px rgba(0,0,0,0.08); padding: 15px 20px; z-index: 1000; border-top: 1px solid #e9ecef; display: flex; justify-content: space-between; align-items: center; }
        .timer-text { font-size: 16px; font-weight: 600; color: #333; }
        .timer-clock { font-size: 22px; font-weight: bold; color: #000; }
        .checkout-btn { background: #ff3333; border: none; border-radius: 25px; padding: 8px 25px; font-weight: bold; font-size: 15px; color: white; display: none; cursor: pointer; }
        .checkout-btn:hover { background: #cc0000; }

        /* TINH CHỈNH CSS CHO RIÊNG MOBILE */
        @media (max-width: 768px) {
            .legend-item, .price-item { font-size: 11px; }
            .price-item .fw-bold { font-size: 13px; }
            .legend-section { padding: 10px; }

            /* Cảnh báo vuốt ngang hiện lên trên Mobile */
            .swipe-hint {
                display: block !important;
                text-align: center;
                color: #888;
                font-size: 12px;
                margin-bottom: 5px;
                font-style: italic;
            }
        }
        .swipe-hint { display: none; } /* Ẩn trên máy tính */
    </style>
</head>
<body>

<!-- 1. Banner phong cách App -->
<div class="app-banner">
    <div class="app-banner-bg" style="background-image: url('${not empty movie.posterUrl ? movie.posterUrl : 'https://cdn.galaxycine.vn/media/2024/2/1/mai-500_1706775685800.jpg'}');"></div>
    <div class="app-banner-overlay"></div>

    <div class="app-banner-content text-white d-flex flex-column align-items-center">
        <h3 class="fw-bold mb-1">${not empty movie.title ? movie.title : 'Đang tải tên phim...'}</h3>
        <p class="small text-white-50 mb-0">
            2D Phụ đề | ${not empty showDate ? showDate : '...'} ${not empty showTime ? showTime : '...'} | ${not empty movie.duration ? movie.duration : '...'} phút
        </p>
    </div>
</div>

<!-- 2. Khối Chú Thích (Legend) -->
<div class="legend-section">
    <div class="container" style="max-width: 600px;">
        <div class="row">
            <div class="col-7">
                <div class="legend-item"><span class="seat-icon"></span> Ghế trống</div>
                <div class="legend-item"><span class="seat-icon holding"></span> Ghế đang giữ</div>
                <div class="legend-item"><span class="seat-icon selected"></span> Ghế đang chọn</div>
                <div class="legend-item"><span class="seat-icon booked"></span> Ghế đã bán</div>
                <div class="legend-item"><span class="seat-icon pre-booked"></span> Ghế đặt trước</div>
            </div>
            <div class="col-5">
                <div class="price-item">
                    <span class="d-flex align-items-center gap-2"><span class="seat-icon vip" style="border-color:#ccc; border-top-color:#ccc;"></span> Ghế thường</span>
                    <span class="fw-bold">45.000 đ</span>
                </div>
                <div class="price-item">
                    <span class="d-flex align-items-center gap-2"><span class="seat-icon vip"></span> Ghế VIP</span>
                    <span class="fw-bold">50.000 đ</span>
                </div>
                <div class="price-item">
                    <span class="d-flex align-items-center gap-2"><span class="seat-icon couple"></span> Ghế đôi</span>
                    <span class="fw-bold">100.000 đ</span>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- 3. Khu vực Sơ đồ ghế -->
<div class="container-fluid p-0">
    <div class="screen-container">
        <div class="screen-curve"></div>
        <div class="screen-text">MÀN HÌNH CHIẾU</div>
    </div>

    <!-- Dòng chữ gợi ý vuốt màn hình (Chỉ xuất hiện trên điện thoại) -->
    <div class="swipe-hint"><i class="fa-solid fa-arrows-left-right"></i> Vuốt ngang để xem toàn bộ ghế</div>

    <!-- Bọc sơ đồ ghế trong một div có khả năng cuộn ngang -->
    <div class="seat-map-scroll">
        <div class="seat-map-wrapper">
            <div id="seat-map-container" class="d-flex flex-column align-items-center">
                <!-- Ghế sẽ được render bằng JS ở dưới -->
            </div>
        </div>
    </div>
</div>

<!-- 4. Thanh toán cố định -->
<div class="bottom-bar">
    <div class="d-flex flex-column">
        <span class="timer-text" id="total-price-label">Thời gian còn lại:</span>
        <span id="seat-info" class="small text-muted" style="display: none;">Ghế: <span id="selected-seats-list" class="fw-bold text-dark"></span></span>
    </div>
    <div class="d-flex align-items-center gap-3">
        <span class="timer-clock" id="timer">10:00</span>
        <button id="checkout-btn" class="checkout-btn" onclick="checkout()">Tiếp tục</button>
    </div>
</div>

<input type="hidden" id="hidden-showtime-id" value="<%= (stId > 0) ? stId : "" %>">

<script>
    const seatLayout = [
        { row: 'A', count: 14, type: 'normal' },
        { row: 'B', count: 15, type: 'normal' },
        { row: 'C', count: 14, type: 'normal' },
        { row: 'D', count: 15, type: 'normal' },
        { row: 'E', count: 13, type: 'vip' },
        { row: 'F', count: 15, type: 'vip' },
        { row: 'G', count: 14, type: 'vip' },
        { row: 'H', count: 15, type: 'vip' },
        { row: 'I', count: 14, type: 'vip' },
        { row: 'J', count: 14, type: 'vip' },
        { row: 'K', count: 13, type: 'vip' },
        { row: 'L', count: 11, type: 'vip' }
    ];

    // =========================================================================
    // NẠP DỮ LIỆU GHẾ ĐỎ TỪ DATABASE VÀ CHUẨN HÓA BẰNG JAVASCRIPT
    // =========================================================================
    const rawBookedSeats = [<%= jsBookedSeats %>];

    // Loại bỏ mọi khoảng trắng và ép in hoa để so sánh chuẩn xác 100%
    const cleanBookedSeats = rawBookedSeats.map(function(s) {
        return String(s).replace(/\s+/g, '').toUpperCase();
    });

    console.log("Danh sách ghế bị khóa (Đã chuẩn hóa): ", cleanBookedSeats);

    const seatContainer = document.getElementById('seat-map-container');

    function renderSeats() {
        let html = '';
        seatLayout.forEach(function(r) {
            html += '<div class="seat-row">';
            for(let i = r.count; i >= 1; i--) {
                let seatId = r.row + i;
                let price = (r.type === 'normal') ? 45000 : 50000;

                // Chuẩn hóa tên ghế đơn trên sơ đồ trước khi kiểm tra
                let checkId = seatId.replace(/\s+/g, '').toUpperCase();
                let isBooked = cleanBookedSeats.includes(checkId) ? 'booked' : '';

                html += '<div class="seat ' + r.type + ' ' + isBooked + '" onclick="toggleSeat(this, \'' + seatId + '\', ' + price + ')">' + seatId + '</div>';
            }
            html += '</div>';
        });

        html += '<div class="seat-row mt-2">';
        const couples = ['M10 M9', 'M8 M7', 'M6 M5', 'M4 M3', 'M2 M1'];
        couples.forEach(function(c) {
            // Chuẩn hóa kiểm tra ghế đôi: khớp cả chuỗi, dạng bỏ khoảng cách hoặc từng ghế con lẻ
            let parts = c.split(' ');
            let noSpace = c.replace(/\s+/g, '').toUpperCase();
            let isBooked = (cleanBookedSeats.includes(c.toUpperCase()) ||
                cleanBookedSeats.includes(noSpace) ||
                (parts.length >= 2 && (cleanBookedSeats.includes(parts[0].toUpperCase()) || cleanBookedSeats.includes(parts[1].toUpperCase())))) ? 'booked' : '';

            html += '<div class="seat couple ' + isBooked + '" onclick="toggleSeat(this, \'' + c + '\', 100000)">' + c + '</div>';
        });
        html += '</div>';

        seatContainer.innerHTML = html;
    }

    renderSeats();

    let selectedSeatsMap = new Map();

    function toggleSeat(element, seatName, price) {
        if (element.classList.contains('booked') || element.classList.contains('holding')) return;

        element.classList.toggle('selected');

        if (element.classList.contains('selected')) {
            selectedSeatsMap.set(seatName, price);
        } else {
            selectedSeatsMap.delete(seatName);
        }

        updateBottomBar();
    }

    function updateBottomBar() {
        let seatNamesArr = Array.from(selectedSeatsMap.keys());
        let totalPrice = 0;
        selectedSeatsMap.forEach(function(price) { totalPrice += price; });

        const timerLabel = document.getElementById('total-price-label');
        const timerClock = document.getElementById('timer');
        const checkoutBtn = document.getElementById('checkout-btn');
        const seatInfo = document.getElementById('seat-info');
        const selectedSeatsList = document.getElementById('selected-seats-list');

        if (seatNamesArr.length > 0) {
            timerLabel.innerText = "Tổng cộng:";
            timerClock.innerText = totalPrice.toLocaleString('vi-VN') + ' đ';
            timerClock.style.color = "#ff3333";
            checkoutBtn.style.display = "block";
            seatInfo.style.display = "block";
            selectedSeatsList.innerText = seatNamesArr.join(', ');
        } else {
            timerLabel.innerText = "Thời gian còn lại:";
            timerClock.style.color = "#000";
            checkoutBtn.style.display = "none";
            seatInfo.style.display = "none";
        }
    }

    function checkout() {
        let seatNames = Array.from(selectedSeatsMap.keys()).join(',');

        if (selectedSeatsMap.size === 0) {
            alert("Vui lòng chọn ít nhất 1 ghế!");
            return;
        }

        let totalPrice = 0;
        selectedSeatsMap.forEach(function(price) { totalPrice += price; });

        let showtimeId = document.getElementById('hidden-showtime-id').value;
        if (!showtimeId) {
            // Lấy trực tiếp từ URL nếu input hidden bị rỗng
            const urlParams = new URLSearchParams(window.location.search);
            showtimeId = urlParams.get('showtimeId') || urlParams.get('roomId');
        }

        // Tự động tách "M10 M9" thành "M10,M9" để Backend nhận diện đúng từng ghế
        let formattedSeats = seatNames.replace(/\s+/g, ',');

        window.location.href = "bookTicket?showtimeId=" + showtimeId + "&seats=" + encodeURIComponent(formattedSeats) + "&totalAmount=" + totalPrice;
    }
    let time = 10 * 60;
    setInterval(function() {
        let m = Math.floor(time / 60);
        let s = time % 60;

        if (selectedSeatsMap.size === 0) {
            document.getElementById('timer').innerText = m + ":" + (s < 10 ? '0' : '') + s;
        }

        if(time > 0) time--;
    }, 1000);
</script>

</body>
</html>