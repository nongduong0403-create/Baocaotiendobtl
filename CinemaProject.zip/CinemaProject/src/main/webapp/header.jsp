<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<nav class="navbar navbar-expand-lg navbar-light bg-white border-bottom py-2 py-lg-3 shadow-sm sticky-top">
    <div class="container">
        <!-- Logo -->
        <a class="navbar-brand fw-bold text-primary fs-4 d-flex align-items-center" href="home">
            🎬 CINEMA EAUT
        </a>

        <!-- Khu vực thông tin tài khoản & Nút Hamburger (Sẽ nằm gọn ở góc phải trên Mobile) -->
        <div class="d-flex align-items-center order-lg-3">
            <c:choose>
                <c:when test="${sessionScope.user != null}">

                    <!-- ========================================================= -->
                    <!-- TÍCH HỢP NÚT QUẢN LÝ NHÂN VIÊN CHO TÀI KHOẢN STAFF Ở ĐÂY -->
                    <!-- ========================================================= -->
                    <c:if test="${sessionScope.user.role == 'STAFF'}">
                        <a href="staff/dashboard" class="btn btn-success btn-sm fw-bold me-2 px-3 shadow-sm d-flex align-items-center" title="Trang quản lý nhân viên">
                            <i class="fa-solid fa-chart-line me-1"></i> <span class="d-none d-sm-inline">Quản Lý NV</span>
                        </a>
                    </c:if>

                    <div class="d-flex align-items-center text-end">
                        <div class="rounded-circle border border-2 border-primary text-primary d-flex justify-content-center align-items-center fw-bold" style="width: 38px; height: 38px; font-size: 1.1rem;">
                            <!-- Lấy chữ cái đầu của tên làm Avatar -->
                                ${sessionScope.user.fullName.substring(0,1)}
                        </div>
                        <!-- Ẩn dòng chào và badge trên Mobile để header không bị vỡ -->
                        <div class="lh-sm ms-2 d-none d-lg-block text-start me-3">
                            <small class="text-dark fw-bold d-block">Chào ${sessionScope.user.fullName}</small>
                            <span class="badge bg-primary" style="font-size: 0.7rem;"><i class="bi bi-person-badge"></i> ${sessionScope.user.membershipTier}</span>
                            <span class="badge bg-warning text-dark" style="font-size: 0.7rem;"><i class="bi bi-star-fill"></i> ${sessionScope.user.points}</span>
                        </div>
                    </div>
                    <!-- Nút Đăng xuất dạng icon -->
                    <a href="logout" class="btn btn-outline-secondary btn-sm me-3 me-lg-0 ms-2 ms-lg-0" title="Đăng xuất">
                        <i class="bi bi-box-arrow-right fs-5"></i>
                    </a>
                </c:when>
                <c:otherwise>
                    <a href="login.jsp" class="btn btn-warning fw-bold px-3 py-1 me-2 me-lg-0 rounded-pill text-dark shadow-sm" style="font-size: 0.9rem;">Đăng nhập</a>
                </c:otherwise>
            </c:choose>

            <!-- Nút Hamburger (Chỉ xuất hiện trên màn hình điện thoại) -->
            <button class="navbar-toggler border-0 px-1 shadow-none" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
                <span class="navbar-toggler-icon"></span>
            </button>
        </div>

        <!-- Các nút điều hướng chính (Sẽ tự động xổ dọc trên Mobile và căn giữa trên PC) -->
        <div class="collapse navbar-collapse justify-content-center order-lg-2" id="mainNav">
            <!-- Thêm mt-3 mt-lg-0 để khi xổ dọc trên mobile có khoảng cách với phía trên -->
            <ul class="navbar-nav mb-2 mb-lg-0 fw-bold text-uppercase text-center mt-3 mt-lg-0" style="font-size: 0.95rem;">
                <!-- Nút LỊCH CHIẾU -->
                <li class="nav-item mx-2 py-1 py-lg-0">
                    <a class="nav-link fw-bold ${pageContext.request.requestURI.contains('home') ? 'text-primary border-bottom border-primary border-2' : 'text-dark hover-primary'}"
                       href="home">LỊCH CHIẾU</a>
                </li>

                <!-- Nút HỆ THỐNG RẠP -->
                <li class="nav-item mx-2 py-1 py-lg-0">
                    <a class="nav-link fw-bold ${pageContext.request.requestURI.contains('room') ? 'text-primary border-bottom border-primary border-2' : 'text-dark hover-primary'}"
                       href="rooms">HỆ THỐNG RẠP</a>
                </li>

                <!-- Nút KHUYẾN MÃI -->
                <li class="nav-item mx-2 py-1 py-lg-0">
                    <a class="nav-link fw-bold ${pageContext.request.requestURI.contains('promotion') ? 'text-primary border-bottom border-primary border-2' : 'text-dark hover-primary'}"
                       href="promotions">KHUYẾN MÃI</a>
                </li>

                <!-- Nút VOUCHER CỦA TÔI -->
                <li class="nav-item mx-2 py-1 py-lg-0">
                    <a class="nav-link fw-bold ${pageContext.request.requestURI.contains('voucher') ? 'text-primary border-bottom border-primary border-2' : 'text-dark hover-primary'}"
                       href="vouchers">VOUCHER CỦA TÔI</a>
                </li>

                <!-- Nút Quản trị viên chỉ hiện nếu user là Admin -->
                <c:if test="${sessionScope.user != null && sessionScope.user.role == 'ADMIN'}">
                    <li class="nav-item mx-3 py-1 py-lg-0 mt-2 mt-lg-0 border-top border-lg-0 pt-2 pt-lg-0">
                        <a class="nav-link text-danger" href="admin"><i class="bi bi-gear-fill me-1"></i> Quản trị viên</a>
                    </li>
                </c:if>
            </ul>
        </div>
    </div>
</nav>

<style>
    /* Hiệu ứng di chuột vào menu chuyển màu xanh */
    .hover-primary:hover {
        color: #0d6efd !important;
    }
</style>