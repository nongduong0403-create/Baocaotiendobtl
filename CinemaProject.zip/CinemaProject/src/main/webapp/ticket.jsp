<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<html>
<head>
    <title>Thanh toán hóa đơn</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background-color: #f8f9fa; }
        .ticket-wrap { background: #fff; border-radius: 15px; box-shadow: 0 10px 25px rgba(0,0,0,0.08); max-width: 450px; margin: 20px auto 40px auto; position: relative; border-top: 8px solid #0d6efd; }
        .ticket-wrap::before, .ticket-wrap::after { content: ''; position: absolute; top: 62%; width: 25px; height: 25px; background: #f8f9fa; border-radius: 50%; }
        .ticket-wrap::before { left: -12px; box-shadow: inset -4px 0 8px rgba(0,0,0,0.05); }
        .ticket-wrap::after { right: -12px; box-shadow: inset 4px 0 8px rgba(0,0,0,0.05); }
        .ticket-divider { border-top: 2px dashed #dee2e6; margin: 20px 0; }
        .btn-success:active { transform: scale(0.97); }
        @media (max-width: 768px) { .ticket-wrap { margin: 15px; padding: 1.25rem !important; } .total-amount { font-size: 1.5rem !important; } }
    </style>
</head>
<body class="d-flex flex-column" style="min-height: 100vh;">

<jsp:include page="header.jsp" />

<div class="container flex-grow-1 my-3 my-md-4 px-3">
    <div class="ticket-wrap p-4 text-center">
        <div class="mb-3">
            <h1 class="mb-2 fs-2">💳</h1>
            <h4 class="fw-bold text-primary">VUI LÒNG THANH TOÁN</h4>
            <p class="text-muted small">Quét mã QR dưới đây để giữ ghế</p>
        </div>

        <div class="ticket-divider"></div>

        <div class="text-start">
            <div class="row mb-3">
                <div class="col-6">
                    <p class="text-secondary mb-1 small">Mã đơn hàng</p>
                    <h6 class="fw-bold text-dark mb-0">PENDING...</h6>
                </div>
                <div class="col-6 text-end">
                    <p class="text-secondary mb-1 small">Rạp chiếu</p>
                    <h6 class="fw-bold text-dark mb-0">Beta Mỹ Đình</h6>
                </div>
            </div>

            <p class="text-secondary mb-1 small">Ghế đã chọn</p>
            <div class="d-flex flex-wrap gap-2 mb-3">
                <!-- ĐÃ SỬA: Dùng Attribute ${seatIdsStr} từ Servlet truyền sang -->
                <span class="badge bg-danger fs-6 px-3 py-2">${seatIdsStr}</span>
            </div>

            <hr>
            <div class="d-flex justify-content-between align-items-center mb-4">
                <span class="text-secondary">Tổng thanh toán:</span>
                <!-- ĐÃ SỬA: Dùng Attribute ${totalAmount} -->
                <strong class="text-danger fs-3 total-amount">${totalAmount} đ</strong>
            </div>
        </div>

        <!-- KHU VỰC QUÉT MÃ QR -->
        <div class="text-center p-3 bg-light border rounded-3">
            <img src="https://img.vietqr.io/image/mbbank-0123456789-compact2.png?amount=${totalAmount}&addInfo=ThanhToanVePhim&accountName=DUONG NONG DUONG"
                 alt="Mã QR Thanh Toán" class="img-fluid border p-1 mb-3 shadow-sm" style="max-width: 190px; border-radius: 12px; background: white;">

            <!-- ĐÃ ĐỔI HƯỚNG VỀ ĐÚNG BOOKTICKETSERVLET ĐỂ LƯU DATABASE -->
            <form action="bookTicket" method="POST">
                <input type="hidden" name="action" value="confirm">
                <input type="hidden" name="showtimeId" value="${showtimeId}">
                <input type="hidden" name="seats" value="${seatIdsStr}">
                <input type="hidden" name="total" value="${totalAmount}">
                <button type="submit" class="btn btn-success btn-lg w-100 fw-bold shadow-sm py-2 fs-6">TÔI ĐÃ CHUYỂN KHOẢN XONG</button>
            </form>
        </div>

    </div>
</div>

<jsp:include page="footer.jsp" />
</body>
</html>