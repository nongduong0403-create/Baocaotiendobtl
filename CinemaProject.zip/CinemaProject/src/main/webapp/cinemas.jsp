<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<html>
<head>
    <title>Hệ Thống Rạp - Cinema EAUT</title>

    <!-- KÍCH HOẠT CHUẨN MOBILE TẠI ĐÂY -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        body { background-color: #f8f9fa; font-family: sans-serif; }
        .cinema-card { transition: transform 0.2s ease, box-shadow 0.2s ease; border-radius: 10px; overflow: hidden; }

        /* Hiệu ứng hover cho PC */
        @media (hover: hover) {
            .cinema-card:hover { transform: translateY(-5px); box-shadow: 0 10px 20px rgba(0,0,0,0.15); }
        }

        /* TINH CHỈNH RIÊNG CHO MOBILE */
        @media (max-width: 768px) {
            .page-title { font-size: 1.5rem; } /* Thu nhỏ tiêu đề H2 */
            .page-subtitle { font-size: 0.9rem; } /* Thu nhỏ mô tả */
            .cinema-card { margin: 0 10px; } /* Thêm khoảng cách 2 bên mép màn hình */

            /* Hiệu ứng nhún mượt mà khi tap ngón tay trên điện thoại */
            .cinema-card:active { transform: scale(0.97); box-shadow: 0 5px 10px rgba(0,0,0,0.1); }
        }
    </style>
</head>
<body class="d-flex flex-column" style="min-height: 100vh;">

<!-- HEADER -->
<jsp:include page="header.jsp" />

<div class="container flex-grow-1 my-4 my-md-5">
    <div class="text-center mb-4 mb-md-5 px-3">
        <h2 class="fw-bold text-uppercase text-primary page-title">Hệ Thống Rạp Chiếu Phim EAUT</h2>
        <p class="text-muted page-subtitle">Trải nghiệm điện ảnh đỉnh cao với hệ thống phòng chiếu hiện đại tiêu chuẩn quốc tế</p>
        <hr class="w-25 mx-auto">
    </div>

    <!-- Đổi thành col-12 col-md-4 để hiển thị rõ ràng 100% chiều ngang trên mobile -->
    <div class="row g-4">
        <!-- Lặp danh sách phòng/rạp từ Database lên -->
        <c:forEach items="${roomList}" var="r">
            <div class="col-12 col-md-4">
                <div class="card cinema-card shadow-sm border-0 h-100">
                    <div class="card-body p-4 d-flex flex-column justify-content-between">
                        <div>
                            <div class="d-flex align-items-center mb-3">
                                <i class="bi bi-geo-alt-fill fs-3 text-danger me-2"></i>
                                <h4 class="fw-bold mb-0">${r.name}</h4>
                            </div>
                            <p class="text-secondary mb-2">
                                <i class="bi bi-display me-2"></i>Sức chứa: <strong>${r.capacity} ghế</strong>
                            </p>
                            <p class="text-secondary mb-4">
                                <i class="bi bi-info-circle me-2"></i>Trạng thái:
                                <span class="badge bg-success">Đang hoạt động</span>
                            </p>
                        </div>
                        <a href="home" class="btn btn-outline-primary fw-bold w-100 py-2">
                            <i class="bi bi-ticket-perforated me-1"></i> Đặt vé ngay
                        </a>
                    </div>
                </div>
            </div>
        </c:forEach>
    </div>
</div>

<jsp:include page="footer.jsp" />
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>